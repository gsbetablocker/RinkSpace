import sys,pathlib,json
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'calibration/rinkfit/src'),str(root/'src')]
from rinkfit_joint.joint_replay import render_snapshots
r=render_snapshots(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/shared_g4/candidate/model.json',r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/programme_scope.json',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/visual_shared_g4',compiled_dir=r'D:/CodexData/RinkSpace_Data/runs/okada_s1_r11/gpu_accel/line_bundle/code/compiled_camera',packet_file=r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/g6_bound/packet.json',top_view=True)
print(json.dumps(dict(model=r['model'],frames=len(r['frames']))))
