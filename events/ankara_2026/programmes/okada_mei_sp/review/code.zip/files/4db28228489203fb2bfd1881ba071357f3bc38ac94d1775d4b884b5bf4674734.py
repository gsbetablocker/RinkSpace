from pathlib import Path
import json,hashlib,os,zipfile,zlib,time,sys
R=Path('D:/OneDrive/codex_projs/RinkSpace'); D=Path('D:/CodexData/RinkSpace_Data'); W=D/'runs/okada_rec_1019'; P=D/'pro'
items={}; omitted=[]
def add(p,a=None,role='evidence'):
 p=Path(p)
 if not p.is_file(): return
 if p.stat().st_size==0:return
 key=str(p.resolve()).replace('\\','/').lower()
 if key in items:return
 if a is None:
  try:a='Project/'+p.relative_to(R).as_posix()
  except ValueError:a='Data/'+p.relative_to(D).as_posix()
 items[key]={'source_path':str(p),'archive_path':a,'role':role,'bytes':p.stat().st_size}
def tree(p,role='evidence',ext=None,maxbytes=None):
 p=Path(p)
 if not p.exists():return
 for f in sorted(p.rglob('*')):
  if f.is_file() and not any(x in f.parts for x in ['__pycache__','.git','.venv','node_modules']):
   if ext is not None and f.suffix.lower() not in ext:continue
   if maxbytes is not None and f.stat().st_size>maxbytes:continue
   add(f,role=role)
# Agent-curated actual full Demo data and S01 baseline. Body pose is unrelated to rink audit.
i=json.loads((P/'Okada_DirectGrid_Offline_Inventory_20261019.json').read_text('utf-8'))
for f in i['files']:
 if f['id'] in ['demo_body'] or f['archive_path'].endswith('/body.npz'):continue
 add(f['source_path'],f['archive_path'],'direct-grid/S01')
for n in ['Okada_DirectGrid_Offline_Inventory_20261019.json','okada_stage_state_inventory.json','okada_recovery_audit_inventory.json','okada_worktree_relevant_status.txt']:
 add(P/n,'offline/'+n,'inventory')
s=json.loads((P/'okada_stage_state_inventory.json').read_text('utf-8'))
for f in s['states']:add(f['file'],role='complete-stage-state')
# Include all original current source data: raw rows, identity, W/Query, guards, native-clock arrays.
tree(W/'g9_ice','current-qualified-source')
# Latest is full, including complete outer multipliers, explicit aux, same-state pixel exports and independent RS exports.
tree(W/'demo_grid_recovery_v1','last-stopped-complete-run')
tree(W/'demo_physical_init65_v1','last-complete-initial-state')
# Original/changed source-generation summaries; do not copy identical hundreds-of-MB source packets here.
for d in W.iterdir():
 if d.is_dir() and (d.name.startswith(('g1','g2','g3','g4','g5','g6','g7','g8','g9','scope_ready'))):
  tree(d,'source-generation-decisions',{'.json','.log','.jsonl','.txt'},8_000_000)
# Every recorded stage full outer arrays, plus small receipts missing from compact inventory.
for stage in sorted({x['stage'] for x in s['states']}):
 tree(W/stage,'stage-receipts',{'.json','.jsonl','.log','.txt'},2_000_000)
 for f in (W/stage).rglob('*'):
  if f.is_file() and f.name in ['lambda.f64','nu.f64']:add(f,role='complete-stage-outer-multipliers')
# Actual current production source (untracked in Git) + build recipes/frozen native source version.
for sub in ['cpp','src','tools','docs']:
 tree(R/'calibration/rinkfit'/sub,'production-source',{'.py','.cpp','.hpp','.h','.cuh','.cu','.cmake','.md','.toml','.json','.txt'})
for n in ['CMakeLists.txt','launch.py','pyproject.toml','README.md','START_HERE.md','CODEX_START.md']:add(R/'calibration/rinkfit'/n,role='production-source')
for d in W.glob('build_v*'):
 if d.is_dir():
  tree(d/'include','frozen-build-source',{'.hpp','.h','.cuh'});tree(d/'src','frozen-build-source',{'.cpp','.cu'})
  for n in ['recipe.json','link.log','joint_recovery.log']:add(d/n,role='frozen-build-recipe')
# Last actual executable retained for identity and inspection, excluding .obj/.pdb/lib caches.
add(W/'build_v16/joint_fit.exe',role='last-executed-backend')
for f in W.iterdir():
 if f.is_file() and f.suffix.lower() in ['.py','.log','.json','.jsonl','.txt','.md'] and f.stat().st_size<10_000_000:add(f,role='run-entry-or-receipt')
tree(W/'perf','measured-performance',{'.py','.cpp','.json','.jsonl','.log','.txt'},8_000_000)
# Real source qualification/journals and final historical-chain products, no all-frame PNG caches.
for name in ['hist_s07_v1','hist_s09_v1','hist_short_v1','histacq','g9_source']:
 tree(W/name,'historical-source-closure',{'.json','.jsonl','.log','.txt','.md'},8_000_000)
for sub in ['hist_s07_v1/chain_qualified_v3','hist_s09_v1/qualified_C0_chain_v2','hist_short_v1/ring_history_qualified']:
 tree(W/sub,'qualified-historical-source',{'.gz'})
# Initialization failures and actual-pixel visual evidence, selected images only.
for sub in ['native_init_v1','grid_input_v1','demo_grid_sampson_v1_stopped','demo50_working_n6','demo_grid_init_v1_main_accepted1','S03_actual_pixel_evidence','B1_actual_pixel_evidence','Demo50_actual_reference','screen_grid_received_v1']:
 tree(W/sub,'initialization-or-failure-evidence',{'.json','.log','.jsonl','.npz','.png'},8_000_000)
for sub in ['grid_input_v1','demo50_working_n6','demo50_main_accepted1']:
 add(W/'initialization_review'/sub/'s07_1464832.png',role='user-visible-failed-grid')
# Source feedback actually used, persistent cases and runtime implementation, not SQLite/cache copies.
tree(R/'src/rink_feedback','continuous-feedback-source',{'.py','.json','.md'})
for f in (R/'src/rinkspace').glob('*feedback*.py'):add(f,role='continuous-feedback-source')
tree(R/'events/ankara_2026/feedback','continuous-feedback-persistent-cases',{'.json','.jsonl','.html','.md'})
tree(D/'events/ankara_2026/feedback','continuous-feedback-actual-chain',{'.json','.jsonl','.txt','.log'},2_000_000)
# Programme and rules; keep source and model identity records, not unrelated demo body/training/media.
for n in ['AGENTS.md','README.md','START_HERE.html','docs/VALIDATION.md','scripts/check_onedrive_paths.py','pyproject.toml']:
 add(R/n,role='project-entry-and-contract')
tree(R/'events/ankara_2026/programmes/okada_mei_sp/fit_joint9','task-status',{'.json','.html','.md'},3_000_000)
for f in (R/'calibration/program_tracking').glob('*.py'):add(f,role='demo-and-native-reader-source')
# User original package extracted directly with original member bytes, no nested redundant ZIP.
extras=[]
for name in ['Okada_Full9_Recovery_Codex_20261019.zip']:
 with zipfile.ZipFile(P/name) as z:
  for x in z.infolist():
   if not x.is_dir(): extras.append({'zip':str(P/name),'member':x.filename,'archive_path':'Original_Request/'+x.filename.split('/',1)[-1],'bytes':x.file_size,'role':'original-user-package'})
plan={'schema':'rinkspace.offline_audit_plan.v1','files':list(items.values()),'zip_members':extras}
(P/'okada_bundle_plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf-8')
print('PLAN',len(items),sum(x['bytes'] for x in items.values()),flush=True)
# Measure exact deflate level6 bytes per unique content without writing temporary data copies.
seen={}; groups={}; start=time.time()
for k,f in enumerate(plan['files']):
 h=hashlib.sha256(); c=zlib.compressobj(6,zlib.DEFLATED,-15); size=0
 with open(f['source_path'],'rb') as r:
  for b in iter(lambda:r.read(1024*1024),b''):h.update(b);size+=len(c.compress(b))
 size+=len(c.flush());f['sha256']=h.hexdigest();f['deflate_bytes']=size
 if f['sha256'] in seen:f['alias_of']=seen[f['sha256']]
 else:
  seen[f['sha256']]=f['archive_path'];g=groups.setdefault(f['role'],{'files':0,'raw':0,'compressed':0});g['files']+=1;g['raw']+=f['bytes'];g['compressed']+=size
 if k%100==0: print('MEASURE',k,len(plan['files']),round(time.time()-start,1),flush=True)
plan['measured_groups']=groups;plan['unique_payload_compressed_bytes']=sum(g['compressed'] for g in groups.values())
(P/'okada_bundle_plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf-8')
print('DONE',json.dumps(groups),plan['unique_payload_compressed_bytes'],flush=True)
