import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import sys,json
from pathlib import Path
import numpy as np
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'calibration/rinkfit/src'),str(root/'src')]
from rinkfit_joint import joint_replay as jr
from rinkfit_joint.native_baseline_init import Motion,_physical,_witnesses
from rinkfit_joint.io_utils import file_sha256
from rinkfit_start.native_camera import rotation
W=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');O=W/'current_ray_domain';O.mkdir(exist_ok=True)
model_file=W/'native_init_v1/model.json';model=jr.read_json(model_file);cg=jr.CameraGraph(jr.graph_from_joint(model));scene=jr.NativeScene(jr.as_event_view(model,'s01'));target=1464832;sid='s07';cam=cg.native_camera(sid);local=float(cg.local_seconds(sid,np.array([target],np.int64))[0])
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),'utf8')
def clean(x):
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,np.ndarray):return clean(x.tolist())
 if isinstance(x,np.generic):return clean(x.item())
 if isinstance(x,float) and not np.isfinite(x):return None
 return x

def qmin(c1,c2,s):
 r=np.minimum(1.,1+c1*s+c2*s*s);v=np.divide(-c1,2*c2,out=np.zeros_like(np.asarray(c1+s)),where=c2!=0)
 return np.minimum(r,np.where((c2>0)&(v>0)&(v<s),1+c1*v+c2*v*v,np.inf))
def fold(camera,logf,radius):
 z=np.asarray(logf)-np.log(camera.optics['f_ref']);k1=np.polynomial.polynomial.polyval(z,camera.optics['k1']);k2=np.polynomial.polynomial.polyval(z,camera.optics['k2']);s=np.asarray(radius)**2
 return np.minimum(qmin(k1,k2,s),qmin(3*k1,5*k2,s))-6*np.hypot(camera.optics['p1'],camera.optics['p2'])*radius

def pose(camera,t):
 q=camera.spline(t);z=q[...,2]-np.log(camera.optics['f_ref']);R=rotation(camera.b,q[...,1])@camera.R0@rotation(camera.n,q[...,0]);n=np.cross(camera.n,np.einsum('...ji,j->...i',R,camera.b));n/=np.linalg.norm(n,axis=-1)[...,None];D=np.broadcast_to(camera.d,(*np.shape(t),3)).copy();D[...,2]+=camera.head['pupil_linear']*z+camera.head['pupil_quadratic']*z*z;C=camera.P+np.einsum('...ji,...j->...i',R,D)+camera.a*n
 return q,R,C

def inverse(camera,uv,t):
 q,R,C=pose(camera,t);z=q[:,2]-np.log(camera.optics['f_ref']);f=np.exp(q[:,2]);pp=np.asarray(camera.optics['principal_point'])+z[:,None]*camera.optics['principal_linear'];eta=camera.optics['eta'];wanted=(uv-pp)/np.c_[f*np.exp(eta/2),f*np.exp(-eta/2)];k1=np.polynomial.polynomial.polyval(z,camera.optics['k1']);k2=np.polynomial.polynomial.polyval(z,camera.optics['k2']);p1=camera.optics['p1'];p2=camera.optics['p2'];xy=wanted.copy()
 def calc(v):
  x,y=v.T;r=x*x+y*y;L=1+k1*r+k2*r*r;A=k1+2*k2*r
  B=np.c_[x*L+2*p1*x*y+p2*(r+2*x*x),y*L+p1*(r+2*y*y)+2*p2*x*y]
  a=L+2*x*x*A+2*p1*y+6*p2*x;b=2*x*y*A+2*p1*x+2*p2*y;d=L+2*y*y*A+6*p1*y+2*p2*x
  return B,a,b,d
 for _ in range(50):
  B,a,b,d=calc(xy);e=B-wanted;det=a*d-b*b;step=np.c_[d*e[:,0]-b*e[:,1],a*e[:,1]-b*e[:,0]]/np.where(abs(det)>1e-12,det,1e-12)[:,None]
  length=np.linalg.norm(step,axis=1);step*=np.minimum(1.,.15/np.maximum(length,1e-30))[:,None];current=np.sum(e*e,axis=1);trial=xy-step
  for _ in range(12):
   bad=np.sum((calc(trial)[0]-wanted)**2,axis=1)>current
   if not bad.any():break
   step[bad]*=.5;trial[bad]=xy[bad]-step[bad]
  xy=trial
 B,a,b,d=calc(xy);err=np.linalg.norm((B-wanted)*np.c_[f*np.exp(eta/2),f*np.exp(-eta/2)],axis=1);r=np.linalg.norm(xy,axis=1);eig=.5*(a+d-np.sqrt((a-d)**2+4*b*b));ray=np.einsum('nji,nj->ni',R,np.c_[xy,np.ones(len(xy))])
 return q,C,ray,r,err,eig

N=907603;B=W/'g9_ice'
def mm(k,d,shape=None):return np.memmap(B/(k+'.bin'),dtype=d,mode='r',shape=shape or (N,))
pts=mm('native_pts','<i8');si=mm('shot_index','<u2');ad=mm('admission','u1');role=mm('fit_role','u1');mi=mm('material_index','<u4');uv=mm('uv','<f8',(N,2));ids=np.flatnonzero((pts==target)&(si==6)&(ad==1)&(role==1));sourceuv=np.asarray(uv[ids]);source_t=local+cam.tau*(sourceuv[:,1]/1079-.5);q,C,ray,r,inverr,eig=inverse(cam,sourceuv,source_t);fl04=fold(cam,q[:,2],.4);fl065=fold(cam,q[:,2],.65);flown=fold(cam,q[:,2],r);valid=inverr<1e-7;rows=[]
for j,i in enumerate(ids):
 label=model['materials'][int(mi[i])]['label'];ice=label.startswith('ice.');lam=-C[j,2]/ray[j,2];world=C[j]+lam*ray[j];inside=lam>0 and scene.containment(world[:2])<=1e-10
 rows.append(dict(row_index=int(i),material=label,source_UV=sourceuv[j],row_time=float(source_t[j]),ray_radius=r[j],inside_current_R04=bool(r[j]<=.4),inside_R065=bool(r[j]<=.65),inverse_error_px=inverr[j],inverse_valid=bool(valid[j]),local_Brown_min_eigenvalue=eig[j],Brown_no_fold_lower_R04=fl04[j],Brown_no_fold_lower_R065=fl065[j],Brown_no_fold_lower_required=flown[j],conditional_ice_world=world if ice else None,conditional_ice_inside=bool(inside) if ice else None))
world,records=jr.inventory(model);p0=cam.at(world,local);row=np.clip(p0['uv'][:,1],0,1079)
for _ in range(12):
 state=cam.at(world,local+cam.tau*(row/1079-.5));nr=np.clip(state['uv'][:,1],0,1079)
 if np.max(abs(nr-row))<1e-9:row=nr;break
 row=nr
state=cam.at(world,local+cam.tau*(row/1079-.5));pred=state['uv'];cert=cam.rs_certificate(world,local);visible=jr.render_visibility(cam,scene,world,records,local,pred);inside=np.isfinite(pred).all(1)&(pred[:,0]>=0)&(pred[:,0]<1920)&(pred[:,1]>=0)&(pred[:,1]<1080);positive=state['depth']>0;within04=state['ray_radius']<=.4;within065=state['ray_radius']<=.65;rs=np.abs(row-pred[:,1])<2e-8;matmask=np.zeros(len(world),bool);board=np.zeros(len(world),bool)
for rr in records:
 if rr['material_index']>=0:matmask[rr['begin']:rr['end']]=True;board[rr['begin']:rr['end']]=rr['board_material_surface']
def counts(mask):
 return dict(total=int(mask.sum()),positive_depth=int((mask&positive).sum()),inside_image_positive=int((mask&inside&positive).sum()),inside_image_radius_pass04=int((mask&inside&positive&within04).sum()),inside_image_radius_pass065=int((mask&inside&positive&within065).sum()),inside_image_RS_equation_pass=int((mask&inside&positive&rs).sum()),inside_image_physical_visible=int((mask&inside&positive&visible).sum()),inside_image_all_current_gates=int((mask&inside&positive&visible&rs&state['valid']&cert['certified']).sum()),inside_image_only_radius04_failed=int((mask&inside&positive&visible&rs&~within04).sum()),inside_image_R065_and_physical_visible=int((mask&inside&positive&visible&rs&within065).sum()),inside_image_hidden_even_without_radius=int((mask&inside&positive&~visible).sum()))
material=[]
for rr in records:
 if rr['material_index']<0:continue
 m=np.zeros(len(world),bool);m[rr['begin']:rr['end']]=True;material.append(dict(label=rr['label'],material_index=rr['material_index'],**counts(m)))
navmanifest=jr.read_json(W/'nav_8a28_v1/manifest.json');nav=np.load(navmanifest['output']['file']);npts=nav['native_pts'];numbers=nav['shot_number'];nR=nav['navigation_R_world_to_camera'];nC=nav['navigation_C_normalized'];nlogf=nav['navigation_log_f_native_pixels'];finite=np.isfinite(nR).all((1,2))&np.isfinite(nC).all(1)&np.isfinite(nlogf);wreports=[];arrays=[]
for sid,shot in model['shots'].items():
 if sid=='s01':continue
 ii=np.flatnonzero((numbers==int(sid[1:]))&finite);rig=model['rigs'][shot['rig_id']];m=Motion(model,[sid],numbers[ii],npts[ii]);nq=m.values(m.x);h=np.asarray(model['blocks'][rig['head_block']]['values']);o=np.asarray(model['blocks'][rig['optics_block']]['values']);X,targetuv,mask=_witnesses(scene,nR[ii],nC[ii],nlogf[ii],navmanifest['original_shared_calibrations'][navmanifest['rig_order'].index(shot['rig_id'])]);p,d,rad,Rcur,Ccur=_physical(nq,h,o,rig['camera'],X);camera=cg.native_camera(sid);fl=fold(camera,nq[:,2],.65);rm=np.max(np.where(mask,rad,0),axis=1);fr=fold(camera,nq[:,2],rm);arg=np.argmax(rm)
 wreports.append(dict(shot=sid,all_native=int((numbers==int(sid[1:])).sum()),finite_native=len(ii),witnesses=int(mask.sum()),current_Rmax=rig['camera']['radius_max'],current_witness_rmax=float(rm.max()),rmax_native_pts=int(npts[ii[arg]]),outside_R04=int((mask&(rad>.4)).sum()),outside_R065=int((mask&(rad>.65)).sum()),negative_depth=int((mask&(d<=0)).sum()),R065_brown_lower_min=float(fl.min()),R065_uncertified_frames=int((fl<=0).sum()),required_radius_brown_lower_min=float(fr.min()),required_radius_uncertified_frames=int((fr<=0).sum())))
 arrays.append((npts[ii],numbers[ii],rm,fl,fr))
np.savez(O/'full_native_witness_rays.npz',native_pts=np.concatenate([a[0]for a in arrays]),shot_number=np.concatenate([a[1]for a in arrays]),required_radius=np.concatenate([a[2]for a in arrays]),R065_brown_lower=np.concatenate([a[3]for a in arrays]),required_brown_lower=np.concatenate([a[4]for a in arrays]))
sumrows=[]
for typ in ('all','ice','board'):
 select=np.array([True if typ=='all' else rr['material'].startswith('ice.') if typ=='ice' else not rr['material'].startswith('ice.') for rr in rows]);good=select&valid
 sumrows.append(dict(kind=typ,source_rows=int(select.sum()),inverse_valid=int(good.sum()),inverse_failed=int((select&~valid).sum()),radius_max=float(r[good].max()) if good.any() else None,outside_R04=int((good&(r>.4)).sum()),outside_R065=int((good&(r>.65)).sum()),R065_brown_uncertified=int((good&(fl065<=0)).sum()),required_brown_uncertified=int((good&(flown<=0)).sum())))
report=dict(schema='rinkfit.current_model_ray_domain_readonly.v1',model=dict(path=str(model_file),sha256=file_sha256(model_file)),native_pts=target,source_rows=sumrows,source_Brown_R04_lower_min=float(fl04.min()),source_Brown_R065_lower_min=float(fl065.min()),source_ray_radius_range=[float(r[valid].min()),float(r[valid].max())],inventory=dict(all_materials=counts(matmask),board_materials=counts(matmask&board),ice_materials=counts(matmask&~board)),full_native_old_navigation_witnesses=wreports,no_fit_or_domain_or_UV_or_qualification_changed=True,visibility_not_a_source_qualification_change=True)
write(O/'source_rows.json',clean(rows));write(O/'material_visibility.json',clean(material));write(O/'report.json',clean(report));print(json.dumps(clean(report),ensure_ascii=False,indent=2))
