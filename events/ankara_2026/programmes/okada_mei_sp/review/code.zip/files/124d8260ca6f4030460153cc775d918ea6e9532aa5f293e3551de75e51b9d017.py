import ctypes as c, ctypes.wintypes as w, json,time,pathlib,subprocess,shutil
K=c.WinDLL('kernel32',use_last_error=True);P=c.WinDLL('psapi',use_last_error=True);S=c.c_size_t
class PE(c.Structure):
 _fields_=[('dwSize',w.DWORD),('cntUsage',w.DWORD),('pid',w.DWORD),('heap',S),('module',w.DWORD),('threads',w.DWORD),('ppid',w.DWORD),('priority',w.LONG),('flags',w.DWORD),('exe',w.WCHAR*260)]
class PMC(c.Structure):
 _fields_=[('cb',w.DWORD),('faults',w.DWORD)]+[(n,S) for n in ['peak_ws','ws','quota_peak_paged','quota_paged','quota_peak_nonpaged','quota_nonpaged','pagefile','peak_pagefile','private']]
class PI(c.Structure):
 _fields_=[('cb',w.DWORD)]+[(n,S)for n in ['commit','commit_limit','commit_peak','physical','available','cache','kernel','kernel_paged','kernel_nonpaged','pagesize']]+[(n,w.DWORD)for n in ['handles','processes','threads']]
class IOC(c.Structure):
 _fields_=[(n,c.c_ulonglong)for n in ['read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes']]
K.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD];K.CreateToolhelp32Snapshot.restype=w.HANDLE;K.Process32FirstW.argtypes=[w.HANDLE,c.POINTER(PE)];K.Process32NextW.argtypes=[w.HANDLE,c.POINTER(PE)];K.CloseHandle.argtypes=[w.HANDLE];K.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];K.OpenProcess.restype=w.HANDLE;P.GetProcessMemoryInfo.argtypes=[w.HANDLE,c.POINTER(PMC),w.DWORD];P.GetPerformanceInfo.argtypes=[c.POINTER(PI),w.DWORD];K.GetProcessIoCounters.argtypes=[w.HANDLE,c.POINTER(IOC)];K.GetProcessTimes.argtypes=[w.HANDLE,c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME)]
def ft(x):return ((int(x.dwHighDateTime)<<32)+int(x.dwLowDateTime))/1e7
def sample():
 pi=PI();pi.cb=c.sizeof(pi);assert P.GetPerformanceInfo(c.byref(pi),pi.cb);ps=pi.pagesize
 snap=K.CreateToolhelp32Snapshot(2,0);pe=PE();pe.dwSize=c.sizeof(pe);ok=K.Process32FirstW(snap,c.byref(pe));rows=[]
 while ok:
  h=K.OpenProcess(0x410,False,pe.pid)
  if h:
   pm=PMC();pm.cb=c.sizeof(pm);io=IOC();times=[w.FILETIME()for _ in range(4)]
   if P.GetProcessMemoryInfo(h,c.byref(pm),pm.cb):
    K.GetProcessIoCounters(h,c.byref(io));K.GetProcessTimes(h,*[c.byref(x)for x in times]);rows.append(dict(pid=pe.pid,ppid=pe.ppid,name=pe.exe,private_commit=pm.private,working_set=pm.ws,peak_working_set=pm.peak_ws,peak_commit=pm.peak_pagefile,page_fault_count=pm.faults,cpu_seconds=ft(times[2])+ft(times[3]),read_bytes=io.read_bytes,write_bytes=io.write_bytes,threads=pe.threads))
   K.CloseHandle(h)
  ok=K.Process32NextW(snap,c.byref(pe))
 K.CloseHandle(snap)
 return dict(utc=time.time(),system=dict(physical_total=pi.physical*ps,physical_available=pi.available*ps,commit=pi.commit*ps,commit_limit=pi.commit_limit*ps,commit_peak=pi.commit_peak*ps,cache=pi.cache*ps),processes=sorted(rows,key=lambda r:r['private_commit'],reverse=True))
out=pathlib.Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/perf');out.mkdir(exist_ok=True)
rows=[]
for i in range(6):
 r=sample();rows.append(r)
 with(out/'process_samples.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps(r)+'\n')
 if i<5:time.sleep(1)
print(json.dumps(dict(first=rows[0]['system'],last=rows[-1]['system'],top_processes=rows[-1]['processes'][:15]),ensure_ascii=False))
