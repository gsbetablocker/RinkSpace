import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json,subprocess,hashlib
import numpy as np,cv2
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');out=rec/'B1_actual_pixel_evidence'
if len(sys.argv)>1:
 from rinkfit_joint import joint_replay as jr
 from rinkfit_joint.joint_acceleration import install
 phase=sys.argv[1];model_file=rec/('shared_g9/initial_state/model.json' if phase=='before' else 'shared_g9/outer_0/finite_line_navigation_restart/accepted_state/model.json')
 q=jr.read_json(model_file);cg=jr.CameraGraph(jr.graph_from_joint(q));world,records=jr.inventory(q);scene=jr.NativeScene(jr.as_event_view(q,'s01'))
 target=out/phase;target.mkdir(parents=True,exist_ok=False)
 install(cg,model_file,target/'acceleration',world,Path('D:/CodexData/RinkSpace_Data/runs/okada_s1_r11/gpu_accel/line_bundle/code/compiled_camera'))
 raw=rec/'hist_short_v1/acquisition_v1/native/1347584.png';assert hashlib.sha256(raw.read_bytes()).hexdigest()=='ba1ae11a30c2c771061de5541fc6b62ee23f4cc2a86a972f480377a92fdcbeff'
 bgr=cv2.imread(str(raw));local=float(cg.local_seconds('s06',np.array([1347584],np.int64))[0]);camera=cg.native_camera('s06')
 uv,good,eq=jr.fast_native_project(camera,world,local);good&=jr.render_visibility(camera,scene,world,records,local,uv)
 im,metrics=jr.draw_fast(bgr,uv,good,records,f'{phase.upper()} source=105.280s PTS=1347584 SAME SOLVER MODEL / ALL MATERIALS')
 vals=q['blocks'][61]['values'];X=np.array([[vals[2],vals[3],0.]],np.float64);pred,valid,root_eq=jr.fast_native_project(camera,X,local)
 source=np.array([230.64343231096325,826.6318383012724]);p=pred[0]
 def point(x):return tuple(np.rint(x).astype(int))
 cv2.circle(im,point(source),10,(0,255,0),3);cv2.drawMarker(im,point(p),(0,0,255),cv2.MARKER_TILTED_CROSS,20,3);cv2.line(im,point(source),point(p),(0,165,255),2)
 error=float(np.linalg.norm(p-source));cv2.putText(im,f'B1 native error {error:.3f}px; VISIBILITY STILL FAILED',(40,1030),cv2.FONT_HERSHEY_SIMPLEX,.8,(0,0,255),2,cv2.LINE_AA)
 cv2.imwrite(str(target/'native_grid.png'),im)
 (target/'receipt.json').write_text(json.dumps(dict(model=str(model_file),model_sha256=hashlib.sha256(model_file.read_bytes()).hexdigest(),source_native_png=str(raw),PTS=1347584,source_time=105.28,source_uv=source.tolist(),actual_RS_uv=p.tolist(),actual_RS_error_px=error,actual_RS_valid=bool(valid[0]),root_equality_px=float(root_eq[0]),all_ice_board_ad_paths_and_ids=True,visibility_failure_retained=True,metrics=metrics),indent=2),'utf8')
else:
 out.mkdir(exist_ok=False)
 for phase in ('before','after'):subprocess.run([sys.executable,'-X','utf8','-B',__file__,phase],check=True)
 ims=[cv2.resize(cv2.imread(str(out/phase/'native_grid.png')),(1280,720),interpolation=cv2.INTER_AREA)for phase in ('before','after')]
 cv2.imwrite(str(out/'before_after.png'),np.concatenate(ims,axis=1))
 print(json.dumps(dict(image=str(out/'before_after.png'),before=json.loads((out/'before/receipt.json').read_text())['actual_RS_error_px'],after=json.loads((out/'after/receipt.json').read_text())['actual_RS_error_px'],whole_programme_fitted=False)),flush=True)
