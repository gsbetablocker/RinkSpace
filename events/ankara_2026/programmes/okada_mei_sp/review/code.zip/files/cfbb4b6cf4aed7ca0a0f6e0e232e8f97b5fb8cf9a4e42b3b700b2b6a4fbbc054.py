import json
from pathlib import Path
rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');state=rec/'motion_g3/candidate';model=json.loads((state/'model.json').read_text());cp=[]
with (state/'engineering_checkpoint.json').open() as f:
 for _ in range(8):f.readline()
 n=int(f.readline())
 for i,b in enumerate(model['blocks']):
  line=f.readline().strip();name,end=json.JSONDecoder().raw_decode(line);flag=line[end:].strip();v=list(map(float,f.readline().split()[1:]));cp.append(dict(name=name,values=v))
shadow={}
for sid,s in model['shots'].items():
 for target,c in zip(s['control_blocks'],s.get('control_coordinates',[dict(block=b,offset=0)for b in s['control_blocks']])):
  if target!=c['block'] or c['offset']!=0:shadow[target]=dict(shot=sid,source_block=c['block'],offset=c['offset'])
diffs=[]
for i,(c,b)in enumerate(zip(cp,model['blocks'])):
 if c['name']!=b['name']or c['values']!=b['values']:
  a=shadow.get(i);source_values=cp[a['source_block']]['values'][a['offset']:a['offset']+3] if a else None
  diffs.append(dict(block=i,name=b['name'],alias=a,candidate_expanded_equals_CP_source_slice=source_values==b['values'],max_abs_difference=max(abs(x-y)for x,y in zip(c['values'],b['values']))))
report=dict(schema='rinkfit.exact_engineering_checkpoint_model_alias_diagnosis.v1',physical_blocks=len(cp),mismatched_blocks=len(diffs),all_mismatches_are_derived_mirror_slots=all(d['alias']is not None and d['candidate_expanded_equals_CP_source_slice']for d in diffs),actual_CP_source_blocks_and_other_physical_values_unchanged=all(d['alias']is not None for d in diffs),differing_blocks=diffs,original_files_changed=False,source_qualification_granted=False)
(rec/'g3_cp_model_alias_diagnosis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='differing_blocks'}))
