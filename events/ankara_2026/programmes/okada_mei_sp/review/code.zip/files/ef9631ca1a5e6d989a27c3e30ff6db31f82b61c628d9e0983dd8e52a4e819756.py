import ctypes as c,json
from ctypes import wintypes as w
k=c.WinDLL('kernel32',use_last_error=True);p=c.WinDLL('psapi',use_last_error=True)
class E(c.Structure):_fields_=[('dwSize',w.DWORD),('cntUsage',w.DWORD),('th32ProcessID',w.DWORD),('th32DefaultHeapID',c.c_size_t),('th32ModuleID',w.DWORD),('cntThreads',w.DWORD),('th32ParentProcessID',w.DWORD),('pcPriClassBase',w.LONG),('dwFlags',w.DWORD),('szExeFile',w.WCHAR*260)]
class IO(c.Structure):_fields_=[(a,c.c_ulonglong)for a in ('ReadOperationCount','WriteOperationCount','OtherOperationCount','ReadTransferCount','WriteTransferCount','OtherTransferCount')]
class M(c.Structure):_fields_=[('cb',w.DWORD),('PageFaultCount',w.DWORD)]+[(a,c.c_size_t)for a in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
k.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD];k.CreateToolhelp32Snapshot.restype=w.HANDLE;k.Process32FirstW.argtypes=[w.HANDLE,c.POINTER(E)];k.Process32NextW.argtypes=[w.HANDLE,c.POINTER(E)];k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE;k.CloseHandle.argtypes=[w.HANDLE];k.GetProcessIoCounters.argtypes=[w.HANDLE,c.POINTER(IO)];p.GetProcessMemoryInfo.argtypes=[w.HANDLE,c.POINTER(M),w.DWORD]
s=k.CreateToolhelp32Snapshot(2,0);e=E();e.dwSize=c.sizeof(e);procs=[]
more=k.Process32FirstW(s,c.byref(e))
while more:
 procs.append((e.th32ProcessID,e.th32ParentProcessID,e.szExeFile));more=k.Process32NextW(s,c.byref(e))
k.CloseHandle(s);wanted={37164};changed=True
while changed:
 changed=False
 for pid,parent,name in procs:
  if parent in wanted and pid not in wanted:wanted.add(pid);changed=True
out=[]
for pid,parent,name in procs:
 if pid not in wanted:continue
 h=k.OpenProcess(0x410,False,pid);io=IO();mem=M();mem.cb=c.sizeof(mem)
 if h:
  k.GetProcessIoCounters(h,c.byref(io));p.GetProcessMemoryInfo(h,c.byref(mem),c.sizeof(mem));k.CloseHandle(h)
 out.append(dict(pid=pid,parent=parent,name=name,read_bytes=io.ReadTransferCount,write_bytes=io.WriteTransferCount,rss=mem.WorkingSetSize,peak_rss=mem.PeakWorkingSetSize))
print(json.dumps(out))
