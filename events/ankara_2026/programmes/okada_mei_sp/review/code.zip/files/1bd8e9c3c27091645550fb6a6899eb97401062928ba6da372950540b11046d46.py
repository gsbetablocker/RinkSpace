import sys,pathlib
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src'),str(root/'calibration/program_tracking')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
from rinkfit_joint.recovery_metrics import main
main(['--packet',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/g5_ice/packet.json','--states',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/metrics_g3_states.json','--out',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/metrics_g3'])
