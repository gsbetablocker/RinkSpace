import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import sys,json
from pathlib import Path
import numpy as np
R=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(R/'calibration/rinkfit/src'))
from rinkfit_joint.grid_baseline_init import FiniteCurveQuery,_physical
from rinkfit_joint.joint_model import as_event_view
from rinkfit_joint.io_utils import read_json,write_json
from rinkfit_start.native_scene import NativeScene,camera_from_event
W=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');m=read_json(W/'demo_grid_init_v1_main_accepted1/model.json');scene=NativeScene(as_event_view(m,'s01'));mi=np.array([142,143,145,144,149,158]);pi=np.zeros(6,int);s=np.array([.2,.5,.8,.13,.47,.81]);X=np.vstack([scene.world(int(i),0,np.array([ss]))[0]for i,ss in zip(mi,s)]);shot=m['shots']['s07'];rig=m['rigs']['main'];cam=camera_from_event(as_event_view(m,'s07'));q=np.broadcast_to(cam.spline(np.array([3.06]))[0],(6,3)).copy();q[:,:2]+=np.array(m['blocks'][shot['reference_angles_block']]['values']);h=np.array(m['blocks'][rig['head_block']]['values']);o=np.array(m['blocks'][rig['optics_block']]['values']);RR,C=_physical(q,h,o,rig['camera']);Y=np.einsum('nij,nj->ni',RR,X-C);target=Y[:,:2]/Y[:,2,None];query=FiniteCurveQuery(m,mi,pi,s,X);res=query.residual(q,h,o,rig['camera'],target,ray=True);report=dict(check='same-model legal line/circle carrier zero set',points=6,max_abs_native=float(np.max(abs(res))),all_finite=bool(np.isfinite(res).all()),full_fit_started=False);assert report['all_finite']and report['max_abs_native']<1e-7;write_json(W/'sampson_identity.json',report);print(json.dumps(report))
