from pathlib import Path
import sys,json,ast,numpy as np
sys.path.insert(0,'D:/OneDrive/codex_projs/RinkSpace/calibration/rinkfit/src')
from rinkfit_joint.baseline_auxiliary import packet_header,checked_array,array_items
from rinkfit_joint.io_utils import file_sha256,write_json
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');p=r/'g6_bound/packet.json';assert file_sha256(p)=='0d63cd94f0178449862a478bd4769c3fb2bfb373a504d4b50dbb8704906441cf';h=packet_header(p);first=904249;n=h['row_count'];assert n-first==287
model_path=Path('D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/fit_full_source_v98/generation_1/model.json');model=json.loads(model_path.read_text(encoding='utf8'));a={k:checked_array(h['arrays'][k],p.parent) for k in ('material_index','kind','path','stroke_pair_index','admission','fit_role')};assert np.all(a['admission'][first:]==1) and np.all(a['fit_role'][first:]==1) and np.all(a['stroke_pair_index'][first:]==-1)
for i in range(first,n):
 mat=model['materials'][int(a['material_index'][i])];assert len(mat['paths'])==1 and int(a['path'][i])==0;assert bool(mat['paths'][0].get('physical_point',False))==(int(a['kind'][i])==1)
queries=0;fresh_queries=0
for q in array_items(p,'queries'):
 queries+=1;fresh_queries+=q['row_index']>=first
assert fresh_queries==0
groups=0;group_rows=0;rank=0
for q in array_items(p,'groups'):
 if any(i>=first for i in q['rows']):
  assert all(i>=first for i in q['rows']);groups+=1;group_rows+=len(q['rows']);rank+=q['rank']
assert group_rows==287 and rank==0
runner=r/'run_v98_compare_g6_v1.py';ast.parse(runner.read_text());config=r/'v98_compare_g6_v1_config.json';cfg=json.loads(config.read_text());binary=r/'compare_build_g5_v1/joint_recovery_compare.exe';receipt=dict(schema='rinkfit.prepared_g6_v98_same_scope_comparison.v1',prepared_not_started=True,packet=dict(file=str(p),sha256=file_sha256(p)),model=dict(file=str(model_path),sha256=file_sha256(model_path)),runner=dict(file=str(runner),sha256=file_sha256(runner)),config=dict(file=str(config),sha256=file_sha256(config)),binary=dict(file=str(binary),sha256=file_sha256(binary)),raw_rows=n,new_qualified_rows_absent_from_historical_CP=287,new_fixed_entity_rows=int(np.sum(a['kind'][first:]==1)),new_finite_ice_rows=int(np.sum(a['kind'][first:]==0)),new_frozen_Query_rows=0,new_statistics_units=groups,new_statistics_rank=rank,original_frozen_Query_count=queries,single_existing_finite_material_path_verified=True,original_v98_state_not_modified=True,comparison_output=cfg['output'],semantics=dict(explicit='Exact historical CP auxiliaries for original matched IDs, plus explicitly masked fresh numerical seeds under fixed v98 physical model for287 new qualified sources.',independent_RS='Keep stored finite station and solve RS independently.',local_profile='Only frozen Query rows can re-solve local station,row,alpha on the same finite material path;287 new non-Query rows retain their initialized station.',statistics='All287 new sources have original unknown-noise rank-zero units; no synthetic W or statistics qualification.'),fit_started=False,large_replay_started=False)
write_json(r/'g6_v98_comparison_prepared.json',receipt);print(json.dumps(receipt))
