import json,pathlib,numpy as np
r=pathlib.Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');p=json.loads((r/'g4_entities/packet.json').read_text('utf8'));m=json.loads((r/'recovery_input_model.json').read_text('utf8'))
def a(k):
 d=p['arrays'][k];return np.memmap(d['file'],dtype=d['dtype'],offset=d.get('offset_bytes',0),mode='r',shape=tuple(d['shape']))
active=(a('admission')==1)&(a('fit_role')==1);si=a('shot_index');mi=a('material_index');pp=a('path');pts=a('native_pts');uv=a('uv');n=len(active);e=np.memmap(r/'motion_g2/initial_state/CP_explicit_metrics/explicit_error_native_uv.f64',dtype='<f8',mode='r',shape=(n,2));err=np.linalg.norm(e,axis=1);report={'shots':{},'worst':[]}
for j,s in enumerate(p['shot_ids']):
 mask=active&(si==j);v=err[mask];report['shots'][s]={'n':int(mask.sum()),'rms':float(np.sqrt(np.mean(v*v))),'max':float(np.max(v)),'over1e5':int(np.count_nonzero(v>1e5))}
for i in np.argsort(np.where(active&np.isfinite(err),err,-1))[-20:][::-1]:
 i=int(i);report['worst'].append(dict(index=i,shot=p['shot_ids'][int(si[i])],material=m['materials'][int(mi[i])]['label'],path=int(pp[i]),pts=int(pts[i]),uv=uv[i].tolist(),error=e[i].tolist(),row_id=p['source_row_ids'][i],station=float(a('station')[i])))
(r/'motion_g2/initialization_failure_diagnosis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8');(r/'runtime_packet_descriptor.json').write_text(json.dumps({'arrays':p['arrays'],'shot_ids':p['shot_ids'],'row_count':n},indent=2),'utf8');print(json.dumps(report,ensure_ascii=False))
