from pathlib import Path
import sys,json
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.qualified_scope_stats import repair_rankzero_source_provenance
r=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');report=repair_rankzero_source_provenance(r/'scope_g4/packet.json',r/'scope_full_ready')
print(json.dumps(report,ensure_ascii=False,indent=2))
