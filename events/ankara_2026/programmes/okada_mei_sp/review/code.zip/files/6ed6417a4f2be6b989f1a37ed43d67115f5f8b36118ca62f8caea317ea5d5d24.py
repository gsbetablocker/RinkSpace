import sys,json
from pathlib import Path
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.accepted_aux_prefix import repack_engineering_exact_candidate
rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
result=repack_engineering_exact_candidate(rec/'motion_g3/candidate',rec/'motion_g3_exact')
(rec/'motion_g3_exact/repack_execution.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result),flush=True)
