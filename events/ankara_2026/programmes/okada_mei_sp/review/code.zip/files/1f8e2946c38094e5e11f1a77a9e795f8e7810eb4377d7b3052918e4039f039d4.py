from pathlib import Path
import sys,json,numpy as np
sys.path.insert(0,'D:/OneDrive/codex_projs/RinkSpace/calibration/rinkfit/src')
from rinkfit_joint.baseline_auxiliary import packet_header,checked_array
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');p=r/'g5_ice/packet.json';h=packet_header(p);n=h['row_count'];a={k:checked_array(h['arrays'][k],p.parent) for k in ('admission','fit_role','shot_index','material_index','kind')};s=(a['admission']==1)&(a['fit_role']==1)&(a['shot_index']==h['shot_ids'].index('s01'));model=json.loads((r/'motion_g3/initial_state/model.json').read_text());labels=np.asarray([m['label'] for m in model['materials']],object)[a['material_index']];report={}
def mem(p,dtype,shape):return np.memmap(p,mode='r',dtype=dtype,shape=shape)
def stats(x):
 x=np.abs(np.asarray(x));x=x[np.isfinite(x)];return dict(n=len(x),RMS=float(np.sqrt(np.mean(x*x))),P95=float(np.quantile(x,.95)),max=float(x.max()))
for label,cp,rs in [('initial','initial_state','initial_independent_RS_state'),('candidate','candidate','independent_RS_state')]:
 root=r/'motion_g3';error=mem(root/cp/'CP_explicit_metrics/explicit_error_native_uv.f64','<f8',(n,2));eq=mem(root/cp/'CP_explicit_metrics/explicit_RS_equality.f64','<f8',(n,));valid=mem(root/rs/'raw_station_RS_valid.u8','u1',(n,));raw=mem(root/rs/'raw_station_RS_error_native_uv.f64','<f8',(n,2));item=dict(CP_RS_equality_px=stats(eq[s]),CP_Euclidean_error_px=stats(np.linalg.norm(error[s],axis=1)),raw_RS_Euclidean_error_px=stats(np.linalg.norm(raw[s&(valid==1)],axis=1)),RS_failed_rows=int(np.sum(s&(valid==0))),CP_RS_over_1e_6_px=int(np.sum(s&(np.abs(eq)>1e-6))),CP_RS_over_0p01_px=int(np.sum(s&(np.abs(eq)>.01))))
 item['by_family']={}
 for name,m in [('ice',np.char.startswith(labels.astype(str),'ice.')),('fixed_entity',a['kind']==1),('print',np.char.find(labels.astype(str),'.print.')>=0)]:
  rr=s&m;item['by_family'][name]=dict(rows=int(rr.sum()),CP_Euclidean_error_px=stats(np.linalg.norm(error[rr],axis=1)),raw_RS_Euclidean_error_px=stats(np.linalg.norm(raw[rr&(valid==1)],axis=1)))
 report[label]=item
mi=json.loads((r/'motion_g3/initial_state/model.json').read_text());mc=json.loads((r/'motion_g3/candidate/model.json').read_text());changed=[i for i,(a,b) in enumerate(zip(mi['blocks'],mc['blocks'])) if a['values']!=b['values']];shared=[i for i,b in enumerate(mi['blocks']) if not b['name'].startswith('shot/')];report['shared_blocks_unchanged']=all(mi['blocks'][i]['values']==mc['blocks'][i]['values'] for i in shared);report['shared_block_count']=len(shared);report['changed_block_count']=len(changed);report['changed_S01_blocks']=sum(mi['blocks'][i]['name'].startswith('shot/s01/') for i in changed);report['same_s01_scope_and_control_coordinates']=mi['shots']['s01']==mc['shots']['s01'];out=r/'g3_s01_RS_regression_summary.json';out.write_text(json.dumps(report,indent=2));print(json.dumps(report))
