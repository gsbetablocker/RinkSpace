from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(r'D:/OneDrive/codex_projs/RinkSpace');DATA=Path(r'D:/CodexData/RinkSpace_Data');W=DATA/'runs/okada_rec_1019'
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'calibration/program_tracking'),str(ROOT/'calibration/rinkfit/src')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
import numpy as np,cv2
from rinkspace.vision_programme_ice_review import ice_curve_inventory
from projection import project_fast

def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ref(p):return dict(file=str(Path(p).resolve()),sha256=sha(p))
def write(p,x):
 with Path(p).open('x',encoding='utf8')as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write(chr(10))
def main():
 begin=time.perf_counter();base=W/'ice_grid_nav8a28_v1';out=W/'ice_grid_nav8a28_normal_v1'
 if out.exists():raise FileExistsError('New immutable normal generation required')
 manifest_path=base/'manifest.json';m=read(manifest_path);cw=read(base/'crosswalk.json');N=m['frames'];M=m['points']
 if sha(m['crosswalk']['file'])!=m['crosswalk']['sha256']:raise ValueError('Crosswalk identity changed')
 for key in ('target_uv','station','crosswalk_index','frame_offsets','frame_native_pts','frame_navigation_kind'):
  if sha(m['fields'][key]['file'])!=m['fields'][key]['sha256']:raise ValueError('Base navigation array changed '+key)
 old=read(m['old_scene']['file']);oi={x['curve_id']:x for x in ice_curve_inventory(old)};pairs=cw['paired_paths']
 fields=m['fields'];arr={key:(np.memmap(f['file'],dtype=f['dtype'],mode='r',shape=tuple(f['shape']))if f['storage']=='raw_binary_C_order'else np.load(f['file'],mmap_mode='r',allow_pickle=False))for key,f in fields.items()if key in('target_uv','station','crosswalk_index','frame_offsets','frame_native_pts','frame_navigation_kind')}
 with np.load(W/'nav_8a28_v1/navigation.npz',allow_pickle=False)as a:
  oldcams=a['old_camera25_scene_units'];nR=a['navigation_R_world_to_camera'];nC=a['navigation_C_normalized'];nlog=a['navigation_log_f_native_pixels'];rig=a['rig_number'];L=float(a['normalization_L']);origin=a['normalization_origin'];pts=a['native_pts']
 if not np.array_equal(pts,arr['frame_native_pts']):raise ValueError('Native frame identity mismatch')
 templates={r:oldcams[np.flatnonzero((rig==r)&np.isfinite(oldcams[:,0]))[0]].copy()for r in range(3)}
 out.mkdir();normal_path=out/'normal.f64';valid_path=out/'normal_valid.u8';reason_path=out/'normal_reason.u8';valid_count=0;invalid_count=0;max_uv_replay=0.;max_orthogonal=0.;max_unit=0.;by_shot={};invalid_examples=[];written=0
 with normal_path.open('xb')as nf,valid_path.open('xb')as vf,reason_path.open('xb')as rf:
  for fi in range(N):
   lo,hi=map(int,arr['frame_offsets'][fi:fi+2]);n=hi-lo
   if not n:continue
   curveid=arr['crosswalk_index'][lo:hi];station=arr['station'][lo:hi];prev=np.empty((n,3));here=np.empty((n,3));after=np.empty((n,3))
   for ci in np.unique(curveid):
    hit=np.flatnonzero(curveid==ci);p=pairs[int(ci)];xyz=oi[p['curve_id']]['xyz'];last=len(xyz)-1;k=np.rint(station[hit]*last).astype(np.int64)
    if np.any(np.abs(station[hit]*last-k)>1e-9):raise ValueError('Base target is not a frozen dense curve sample')
    if p['current_path_kind']==1:
     if np.linalg.norm(xyz[0]-xyz[-1])>1e-9:raise ValueError('Declared circle dense curve is not closed')
     k=k%last;before=(k-1)%last;nxt=(k+1)%last
    else:before=np.maximum(0,k-1);nxt=np.minimum(last,k+1)
    prev[hit]=xyz[before];here[hit]=xyz[k];after[hit]=xyz[nxt]
   c=oldcams[fi].copy()
   if not np.isfinite(c).all():
    c=templates[int(rig[fi])].copy();c[:3]=nC[fi]*L+origin;c[3:6]=cv2.Rodrigues(nR[fi])[0].ravel();c[6:8]=nlog[fi]
   uv,depth=project_fast(c,np.concatenate([prev,here,after]));p0,p1,p2=np.split(uv,3);d0,d1,d2=np.split(depth,3);t=p2-p0;length=np.linalg.norm(t,axis=1);finite=np.isfinite(uv.reshape(3,n,2)).all(axis=(0,2))&(d0>.05)&(d1>.05)&(d2>.05);valid=finite&np.isfinite(length)&(length>1e-12);normal=np.zeros((n,2),np.float64);normal[valid]=np.c_[-t[valid,1],t[valid,0]]/length[valid,None];reason=np.where(valid,0,np.where(finite,2,1)).astype('u1')
   err=float(np.max(np.abs(p1-arr['target_uv'][lo:hi])));max_uv_replay=max(max_uv_replay,err)
   if err>1e-8:raise ValueError('Normal point does not reproduce base old target UV '+str(err))
   if valid.any():
    max_orthogonal=max(max_orthogonal,float(np.max(np.abs(np.sum(normal[valid]*t[valid]/length[valid,None],axis=1)))));max_unit=max(max_unit,float(np.max(np.abs(np.linalg.norm(normal[valid],axis=1)-1))))
   normal.astype('<f8').tofile(nf);valid.astype('u1').tofile(vf);reason.tofile(rf);written+=n;valid_count+=int(valid.sum());invalid_count+=int((~valid).sum())
   if(~valid).any()and len(invalid_examples)<20:invalid_examples.extend(dict(native_pts=int(pts[fi]),row=int(lo+j),reason=int(reason[j]))for j in np.flatnonzero(~valid)[:20-len(invalid_examples)])
   if fi%2000==0:print(json.dumps(dict(frame=fi,normal_rows=written,seconds=time.perf_counter()-begin)),flush=True)
 if written!=M:raise ValueError('Normal row denominator changed')
 fields=dict(fields)
 fields.update(normal=dict(dtype='<f8',shape=[M,2],storage='raw_binary_C_order',**ref(normal_path)),normal_valid=dict(dtype='u1',shape=[M],storage='raw_binary_C_order',**ref(valid_path)),normal_reason=dict(dtype='u1',shape=[M],storage='raw_binary_C_order',**ref(reason_path)))
 result=dict(m,schema='rinkfit.old_ice_pixel_layout_normal_navigation.v1',base_manifest=ref(manifest_path),fields=fields,normal_extractor=ref(__file__),normal_definition='unit 90-degree rotation of old renderer dense same-curve neighbor projected tangent; circle modulo closed unique samples; finite straight one-sided endpoint neighbor',normal_scope='numerical initializer same-entity rendered contour distance only; not an observed Query, source likelihood, covariance or identity qualification',normal_sign_convention='(-t_y,t_x); squared contour distance is sign invariant',normal_valid_count=valid_count,normal_invalid_count=invalid_count,normal_reason_codes={0:'valid_same_curve_projected_tangent',1:'nonfinite_or_nonforward_dense_neighbor_projection',2:'degenerate_projected_tangent'},invalid_normals_preserved_with_zero_vector_and_explicit_mask=True,normal_invalid_examples=invalid_examples,normal_target_UV_replay_max_abs_px=max_uv_replay,normal_tangent_orthogonality_max_abs=max_orthogonal,normal_unit_length_max_abs_error=max_unit,normal_added_bytes=M*18,normal_elapsed_seconds=time.perf_counter()-begin,all_base_array_bytes_and_UV_unchanged=True,full_navigation_denominator=M,consumer_must_report_invalid_normal_rows_without_claiming_them_as_satisfied=True)
 write(out/'manifest.json',result);print(json.dumps(dict(manifest=str(out/'manifest.json'),rows=M,valid=valid_count,invalid=invalid_count,target_replay_max_abs_px=max_uv_replay,unit_error=max_unit,orthogonality=max_orthogonal,added_bytes=M*18,seconds=result['normal_elapsed_seconds'])),flush=True)
if __name__=='__main__':main()
