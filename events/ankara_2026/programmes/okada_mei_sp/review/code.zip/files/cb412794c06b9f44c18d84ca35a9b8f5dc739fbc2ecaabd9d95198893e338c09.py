from pathlib import Path
import os,sys,json
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkspace.feedback_runtime import feedback_store,learn_source_review,atomic_json,file_sha,authenticate_refs
from rink_feedback.cycle import FeedbackCycle
from rink_feedback.core import _hash
from rinkspace.path_policy import guard_project_write
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');folder=rec/'S03_actual_pixel_evidence'
cfg=json.loads((rec/'camera_g9_config.json').read_text('utf-8-sig'));spec=cfg['source_camera_mode_navigation']
navpath=rec/'camera_g9/outer_0/source_camera_mode_navigation/receipt.json';nav=json.loads(navpath.read_text('utf-8-sig'))
reviewpath=rec/'hist_short_v1/ring_history_source_review.json';review=json.loads(reviewpath.read_text('utf-8-sig'))
visualpath=folder/'visual_review.json';visual=json.loads(visualpath.read_text('utf-8-sig'))
conclusionpath=folder/'conclusion.json';conclusion=json.loads(conclusionpath.read_text('utf-8-sig'))
diagpath=rec/'g9_actual_failures/R4_actual_navigation_conclusion.json';diag=json.loads(diagpath.read_text('utf-8-sig'))
assert nav['accepted'] is True and nav['source_packet_sha256']==spec['source_packet_sha256']
assert spec['shot_id']=='s03' and spec['target_native_pts']==744704 and len(spec['source_rows'])==41
assert nav['full_current_PHR_cost_candidate']<nav['full_current_PHR_cost_before']
assert visual['whole_programme_fitted'] is False and visual['source_images_and_UV_unchanged'] is True
assert review['statistics_unknown'] is True and review['user_approved_every_source_pixel'] is False
for ref in spec['source_evidence']:
 assert file_sha(ref['file'])==ref['sha256'],ref['file']
target=[r for r in spec['source_rows'] if r['native_pts']==744704]
assert len(target)==9 and all(r['source_row_id'] in review['accepted_source_row_ids'] for r in target)
assert all(r['physical_instance_identity_closed'] and r['actual_material_layer_identity_closed'] for r in review['finite_target_layer_identity_reviews'] if r['shot_id']=='s03')
source=dict(video_sha256=spec['source_clock']['source_video_sha256'],pts=744704,time_base='1/12800',coordinate_domain='native_pixels',native_hw=[1080,1920])
def ref(p,kind,independent=False,source_binding=source):
 return dict(path=str(p),sha256=file_sha(p),kind=kind,source=source_binding,current_frame=True,independent_of_model=independent)
native=ref(rec/'hist_short_v1/ring_acquisition_v1/native/744704.png','native_pixels',True)
evidence=[native,ref(reviewpath,'existing_exact_source_review',True),ref(visualpath,'existing_model_visual_review'),ref(conclusionpath,'actual_same_source_before_after'),ref(navpath,'accepted_production_navigation_receipt'),ref(diagpath,'actual_finite_source_navigation_diagnostic')]
authenticate_refs(evidence,root)
facts=dict(schema='rinkfit.S03_source_scoped_model_mismatch_episode.v1',
 authority='existing_assistant_native_source_review_and_actual_production_receipts; not_user_confirmation',
 source=source,shot_id='s03',camera_id='end',source_packet_sha256=spec['source_packet_sha256'],
 original_qualified_source_rows=spec['source_rows'],source_native_pts=[720896,729856,737792,744704],
 source_identity_basis=diag['source_instance_evidence'],
 actual_same_finite_circle_search=diag['same_circle_full_station_result'],
 conditional_geometry_counterexample=diag['same_source_counterexample'],
 conditional_geometry_was_production_accepted=False,
 actual_camera_navigation=dict(full_current_PHR_before=nav['full_current_PHR_cost_before'],full_current_PHR_after=nav['full_current_PHR_cost_candidate'],
 target_rows=9,target_true_RS_RMS_before_px=nav['diagnostic_native_pixel_RMS_before'],target_true_RS_RMS_after_px=nav['diagnostic_native_pixel_RMS_candidate'],
 original_constraint_debt_before=nav['original_constraint_debt_before'],original_constraint_debt_after=nav['original_constraint_debt_candidate'],
 tiny_original_pixel_rows=41,accepted=True),
 four_exposure_same_denominator_comparison=conclusion['comparisons'],
 remaining_visible_failure=visual['remaining_visible_failure'],
 source_UV_material_ID_and_qualification_changed=False,source_recalled=False,statistics_unknown=True,
 new_RGB_review_executed_by_this_registration=False,new_subpixel_position_verification_executed=False,
 user_confirmation_added=False,fit_started_or_resumed_by_this_registration=False,whole_programme_fitted=False,
 evidence_refs=evidence)
factsref=atomic_json(folder/'S03_camera_feedback_episode.json',facts)
evidence.append(dict(factsref,kind='source_scoped_episode_receipt',source=source,current_frame=True,independent_of_model=False))
finding=dict(event_id='ankara_2026',programme_id='okada_mei_sp',camera_id='end',source=source,
 entity_ids=['ice.R4:middle','ice.R4:outer'],signal_type='source_supported_camera_model_mismatch',
 problem_key='same_R4_four_exposures_local_camera_drift',
 observation_ids=[r['source_dataset_id']+'::'+r['source_row_id'] for r in target],
 context_tags=['fit_checkpoint','native_source_recheck','R4','material_boundary','model_mismatch','camera_navigation'],
 evidence_refs=evidence,observation_snapshot_sha256=spec['source_packet_sha256'],
 checkpoint_state_token_before=nav['original_constraint_debt_before']['state_token'],
 checkpoint_state_token_after=nav['original_constraint_debt_candidate']['state_token'],
 review_scope=dict(shot_id='s03',native_pts=744704,target_source_rows=9,all_same_source_anchor_rows=41,
 source_anchor_native_pts=[720896,729856,737792],row_indices=[r['row_index'] for r in target]),
 diagnostic=dict(numerical_navigation_improved_but_not_recovered=True,target_actual_RS_RMS_px=nav['diagnostic_native_pixel_RMS_candidate'],
 interpretation_is_not_source_qualification=True,remaining_visual_failure=visual['remaining_visible_failure']))
with feedback_store(root,'ankara_2026') as store:
 ticket=FeedbackCycle(store).checkpoint('okada_rec_1019_S03_camera_mode_v14_episode',[finding])
findingid=ticket['tasks'][0]['finding_id']
checks={}
for name,value in [
 ('semantic_class','existing reviewed static physical ice target material interface; no person, caption or reflection admitted'),
 ('physical_instance','existing assistant-reviewed right-end R4, same source instance across four official exposures by original rink topology and ISU-SKATING.COM / ALL SKATING advertisement adjacency; not a new user R4 signature'),
 ('measurement_operator','original R4 middle white-ring/outer-fill interface and outer-fill/bright-ice interface; original finite circular material paths retained, no line substitute, radius ratio or concentricity proof'),
 ('visibility','only the nine existing accepted visible target material rows at native PTS744704; existing shoe/shadow/ambiguous-interface rejections remain rejected')]:
 checks[name]=dict(status='verified',value=value,evidence_refs=[native['sha256'],file_sha(reviewpath)],
  authority='existing assistant exact-source native review; no fresh RGB read in this registration')
checks['position']=dict(status='unknown',value='Original frozen UV retained; no new independent subpixel remeasurement or uncertainty certificate was performed by this registration. This does not revoke existing source qualification.',
 evidence_refs=[native['sha256'],file_sha(reviewpath)],existing_source_UV_retained=True,existing_source_qualification_unchanged=True)
lesson=dict(summary='同一已闭合靶圈跨连续原片曝光大残差时，先区分有限station导航失败与局部相机漂移；不能移动共享圈破坏前帧或让原UV迁就模型。',
 reader_check='declared_target_material_interface',
 solver_check='refine_joint_source_camera_mode_navigation_with_complete_current_PHR_acceptance_and_full_same_source_replay',
 current_source_reread_required=True,source_identity_or_pixels_transferred_to_future_frame=False,
 UV_or_observation_reinstallation_authorized=False,source_qualification_granted=False,statistics_unknown=True,
 scope='ankara_2026 / exact official O6j8L8TmfKo / end / s03 R4; target744704 with anchors720896,729856,737792',
 diagnostic_order=['Keep original UV/material/operator/qualification and inspect exact native source plus neighbour advertisements.',
 'Search only the original finite station support; a valid RS root or a large residual is not identity evidence.',
 'Check all same-instance source exposures before moving shared geometry; one-frame geometry improvement can destroy earlier exposures.',
 'Use source-supported increments of the existing camera function and affected legal auxiliaries as a numerical proposal only; retain complete original PHR and rollback.',
 'Compare all source exposures, original constraints and whole-scope rendering; this episode still has target RMS79.959px, one231.224px source error, worsened anchor RMS and Ad1/board-top visible errors.'],
 no_direct_fit_launch_authorized_by_case=True,whole_programme_recovery_claimed=False,
 no_new_user_confirmation=True,no_new_position_truth_or_statistics_certificate=True)
# Compute and check the exact durable OneDrive destination before the production helper writes it.
dimensions=['semantic_class','physical_instance','measurement_operator','visibility']
scope=dict(event_id='ankara_2026',source_video_sha256=source['video_sha256'],camera_id='end',entity_ids=finding['entity_ids'])
tags=sorted(set(finding['context_tags']+['model_mismatch','source_recheck']))
claims={n:{k:v for k,v in checks[n].items() if k not in {'evidence_refs','source','evidence_id'}} for n in dimensions}
pattern=dict(scope=scope,resolution_type='model_mismatch',verified_dimensions=dimensions,semantic_claims=claims,tags=tags,lesson=lesson)
expected_caseid='lesson_'+_hash(pattern)[:24]
casepath=guard_project_write(root/'events/ankara_2026/feedback/learned'/(expected_caseid+'.v1.json'),project_root=root)
assert len(str(casepath).encode('utf-16-le'))//2<260 and all(len(x.encode('utf-16-le'))//2<=255 for x in casepath.parts)
result=learn_source_review(project=root,event_id='ankara_2026',finding_id=findingid,source=source,
 checks=checks,evidence_refs=evidence,resolution_type='model_mismatch',lesson=lesson)
assert result['learned_case']['case_id']==expected_caseid
assert result['resolution']['unresolved_dimensions']==['position']
assert result['learned_case']['case']['fit_admissible'] is False and result['learned_case']['case']['training_eligible'] is False
receipt=dict(schema='rinkfit.S03_source_camera_feedback_registration.v1',finding_id=findingid,
 production_feedback_result=result,source_episode=factsref,durable_advisory_case=str(casepath),
 original_qualification_and_UV_preserved=True,statistics_unknown=True,source_qualification_reissued=False,
 model_or_fit_mutated=False,new_RGB_read_or_user_confirmation_claimed=False,
 partial_API_action_meaning='keep_unknown applies only to new independent position truth/adapter promotion; existing admitted source means and qualification are untouched',
 future_use='source-scoped advisory current-source review and solver diagnosis only; no UV transfer, qualification, direct fit launch or full-programme success claim')
atomic_json(folder/'S03_camera_feedback_resolution.json',receipt)
print(json.dumps(dict(finding_id=findingid,case_id=expected_caseid,resolution_id=result['resolution']['resolution_id'],
 learned=True,verified_dimensions=result['resolution']['verified_dimensions'],unknown=result['resolution']['unresolved_dimensions'],
 observation_action=result['observation_action'],case_file=str(casepath),receipt=str(folder/'S03_camera_feedback_resolution.json'),
 production_receipt=result['receipt'],fit_mutated=False),ensure_ascii=False))
