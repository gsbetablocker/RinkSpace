import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json,time
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.joint_solver import rebind_explicit_nuisance
from rinkfit_joint.io_utils import write_json,file_sha256
rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');src=rec/'g6_ice/packet.json';state=rec/'motion_g3_exact/candidate';out=rec/'g6_bound/packet.json'
start=time.monotonic()
result=rebind_explicit_nuisance(src,state,out)
write_json(out.parent/'binding_execution.json',dict(schema='rinkfit.actual_engineering_aux_prefix_binding.v1',actual_pid=os.getpid(),elapsed_seconds=time.monotonic()-start,result=result,source_qualification_issued=False,MC_started=False,fit_started=False))
print(json.dumps(result),flush=True)
