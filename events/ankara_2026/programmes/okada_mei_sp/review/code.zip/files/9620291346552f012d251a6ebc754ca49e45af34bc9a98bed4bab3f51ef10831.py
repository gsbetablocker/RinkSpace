from pathlib import Path
import ast,json,sys,sqlite3,hashlib
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.io_utils import file_sha256,write_json
r=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a');out=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
p=r/'board_physical_requalification_parallel_v1/partial_manifest.json';v=json.loads(p.read_text());db=out/'scope_g1/qualification.sqlite3';c=sqlite3.connect('file:'+db.as_posix()+'?mode=ro',uri=True)
assert c.execute('select count(*) from rows where inventory is not null and mask is not null').fetchone()[0]==v['raw_original_rows']
assert c.execute('select count(*) from rows').fetchone()[0]==v['raw_original_rows']
pts=sorted(row[0]for row in c.execute('select distinct pts from rows'));assert len(pts)==v['completed_exposures'];c.close()
def ref(f):return dict(file=str(f),sha256=file_sha256(f))
write_json(out/'scope_g1/prepared_index.json',dict(schema='rinkfit.verified_partial_qualification_index.v1',primary_audit=ref(p),mask_provenance=ref(r/'board_legacy_mask_provenance_v1/manifest.json'),source_scope=v['source_scope'],database=ref(db),closed_native_pts=pts))
ast.parse((root/'calibration/rinkfit/src/rinkfit_joint/qualified_scope.py').read_text());print('prepared exact-index cache verified',len(pts))
