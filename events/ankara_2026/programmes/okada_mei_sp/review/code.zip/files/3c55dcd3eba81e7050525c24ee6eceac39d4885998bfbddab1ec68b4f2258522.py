from pathlib import Path
import sys,json,hashlib,time
from collections import Counter
ROOT=Path(r'D:/OneDrive/codex_projs/RinkSpace');DATA=Path(r'D:/CodexData/RinkSpace_Data');W=DATA/'runs/okada_rec_1019'
sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'calibration/program_tracking'),str(ROOT/'calibration/rinkfit/src')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
import numpy as np,cv2
from calibration.program_tracking.render_result import fixed_scene_paths
from rinkfit_joint.role_guard import FrameRoleGuard

def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ref(p):return dict(file=str(Path(p).resolve()),sha256=sha(p))
def write(p,x):
 with Path(p).open('x',encoding='utf8')as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write(chr(10))
def normalized_chart(x):
 mean=x.mean(0);d=np.mean(np.linalg.norm(x-mean,axis=1));s=np.sqrt(2.)/d;T=np.asarray([[s,0,-s*mean[0]],[0,s,-s*mean[1]],[0,0,1.]])
 return (x-mean)*s,T

def four_point_h(X,U):
 x,tx=normalized_chart(X);u,tu=normalized_chart(U);A=np.zeros((8,8));b=np.zeros(8)
 for i,((a,c),(q,r))in enumerate(zip(x,u)):
  A[2*i]=[a,c,1,0,0,0,-q*a,-q*c];A[2*i+1]=[0,0,0,a,c,1,-r*a,-r*c];b[2*i:2*i+2]=[q,r]
 z=np.linalg.solve(A,b);H=np.linalg.solve(tu,np.r_[z,1.].reshape(3,3))@tx;H/=H[2,2];return H,float(np.linalg.cond(A))
def main():
 start=time.perf_counter();out=W/'screen_grid_probe_v1'
 if out.exists():raise FileExistsError(out)
 initial_path=W/'screen_grid_demo50_s2_v1/initial_state.json';m=read(initial_path);top=read(m['topology']['file'])
 if sha(m['topology']['file'])!=m['topology']['sha256']:raise ValueError('Original direct topology identity changed')
 scene_path=m['old_scene_reference']['file'];scene=read(scene_path)
 if sha(scene_path)!=m['old_scene_reference']['sha256']:raise ValueError('Old fixed virtual grid geometry identity changed')
 oldpaths=fixed_scene_paths(scene,draw_grid=True);ice=[(i,k,x)for i,(k,x)in enumerate(oldpaths)if k in('grid','marking')];xyz=np.concatenate([x for i,k,x in ice]);V=len(xyz)
 if V!=m['vertices_per_frame']:raise ValueError('Original direct vertex identity changed')
 for (ri,k,x),p in zip(ice,top['paths']):
  if p['original_renderer_path_index']!=ri or hashlib.sha256(np.ascontiguousarray(x,dtype='<f8').tobytes()).hexdigest()!=p['original_world_vertex_bytes_sha256']:raise ValueError('Original path vertex identity changed')
 L=194.46873526395436;origin=np.zeros(3);world=xyz[:,:2]/L;grid_vertex=np.zeros(V,bool)
 for p in top['paths']:
  if p['kind']=='grid':grid_vertex[p['vertex_begin']:p['vertex_end']]=True
 def load(key):
  a=m['fields'][key];return np.load(a['file'],mmap_mode='r',allow_pickle=False)if a['storage']=='npy_memmap'else np.memmap(a['file'],dtype=a['dtype'],mode='r',shape=tuple(a['shape']))
 uv=load('screen_uv');flags=load('vertex_mask_bits');pts=load('frame_native_pts');shot=load('frame_shot_number');F=len(pts);roles_path=DATA/'runs/okada_joint9_1018a/roles/frame_roles.json';guard=FrameRoleGuard(roles_path)
 ids=np.full((F,4),-1,'<i4');X=np.full((F,4,2),np.nan);U=np.full((F,4,2),np.nan);H=np.full((F,3,3),np.nan);valid=np.zeros(F,'u1');allowed=np.zeros(F,'u1');reason=np.ones(F,'u1');visible_count=np.zeros(F,'<i4');area=np.zeros(F);condition=np.full(F,np.nan);full_error=np.full(F,np.nan);visible_error=np.full(F,np.nan);full_relative=np.full(F,np.nan);frames=[];diagnostic=[];counts=Counter()
 for fi in range(F):
  p=int(pts[fi]);sid='s%02d'%int(shot[fi])
  try:guard.assert_training_pixels([p],shot_id=sid);allowed[fi]=1
  except ValueError:pass
  vv=np.flatnonzero(grid_vertex&((flags[fi]&7)==7));visible_count[fi]=len(vv)
  if len(vv)<4:reason[fi]=1;counts['less_than_4_visible_grid_vertices']+=1;continue
  u=np.asarray(uv[fi,vv]);hull=cv2.convexHull(np.asarray(u,np.float32),returnPoints=False).ravel();hu=u[hull];a=int(hull[np.argmin(hu[:,0]+hu[:,1])]);b=int(hull[np.argmax(np.sum((hu-u[a])**2,axis=1))]);ab=u[b]-u[a];crossab=ab[0]*(u[:,1]-u[a,1])-ab[1]*(u[:,0]-u[a,0]);c=int(np.argmax(np.abs(crossab)))
  ac=u[c]-u[a];bc=u[c]-u[b];area_ab=np.abs(crossab);area_ac=np.abs(ac[0]*(u[:,1]-u[a,1])-ac[1]*(u[:,0]-u[a,0]));area_bc=np.abs(bc[0]*(u[:,1]-u[b,1])-bc[1]*(u[:,0]-u[b,0]));minarea=np.minimum(np.minimum(area_ab,area_ac),area_bc);minarea[[a,b,c]]=0.;d=int(np.argmax(minarea));area[fi]=minarea[d]
  if not np.isfinite(area[fi])or area[fi]<=1e-6:reason[fi]=2;counts['no_nondegenerate_visible_quad']+=1;continue
  vi=vv[[a,b,c,d]];x=np.asarray(world[vi]);target=np.asarray(uv[fi,vi]);
  try:h,cond=four_point_h(x,target)
  except np.linalg.LinAlgError:reason[fi]=3;counts['singular_four_point_layout']+=1;continue
  ids[fi]=vi;X[fi]=x;U[fi]=target;H[fi]=h;condition[fi]=cond;valid[fi]=1;reason[fi]=0
  # Deterministic four-point homography arithmetic replay, no camera model or optimization is involved.
  q=np.c_[world,np.ones(V)]@h.T
  with np.errstate(divide='ignore',invalid='ignore'):prediction=q[:,:2]/q[:,2:3]
  actual=np.asarray(uv[fi]);finite=np.isfinite(actual).all(1)&np.isfinite(prediction).all(1);diff=np.max(np.abs(prediction[finite]-actual[finite]),axis=1);full_error[fi]=float(np.max(diff));full_relative[fi]=float(np.max(diff/(1.+np.max(np.abs(actual[finite]),axis=1))));onscreen=finite&((flags[fi]&7)==7);visible_error[fi]=float(np.max(np.abs(prediction[onscreen]-actual[onscreen])))if onscreen.any()else 0.
  record=dict(shot_id=sid,native_pts=p,frame_role_allows_numerical_navigation=bool(allowed[fi]),world_xy=x.tolist(),target_uv=target.tolist(),source_vertex_index=vi.tolist(),source_screen_grid_frame_index=fi,source_target_values_are_unmodified=True)
  if allowed[fi]:frames.append(record)
  else:counts['protected_frames_retained_not_in_navigation_objective']+=1
  if fi%1500==0:print(json.dumps(dict(frame=fi,valid_probes=int(valid.sum()),eligible_frames=len(frames),seconds=time.perf_counter()-start)),flush=True)
 counts.update(valid_frames=int(valid.sum()),invalid_frames=int((valid==0).sum()),eligible_navigation_frames=len(frames),protected_total=int((allowed==0).sum()));out.mkdir()
 arrays=dict(native_pts=np.asarray(pts),shot_number=np.asarray(shot),source_vertex_index=ids,world_xy=X,target_uv=U,H_normalized_world_xy_to_native=H,probe_valid=valid,frame_role_allows_numerical_navigation=allowed,reason=reason,visible_grid_vertex_count=visible_count,minimum_quad_triangle_twice_area_px2=area,normalized_four_point_system_condition=condition,full_vertex_replay_max_abs_px=full_error,visible_vertex_replay_max_abs_px=visible_error,full_vertex_replay_max_relative=full_relative)
 fields={}
 for key,a in arrays.items():
  file=out/(key+'.npy')
  with file.open('xb')as f:np.save(f,a,allow_pickle=False)
  fields[key]=dict(dtype=str(a.dtype),shape=list(a.shape),storage='npy_memmap',**ref(file))
 summary=dict(schema='rinkfit.direct_screen_grid_probe_evidence.v1',initial_screen_grid_state=ref(initial_path),source_topology=m['topology'],old_grid_coordinate_source=m['old_scene_reference'],world_xy_gauge='old frozen Demo scene x/y divided by L=194.46873526395436, origin=[0,0,0]; fixed virtual plane coordinates, not physical feature correspondences or metre measurements',normalization=dict(L=L,origin=origin.tolist()),source_vertex_selection='four original visible grid vertices with large spread; deterministic farthest pair/maximum triangle/minimum four-triangle area; no original direct state point changed or removed',homography_operation='normalized 4-point 8x8 linear algebra only, not a camera fit or new clock conversion',fields=fields,frames=F,counts=dict(counts),reason_codes={0:'valid_original_visible_four_point_probe',1:'less_than_4_visible_original_grid_vertices',2:'no_nondegenerate_quad',3:'singular_four_point_algebra'},full_direct_initial_state_retained_vertices=m['total_screen_vertices'],replay_denominator_per_frame=V,maximum_visible_replay_abs_px=float(np.nanmax(visible_error)),maximum_all_vertex_replay_abs_px=float(np.nanmax(full_error)),maximum_all_vertex_replay_relative=float(np.nanmax(full_relative)),permitted_navigation_probe_count=len(frames)*4,source_W_Query_or_qualification_changed=False,current_camera_or_S01_modified=False,numerical_initialization_only=True,source_observation=False,frame_roles=ref(roles_path),extractor=ref(__file__),elapsed_seconds=time.perf_counter()-start)
 evidence_path=out/'layout_evidence.json';write(evidence_path,summary)
 source_packet=W/'g9_bound/packet.json';spec=dict(schema='rinkfit.fixed_screen_plane_navigation.v1',numerical_initialization_only=True,source_observation=False,source_packet_sha256=sha(source_packet),initial_screen_grid_state=ref(initial_path),homography_layout_evidence=ref(evidence_path),world_xy_gauge=summary['world_xy_gauge'],pixel_scale=1.0,pixel_scale_is_explicit_numerical_preconditioning_not_source_sigma=True,frames=frames,source_vertex_index_is_original_direct_state_identity=True,original_full_G9_native_objective_unchanged=True,all_original_direct_initial_points_retained=True,protected_frames_not_promoted=True)
 write(out/'navigation_spec.json',spec);print(json.dumps(dict(spec=str(out/'navigation_spec.json'),evidence=str(evidence_path),frames=F,counts=dict(counts),visible_replay_max=summary['maximum_visible_replay_abs_px'],full_replay_max=summary['maximum_all_vertex_replay_abs_px'],full_replay_relative=summary['maximum_all_vertex_replay_relative'],seconds=summary['elapsed_seconds'])),flush=True)
if __name__=='__main__':main()
