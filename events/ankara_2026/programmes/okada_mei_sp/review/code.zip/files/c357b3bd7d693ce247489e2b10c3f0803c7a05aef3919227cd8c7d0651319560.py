from pathlib import Path
import sys,json,hashlib
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.io_utils import file_sha256,write_json
from rinkfit_joint.packet_storage import write_packet
from rinkfit_joint.board_source_qualification_guard import assert_board_material_source_qualification
r=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');parent=r/'scope_fast2/packet.json';p=json.loads(parent.read_text());out=r/'scope_ready';out.mkdir(exist_ok=False)
rawref=dict(file=str(parent),sha256=file_sha256(parent),role='immutable_parent_raw_source_ledger_not_source_qualification')
fixed=[]
for g in p['groups']:
 if g.get('statistic_kind')=='constraint_only_unknown_noise' and not g.get('unknown_noise_source_refs'):
  g['unknown_noise_source_refs']=[rawref];fixed.append(g['id'])
# The source compiler changed only rank-zero provenance serialization. Source
# evidence and exact raw membership remain the already checked original bytes.
certpath=Path(p['board_material_source_qualification']['file']);cert=json.loads(certpath.read_text())
cert['consumer_module_ref']=dict(file=str(root/'calibration/rinkfit/src/rinkfit_joint/qualified_scope.py'),sha256=file_sha256(root/'calibration/rinkfit/src/rinkfit_joint/qualified_scope.py'))
cert['rankzero_provenance_serialization_parent_certificate']=p['board_material_source_qualification']
write_json(out/'certificate.json',cert)
p['board_material_source_qualification']=dict(file=str(out/'certificate.json'),sha256=file_sha256(out/'certificate.json'))
p['rankzero_provenance_serialization_parent_packet']=rawref
write_packet(out/'packet.json',p)
assert_board_material_source_qualification(p,out/'packet.json')
write_json(out/'report.json',dict(schema='rinkfit.rankzero_source_reference_serialization_repair.v1',parent_packet=rawref,packet=dict(file=str(out/'packet.json'),sha256=file_sha256(out/'packet.json')),repaired_groups=len(fixed),group_ids=fixed,raw_arrays_ID_UV_PTS_membership_statistics_W_and_rank_unchanged=True,physical_source_guard_passed=True,numerical_auxiliary_and_domain_checks_pending=True))
print(json.dumps(dict(packet=str(out/'packet.json'),sha256=file_sha256(out/'packet.json'),repaired_groups=len(fixed),active=p['active_rows']),ensure_ascii=False))
