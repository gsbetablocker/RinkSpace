import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import sys,json,copy
from pathlib import Path
import numpy as np
R=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(R/'calibration/rinkfit/src'))
from rinkfit_joint.io_utils import read_json,write_json,file_sha256,object_sha256
from rinkfit_joint.joint_model import as_event_view
from rinkfit_joint.joint_replay import inventory
from rinkfit_start.native_scene import camera_from_event
W=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');source=Path('D:/CodexData/RinkSpace_Data/runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/navigation_model.json');out=W/'grid_input_v1';assert not out.exists()
a=read_json(source);b=copy.deepcopy(a);assert a['rigs']['main']['camera']['radius_max']==.4;b['rigs']['main']['camera']['radius_max']=.65
certs={}
for sid,s in b['shots'].items():
 if s['rig_id']=='main':
  certs[sid]=camera_from_event(as_event_view(b,sid)).optical_domain_certificate()
assert all(c['passed']for c in certs.values()),certs
assert a['blocks']==b['blocks'] and a['materials']==b['materials'] and a['shots']==b['shots']
x,records=inventory(a);probes=np.array([x[r['begin']]for r in records if r['material_index']>=0]);ca=camera_from_event(as_event_view(a,'s01'));cb=camera_from_event(as_event_view(b,'s01'));s=a['shots']['s01'];times=(np.arange(s['scope']['first_pts'],s['scope']['last_pts']+1,256)-s['time_origin_pts'])/12800.;times=(times[:,None]+ca.tau*(np.array([0.,539.5,1079.])/1079-.5)).ravel();exact=True;delta=0.;count=0;newvalid=0
for begin in range(0,len(times),64):
 t=times[begin:begin+64,None];p=ca.at(probes[None,:,:],t);q=cb.at(probes[None,:,:],t);finite=np.isfinite(p['uv'])&np.isfinite(q['uv']);delta=max(delta,float(np.max(np.where(finite,abs(p['uv']-q['uv']),0))));exact &= np.array_equal(p['uv'],q['uv'],equal_nan=True);count+=p['valid'].size;newvalid+=int((q['valid']&~p['valid']).sum())
assert exact and delta==0
meta=dict(schema='rinkfit.current_input_confirmed_ray_domain_repair.v1',input_model=dict(path=str(source),sha256=file_sha256(source)),main_before=.4,main_after=.65,current_input_control_hull_certificates=certs,certificate_source='current input NativeCamera.optical_domain_certificate; not native_init_v1 or old certificate',all_numeric_blocks_and_material_geometry_unchanged=True,S01_controls=1252,S01_native_exposures=1248,S01_row_time_positions=[0.,539.5,1079.],S01_projection_checks=count,S01_UV_bitwise_equal=exact,S01_maximum_UV_delta_px=delta,S01_additional_valid_off_domain_probes=newvalid,source_UV_W_Query_qualification_modified=False,engineering_PHR_identity_unchanged_claimed=False,full_source_scope_preserved=True)
b['joint_ray_domain_extension']=meta;b['paired_grid_domain_input']=meta
out.mkdir();write_json(out/'model.json',b);meta['output_model']=dict(path=str(out/'model.json'),sha256=file_sha256(out/'model.json'));write_json(out/'receipt.json',meta);print(json.dumps(meta,ensure_ascii=False))
