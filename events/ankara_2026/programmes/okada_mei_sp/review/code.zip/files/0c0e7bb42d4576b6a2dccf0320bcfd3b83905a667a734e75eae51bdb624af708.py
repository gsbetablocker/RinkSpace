from pathlib import Path
import sys,json,numpy as np
sys.path.insert(0,'D:/OneDrive/codex_projs/RinkSpace/calibration/rinkfit/src')
from rinkfit_joint.baseline_auxiliary import packet_header,array_items,checked_array
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');p=r/'g5_ice/packet.json';h=packet_header(p);n=h['row_count'];arr={k:checked_array(h['arrays'][k],p.parent) for k in ('uv','native_pts','shot_index','material_index','kind','path','E','station','row','alpha','admission','fit_role')};active=(arr['admission']==1)&(arr['fit_role']==1);s01=active&(arr['shot_index']==h['shot_ids'].index('s01'))
def raw(path,dtype,shape):return np.memmap(path,mode='r',dtype=dtype,shape=shape)
a=r/'motion_g3';vi=raw(a/'initial_independent_RS_state/raw_station_RS_valid.u8','u1',(n,));vc=raw(a/'independent_RS_state/raw_station_RS_valid.u8','u1',(n,));failed=np.flatnonzero(s01&(vi==1)&(vc==0));ei=raw(a/'initial_independent_RS_state/raw_station_RS_error_native_uv.f64','<f8',(n,2));ec=raw(a/'independent_RS_state/raw_station_RS_error_native_uv.f64','<f8',(n,2));delta=np.sum(ec*ec,axis=1)-np.sum(ei*ei,axis=1);finite=np.flatnonzero(s01&np.isfinite(delta));worst=finite[np.argsort(delta[finite])[-12:]];selected=np.unique(np.r_[failed,worst]);lookup={int(i):{} for i in selected}
for k in ('source_row_ids','source_dataset_ids'):
 for i,x in enumerate(array_items(p,k)):
  if i in lookup:lookup[i][k]=x
  if i>int(selected[-1]):break
queries={}
for q in array_items(p,'queries'):
 if q['row_index'] in lookup:queries[int(q['row_index'])]=q
 if q['row_index']>=182017:break
models=[json.loads((a/d/'model.json').read_text()) for d in ('initial_state','candidate')];rows=[]
for i in selected:
 i=int(i);item=dict(global_row=i,source_dataset_id=lookup[i]['source_dataset_ids'],source_row_id=lookup[i]['source_row_ids'],shot_id='s01',native_pts=int(arr['native_pts'][i]),source_uv=arr['uv'][i].tolist(),material_index=int(arr['material_index'][i]),material=models[0]['materials'][int(arr['material_index'][i])]['label'],kind=int(arr['kind'][i]),E=float(arr['E'][i]),path=int(arr['path'][i]),became_RS_failed=bool(i in failed),initial_RS_error=ei[i].tolist(),candidate_RS_error=ec[i].tolist(),aux={})
 for d in ('initial_state','candidate'):
  ar=a/d/'explicit_nuisance';item['aux'][d]={k:float(raw(ar/(k+'.f64'),'<f8',(n,))[i]) for k in ('station','row','alpha')};item['aux'][d]['path']=int(raw(ar/'path.u32','<u4',(n,))[i]);cp=a/d/'CP_explicit_metrics';item['aux'][d]['CP_RS_equality_px']=float(raw(cp/'explicit_RS_equality.f64','<f8',(n,))[i])
 if i in queries:item['query']=queries[i]
 rows.append(item)
report=dict(schema='rinkfit.actual_g3_s01_RS_regression_rows.v1',failed_rows=failed.tolist(),failed_count=len(failed),diagnostic_rows=rows,initial_model=str(a/'initial_state/model.json'),candidate_model=str(a/'candidate/model.json'),source_packet=str(p),no_full_fit_started=True);out=r/'g3_s01_RS_regression_rows.json';report=json.loads(json.dumps(report),parse_constant=lambda x:None);out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(dict(path=str(out),failed_count=len(failed),failed_pts=arr['native_pts'][failed].tolist(),failed_materials=[models[0]['materials'][int(m)]['label'] for m in arr['material_index'][failed]],diagnostic_rows=len(rows))))
