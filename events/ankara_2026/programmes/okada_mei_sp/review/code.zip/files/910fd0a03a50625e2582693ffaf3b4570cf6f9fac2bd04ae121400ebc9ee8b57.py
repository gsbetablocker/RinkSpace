import sys,pathlib
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'calibration/rinkfit/src'),str(root/'src')]
from rinkfit_joint.recovery_metrics import main
main(['--packet',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/g6_bound/packet.json','--states',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/recovery_metrics_g6_states.json','--out',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/compare_g6_actual_v1'])
