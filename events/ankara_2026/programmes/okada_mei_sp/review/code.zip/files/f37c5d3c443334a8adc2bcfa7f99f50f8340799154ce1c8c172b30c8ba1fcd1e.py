import sys,json,traceback,pathlib
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'));sys.path.insert(0,str(root/'src'))
from rinkfit_joint.joint_solver import build
try:
 build(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/build_v4',ceres_install=root/'environments/cg22p')
except Exception:
 traceback.print_exc();raise
