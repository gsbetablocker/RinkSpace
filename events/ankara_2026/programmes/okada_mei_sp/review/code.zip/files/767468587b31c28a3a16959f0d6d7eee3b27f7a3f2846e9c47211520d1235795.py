import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
import sys,json,copy,hashlib,struct,time
import numpy as np
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src'),str(root/'calibration/program_tracking')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
from rinkfit_joint.baseline_recovery import apply_source_supported_motion_flags
from rinkfit_joint.component_rollback import build_s01_component_rollback
from rinkfit_joint.io_utils import file_sha256,write_json
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');accepted=r/'motion_g3_exact/candidate/model.json';template=Path('D:/CodexData/RinkSpace_Data/runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/navigation_model.json');packet=r/'g6_bound/packet.json';out=r/'recovery_input_g6_model.json';receipt=r/'recovery_input_g6_model_receipt.json'
if out.exists() or receipt.exists() or (r/'S01_rollback_g6_v1').exists():raise ValueError('immutable g6 input/rollback generation exists')
assert file_sha256(accepted)=='cede11d65adc464324b0a78521852ff59594573bd60f671ddd81cf0f66abc38a'
assert file_sha256(packet)=='0d63cd94f0178449862a478bd4769c3fb2bfb373a504d4b50dbb8704906441cf'
refs={name:dict(file=str(p),sha256=file_sha256(p)) for name,p in [('accepted_model',accepted),('baseline_navigation_template',template),('source_packet',packet)]}
old=json.loads(accepted.read_text(encoding='utf8'));base=json.loads(template.read_text(encoding='utf8'));q=copy.deepcopy(old)
if len(old['blocks'])!=len(base['blocks']):raise ValueError('navigation template block allocation differs')
restored=[]
for i,(block,b) in enumerate(zip(q['blocks'],base['blocks'])):
 if block['name']!=b['name'] or len(block['values'])!=len(b['values']):raise ValueError('navigation template physical identity differs')
 if block['name'].startswith('shot/'):
  for flag in ('constant','fixed_indices'):
   if flag in b:block[flag]=copy.deepcopy(b[flag])
   else:block.pop(flag,None)
  restored.append(i)
q['linear_control_manifolds']=copy.deepcopy(base['linear_control_manifolds']);q.pop('source_supported_motion_flags',None)
q=apply_source_supported_motion_flags(packet,q)
q['source_supported_motion_flags']['packet']=refs['source_packet']
def projection_definition(doc):
 j=copy.deepcopy(doc)
 for key in ('source_supported_motion_flags','linear_control_manifolds'):j.pop(key,None)
 for block in j['blocks']:
  for key in ('constant','fixed_indices'):block.pop(key,None)
 return j
if projection_definition(q)!=projection_definition(old):raise ValueError('current prefix projection comparison differs beyond its four established flag exclusions')
def values_digest(doc):
 h=hashlib.sha256()
 for i,b in enumerate(doc['blocks']):
  h.update(struct.pack('<Q',i));h.update(b['name'].encode());h.update(b'\0');h.update(np.asarray(b['values'],dtype='<f8').tobytes())
 return h.hexdigest()
oldvalue=values_digest(old)
if values_digest(q)!=oldvalue:raise ValueError('master or mirror physical numeric bytes changed')
for sid in old['shots']:
 if q['shots'][sid]!=old['shots'][sid]:raise ValueError('camera time/pose/projection definition changed')
if any(d.get('orthonormal_error',0)>1e-10 for d in q['linear_control_manifolds']):raise ValueError('manifold basis no longer orthonormal')
for name,ref in refs.items():
 if file_sha256(ref['file'])!=ref['sha256']:raise ValueError('input dependency changed: '+name)
write_json(out,q)
reread=json.loads(out.read_text(encoding='utf8'))
if values_digest(reread)!=oldvalue or projection_definition(reread)!=projection_definition(old):raise ValueError('serialized g6 input changed physical/projection values')
flags_changed=[dict(index=i,name=a['name'],old_constant=a.get('constant',False),new_constant=b.get('constant',False),old_fixed_indices=a.get('fixed_indices',[]),new_fixed_indices=b.get('fixed_indices',[])) for i,(a,b) in enumerate(zip(old['blocks'],q['blocks'])) if (a.get('constant',False),a.get('fixed_indices',[]))!=(b.get('constant',False),b.get('fixed_indices',[]))]
proof=dict(schema='rinkfit.exact_candidate_new_source_support_flags.v1',**refs,input_model=dict(file=str(out),sha256=file_sha256(out)),physical_master_and_unused_mirror_values_exact=True,physical_value_bytes_sha256=oldvalue,all_shot_projection_definitions_exact=True,source_clock_materials_rigs_geometry_and_other_model_fields_exact=True,helper_projection_definition_equal=True,helper_exactly_excluded_fields=['source_supported_motion_flags','linear_control_manifolds','blocks[].constant','blocks[].fixed_indices'],historical_source_graph_provenance_unchanged=True,restored_shot_flag_blocks=len(restored),flags_changed=flags_changed,linear_manifolds_reloaded_from_verified_navigation_template=True,source_support=q['source_supported_motion_flags'],source_qualification_or_statistics_granted=False,old_duals_or_objective_resumed=False,fit_started=False)
write_json(receipt,proof)
manifest=build_s01_component_rollback(out,packet,accepted,r/'motion_g3/initial_state/model.json',r/'motion_g3/initial_state/explicit_nuisance/manifest.json',r/'g5_ice/packet.json',r/'S01_rollback_g6_v1')
print(json.dumps(dict(input_model=proof['input_model'],receipt=dict(file=str(receipt),sha256=file_sha256(receipt)),rollback_manifest=dict(file=str(r/'S01_rollback_g6_v1/manifest.json'),sha256=file_sha256(r/'S01_rollback_g6_v1/manifest.json')),physical_values_exact=True,projection_definition_equal=True,flags_changed=len(flags_changed))),flush=True)
