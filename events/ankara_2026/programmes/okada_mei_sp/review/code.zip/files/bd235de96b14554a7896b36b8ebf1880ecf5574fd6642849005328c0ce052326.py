import os,sys,json
from pathlib import Path
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
ROOT=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(ROOT),str(ROOT/'calibration/rinkfit/src')]
from rinkfit_joint.joint_solver import execute_explicit
W=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');model=Path(r'D:\CodexData\RinkSpace_Data\runs\okada_full9_recovery_1019\baseline_import_gpu32_v1\navigation_model.json');manifest=W/'screen_grid_demo50_s2_v1/initial_state.json'
result=execute_explicit(W/'build_v14/joint_fit.exe',model,W/'g9_ice/packet.json',W/'screen_grid_received_v1',config=W/'receive_screen_grid_v1_config.json',engineering_recovery=True)
if result:raise SystemExit(result)
from rinkfit_joint.screen_grid_state import ScreenGridState
from calibration.program_tracking.render_demo_last_shot import decode
import cv2
s=ScreenGridState(manifest);p=1464832
native=next(decode(s.manifest['source_identity']['path'],p,p))[1]
image,receipt=s.draw(native,p,labels=True)
out=W/'screen_grid_received_v1';target=out/'s07_1464832_direct.png'
cv2.imwrite(str(target),image)
receipt.update(output=str(target),source_seconds=p/12800,screen_grid_initialized=True,physical_camera_CP_initialized=False,optimizer_started=False)
(out/'s07_1464832_direct_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps(receipt),flush=True)
