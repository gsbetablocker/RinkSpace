import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json,time
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.reference_source_append import append_constraint_source_chunks
from rinkfit_joint.qualified_scope_append import rebind_qualified_board_certificate
from rinkfit_joint.io_utils import file_sha256,write_json
run=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a');rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');bundlepath=run/'recovery_tracklet_qualified_v2/manifest.json';bundle=json.loads(bundlepath.read_text());bundleref=dict(file=str(bundlepath),sha256=file_sha256(bundlepath));parent=rec/'scope_full_ready/packet.json'
write_json(rec/'g4_entities_runtime.json',dict(actual_pid=os.getpid(),phase='qualified_append_started',source_parent=str(parent),immutable_parent_parsed_once=True,no_RGB_or_MC_requalification=True))
print(json.dumps(dict(actual_pid=os.getpid(),phase='qualified_append_started')),flush=True)
def finalize(packet,folder,immutable_parent):return rebind_qualified_board_certificate(parent,packet,folder,bundleref,parent_document=immutable_parent)
started=time.monotonic()
r=append_constraint_source_chunks(parent,bundle['closed_chunks'],bundle['model']['file'],bundle['material_map']['file'],run/'roles/frame_roles.json',rec/'g4_entities',finalize_packet_with_parent=finalize,typed_entity_qualification=bundle['typed_entity_qualification'])
print(json.dumps(dict(packet=r['packet'],active_rows=r['active_rows'],appended_rows=r['appended_raw_rows'],seconds=time.monotonic()-started),ensure_ascii=False),flush=True)
import ctypes
from ctypes import wintypes as w
class PM(ctypes.Structure):
 _fields_=[('cb',w.DWORD),('PageFaultCount',w.DWORD),('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t),('PrivateUsage',ctypes.c_size_t)]
class IO(ctypes.Structure):
 _fields_=[('ReadOperationCount',ctypes.c_uint64),('WriteOperationCount',ctypes.c_uint64),('OtherOperationCount',ctypes.c_uint64),('ReadTransferCount',ctypes.c_uint64),('WriteTransferCount',ctypes.c_uint64),('OtherTransferCount',ctypes.c_uint64)]
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=w.HANDLE;h=k.GetCurrentProcess();pm=PM();pm.cb=ctypes.sizeof(pm);ctypes.WinDLL('psapi').GetProcessMemoryInfo(h,ctypes.byref(pm),pm.cb);io=IO();k.GetProcessIoCounters(h,ctypes.byref(io))
write_json(rec/'g4_entities_resources.json',dict(actual_pid=os.getpid(),elapsed_seconds=time.monotonic()-started,private_bytes=pm.PrivateUsage,rss_bytes=pm.WorkingSetSize,peak_rss_bytes=pm.PeakWorkingSetSize,peak_private_commit_bytes=pm.PeakPagefileUsage,read_transfer_bytes=io.ReadTransferCount,write_transfer_bytes=io.WriteTransferCount,read_operations=io.ReadOperationCount,write_operations=io.WriteOperationCount,parent_JSON_registry_parsed_once=True,old_raw_arrays_read_only_mapped=True,physical_evidence_hashes_cached_across_rebinding=True))
write_json(rec/'g4_entities_runtime.json',dict(actual_pid=os.getpid(),phase='completed',packet=r['packet'],active_rows=r['active_rows']))
