from pathlib import Path
import json,os,subprocess
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');build=r/'exact_replay_memo_build_v1';recipe=json.loads((build/'recipe.json').read_text());env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','');cmd=[str(build/'test_joint_exact_replay_memo.exe'),str(r/'recovery_input_g6_model.json'),str(r/'g5_compare_tiny_fixture.json'),str(r/'exact_replay_memo_native_test_v1')];x=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace');print(x.stdout+x.stderr);raise SystemExit(x.returncode)
