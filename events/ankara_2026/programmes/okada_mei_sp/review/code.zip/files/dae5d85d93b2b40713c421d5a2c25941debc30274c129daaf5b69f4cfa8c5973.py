"""Run existing GPU production objective with a temporary supported optical stage.
All nine shots and all qualified source residuals remain in the problem.
"""
import argparse,os,sys,json
from pathlib import Path
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
ROOT=Path('D:/OneDrive/codex_projs/RinkSpace');WORK=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'calibration/rinkfit/src')]
from rinkfit_joint.io_utils import file_sha256,write_json
from rinkfit_joint.joint_solver import execute_explicit
p=argparse.ArgumentParser();p.add_argument('--ready-state',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
r=json.loads(a.ready_state.read_text('utf8'));mfile=Path(r['model']['file']);packet=Path(r['packet']['file']);ck=Path(r['initial_checkpoint']['file']);out=a.out
for key,ref in [('model',r['model']),('packet',r['packet']),('checkpoint',r['initial_checkpoint'])]:
 if file_sha256(ref['file'])!=ref['sha256']:raise ValueError('Changed ready-state '+key)
if out.exists():raise ValueError('Immutable production generation exists')
m=json.loads(mfile.read_text('utf8'));corrections={int(x['block']) for x in m['linear_control_manifolds']}
if len(corrections)!=40 or set(m['shots'])!={f's{i:02d}' for i in range(1,10)}:raise ValueError('Expected original 40/240 S01 correction basis and all nine shots')
allowed={m['rigs']['main']['optics_block']}|corrections
for sid,shot in m['shots'].items():
 if sid!='s01' and shot['rig_id']=='main':allowed.update(shot['control_blocks']);allowed.add(shot['reference_angles_block'])
# Existing production runtime prefix mechanism; no model flags or parameter
# allocations are changed, and all source/auxiliary/constraint terms remain.
fixed=[b['name'] for i,b in enumerate(m['blocks']) if i not in allowed]
for i in allowed:
 if any(m['blocks'][i]['name'].startswith(x) for x in fixed):raise ValueError('Temporary prefix overlaps an allowed physical block')
cfg=json.loads((WORK/'camera_g9_config.json').read_text('utf8'))
for key in ['source_camera_mode_navigation','motion_navigation_restart','coupled_motion_navigation_restart','finite_line_navigation_restart','resume_engineering_outer_state','baseline_auxiliary_manifest']:
 cfg.pop(key,None)
cfg.update(parameter_stage='optics',temporary_runtime_fixed_physical_prefixes=fixed,
 resume_engineering_checkpoint=str(ck),reinitialize_native_auxiliaries=False,
 refine_ordinary_station_seeds=False,refine_query_navigation_seeds=False,initialization_only=False)
config=out.with_name(out.name+'_config.json');write_json(config,cfg)
write_json(out.with_name(out.name+'_stage_binding.json'),dict(schema='rinkfit.Demo50_supported_optics_stage.v1',ready_state=dict(file=str(a.ready_state),sha256=file_sha256(a.ready_state)),model=r['model'],packet=r['packet'],checkpoint=r['initial_checkpoint'],allowed_physical_blocks=[m['blocks'][i]['name']for i in sorted(allowed)],temporary_fixed_blocks=len(fixed),all_nine_source_scope_unchanged=True,original_flags_and_manifold_unchanged=True,old_camera_parameters_imported=False,source_UV_W_Query_qualification_unchanged=True,GPU_raw_J_and_CUDA_CGNR_retained=True,S01_function_change_must_be_compared_on_same_original_sources=True,original_baseline_preserved_on_disk=True,not_exact_S01_zero_import_after_optimization=True))
raise SystemExit(execute_explicit(str(WORK/'build_v14/joint_fit.exe'),str(mfile),str(packet),str(out),config=str(config),engineering_recovery=True))
