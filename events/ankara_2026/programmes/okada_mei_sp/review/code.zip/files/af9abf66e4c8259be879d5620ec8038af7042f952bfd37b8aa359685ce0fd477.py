from pathlib import Path
import json,os,subprocess
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');recipe=json.loads((r/'component_rollback_build_v3/recipe.json').read_text());env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','');x=subprocess.run([str(r/'component_rollback_build_v3/test_joint_component_rollback.exe'),str(r/'component_rollback_native_test_v3')],env=env,capture_output=True,text=True,errors='replace');print(x.stdout+x.stderr);raise SystemExit(x.returncode)
