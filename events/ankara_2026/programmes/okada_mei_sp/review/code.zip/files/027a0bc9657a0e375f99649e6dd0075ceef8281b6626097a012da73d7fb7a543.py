import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.joint_replay import render_snapshots
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
r=render_snapshots(rec/'demo_grid_init_v1_main_accepted1/model.json',rec/'programme_scope.json',rec/'initialization_review/demo50_main_accepted1',[1464832,2415104],shots=[],compiled_dir=Path('D:/CodexData/RinkSpace_Data/runs/okada_s1_r11/gpu_accel/line_bundle/code/compiled_camera'),packet_file=rec/'g9_ice/packet.json')
print(json.dumps(dict(frames=len(r['frames']),model=r['model'],source_accuracy_accepted=False,video_generated=False)),flush=True)
