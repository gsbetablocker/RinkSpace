import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.joint_replay import render_snapshots
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
items=[('native_init_v1',rec/'native_init_v1/model.json')]
for name,model in items:
 result=render_snapshots(model,Path('D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/programme_scope.json'),rec/'initialization_review'/name,[744704,1464832],compiled_dir=Path('D:/CodexData/RinkSpace_Data/runs/okada_s1_r11/gpu_accel/line_bundle/code/compiled_camera'),packet_file=rec/'g9_bound/packet.json')
 print(json.dumps(dict(phase=name,model_sha256=result['model']['sha256'],frames=len(result['frames']),all_materials=result['all_material_paths_enabled'],video_generated=False)),flush=True)
