import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import sys,json,time
from pathlib import Path
import numpy as np
R=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(R/'calibration/rinkfit/src'))
from rinkfit_joint.grid_baseline_init import GridTargets,GridMotion,_physical
from rinkfit_joint.io_utils import read_json,write_json
W=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');g=GridTargets(W/'ice_grid_nav8a28_v1/manifest.json');a=g.arrays;m=read_json(W/'grid_input_v1/model.json');reports=[]
for rid in ('secondary','end','main'):
 sids=[s for s,v in m['shots'].items()if s!='s01'and v['rig_id']==rid];mask=np.isin(g.shot,[int(s[1:])for s in sids]);ids=g.rows(mask);count=np.diff(g.offset)[mask];pts=np.repeat(g.pts[mask],count);sn=np.repeat(g.shot[mask],count);target=np.asarray(a['target_uv'][ids]);world=np.asarray(a['current_world'][ids]);rig=m['rigs'][rid];h=np.asarray(m['blocks'][rig['head_block']]['values']);o=np.asarray(m['blocks'][rig['optics_block']]['values']);ticks=pts.astype(float)+o[11]*(target[:,1]/1079-.5)*12800;start=time.perf_counter();motion=GridMotion(m,sids,sn,ticks);q=motion.values(motion.x);p,depth,r,RR,C=_physical(q,h,o,rig['camera'],world[:,None,:]);z=q[:,2]-np.log(rig['camera']['f_ref']);k1=o[5]+o[6]*z;k2=o[7]+o[8]*z;s=r[:,0]**2;localradial=1+3*k1*s+5*k2*s*s-6*np.hypot(o[9],o[10])*r[:,0];err=np.linalg.norm(p[:,0]-target,axis=1);report=dict(rig=rid,N=len(ids),nnz=[D.nnz for D in motion.D],sparse_bytes=sum(D.data.nbytes+D.indices.nbytes+D.indptr.nbytes for D in motion.D)+sum(C.row.nbytes for C in motion.coo),RMS=float(np.sqrt(np.mean(err*err))),rmax=float(r.max()),negative_depth=int((depth<=0).sum()),outside_R=int((r>rig['camera']['radius_max']).sum()),local_radial_negative=int((localradial<=0).sum()),seconds=time.perf_counter()-start);reports.append(report);print(json.dumps(report),flush=True)
write_json(W/'grid_preflight.json',reports)
