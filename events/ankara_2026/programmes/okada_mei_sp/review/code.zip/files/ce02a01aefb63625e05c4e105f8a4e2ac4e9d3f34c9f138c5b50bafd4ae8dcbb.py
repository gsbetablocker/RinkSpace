import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,hashlib,subprocess
import numpy as np,cv2
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
W=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');O=W/'S03_actual_pixel_evidence';spec=json.loads((W/'g9_actual_failures/S03_camera_mode_spec_g9.json').read_text('utf8'));bindings=json.loads((W/'g9_actual_failures/S03_render_source_bindings.json').read_text('utf8'));points=[720896,729856,737792,744704]
restart=W/'camera_g9/outer_0/source_camera_mode_navigation';before_state=W/'shared_g9/candidate';after_state=restart/'accepted_state'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),'utf8')
if len(sys.argv)>1:
 from rinkfit_joint import joint_replay as jr
 from rinkfit_joint.joint_acceleration import install
 phase=sys.argv[1];state=before_state if phase=='before' else after_state
 if phase=='after':
  receipt=json.loads((restart/'receipt.json').read_text('utf8'));assert receipt['accepted'] is True,'after requires actual complete production acceptance'
 model_file=state/'model.json';q=jr.read_json(model_file);cg=jr.CameraGraph(jr.graph_from_joint(q));world,records=jr.inventory(q);scene=jr.NativeScene(jr.as_event_view(q,'s01'));assert len(q['materials'])==350
 target=O/phase;target.mkdir(parents=True,exist_ok=False)
 install(cg,model_file,target/'acceleration',world,Path('D:/CodexData/RinkSpace_Data/runs/okada_s1_r11/gpu_accel/line_bundle/code/compiled_camera'))
 station_file=state/'explicit_nuisance/station.f64';N=station_file.stat().st_size//8;stations=np.memmap(station_file,dtype='<f8',mode='r',shape=(N,));camera=cg.native_camera('s03');frames=[]
 for pt in points:
  raw=Path(bindings[str(pt)]['file']);assert sha(raw)==bindings[str(pt)]['sha256'];bgr=cv2.imread(str(raw));assert bgr.shape[:2]==(1080,1920)
  local=float(cg.local_seconds('s03',np.array([pt],np.int64))[0]);uv,good,eq=jr.fast_native_project(camera,world,local);good&=jr.render_visibility(camera,scene,world,records,local,uv)
  im,metrics=jr.draw_fast(bgr,uv,good,records,f'{phase.upper()} | source {pt/12800:.3f}s | PTS {pt} | ALL 350 MATERIALS + IDS')
  rows=[r for r in spec['source_rows'] if r['native_pts']==pt];X=[]
  for r in rows:
   path=q['materials'][r['material_index']]['paths'][r['path']];assert path['geometry_block']==25 and path['kind']==1
   g=q['blocks'][25]['values'];s=float(stations[r['row_index']]);a=path['start_angle']+s*(path['end_angle']-path['start_angle']);radius=g[path['radius_index']];X.append([g[0]+radius*np.cos(a),g[1]+radius*np.sin(a),0.])
  pred,valid,root_eq=jr.fast_native_project(camera,np.asarray(X,np.float64),local);measurements=[]
  for r,p,v,h in zip(rows,pred,valid,root_eq):
   source=np.asarray(r['source_uv'],np.float64);finite=bool(np.isfinite(p).all());error=float(np.linalg.norm(p-source)) if finite else None;ok=bool(v and finite)
   a=tuple(np.rint(source).astype(int));cv2.circle(im,a,7,(0,255,0),2)
   if finite and np.max(np.abs(p))<1e7:
    b=tuple(np.rint(p).astype(int));cv2.drawMarker(im,b,(255,0,255),cv2.MARKER_TILTED_CROSS,16,2);cv2.line(im,a,b,(0,100,255),1)
   measurements.append(dict(row_index=r['row_index'],source_row_id=r['source_row_id'],material=q['materials'][r['material_index']]['label'],source_uv=r['source_uv'],source_station=float(stations[r['row_index']]),actual_RS_uv=[float(x) if np.isfinite(x) else None for x in p],actual_RS_valid=ok,actual_RS_error_px=error,RS_equality_px=float(h) if np.isfinite(h) else None))
  all_valid=all(r['actual_RS_valid'] for r in measurements);rms=float(np.sqrt(np.mean([r['actual_RS_error_px']**2 for r in measurements]))) if all_valid else None;maxerr=max(r['actual_RS_error_px'] for r in measurements if r['actual_RS_error_px'] is not None)
  cv2.rectangle(im,(0,1005),(1919,1079),(15,15,15),-1);text=f'Original UV: green | Current exact-state native RS: magenta | N={len(rows)} | RMS={rms:.3f}px MAX={maxerr:.3f}px' if rms is not None else f'Original UV green | Current exact-state native RS magenta | N={len(rows)} | NATIVE ROOT FAILURES RETAINED'
  cv2.putText(im,text,(25,1048),cv2.FONT_HERSHEY_SIMPLEX,.72,(245,245,245),2,cv2.LINE_AA)
  image_file=target/f'{pt}_grid.png';assert cv2.imwrite(str(image_file),im);frames.append(dict(PTS=pt,source_time_seconds=pt/12800,source_native_png=str(raw),source_native_png_sha256=bindings[str(pt)]['sha256'],image=str(image_file),source_rows=len(rows),native_valid_rows=sum(r['actual_RS_valid'] for r in measurements),native_full_N_RMS_px=rms,max_native_error_px=maxerr,source_rows_kept=measurements,all_350_materials_and_ids=True,source_UV_unchanged=True,source_image_unmodified=True,render_visibility_failures_not_relabelled_as_fit_success=True,metrics=metrics))
  print(json.dumps(dict(phase=phase,PTS=pt,N=len(rows),native_RMS_px=rms,max_px=maxerr,image=str(image_file))),flush=True)
 write(target/'receipt.json',dict(schema='rinkfit.actual_S03_source_camera_mode_native_grid.v1',phase=phase,model=str(model_file),model_sha256=sha(model_file),state_directory=str(state),source_packet_sha256=spec['source_packet_sha256'],native_time_base='1/12800',source_pts_step=256,original_E_and_UV_unchanged=True,all_350_materials_and_ids=True,frames=frames,whole_programme_fitted=False,video_generated=False))
else:
 O.mkdir(exist_ok=False)
 while not (before_state/'model.json').exists() or not (before_state/'explicit_nuisance/station.f64').exists():time.sleep(1)
 with (O/'before_render.log').open('w',encoding='utf8') as log:subprocess.run([sys.executable,'-X','utf8','-B',__file__,'before'],check=True,stdout=log,stderr=subprocess.STDOUT)
 while not (restart/'receipt.json').exists():time.sleep(1)
 rr=json.loads((restart/'receipt.json').read_text('utf8'))
 if not rr['accepted']:
  write(O/'conclusion.json',dict(schema='rinkfit.actual_S03_navigation_visual_evidence.v1',navigation_accepted=False,after_rendered=False,reason='Production same-PHR/native-root/pixel guard rejected candidate; no accepted after state is fabricated.',navigation_receipt=str(restart/'receipt.json'),before_receipt=str(O/'before/receipt.json'),whole_programme_fitted=False,video_generated=False));print('Navigation rejected; actual before only.',flush=True);raise SystemExit(0)
 while not (after_state/'model.json').exists() or not (after_state/'explicit_nuisance/station.f64').exists():time.sleep(1)
 with (O/'after_render.log').open('w',encoding='utf8') as log:subprocess.run([sys.executable,'-X','utf8','-B',__file__,'after'],check=True,stdout=log,stderr=subprocess.STDOUT)
 before=json.loads((O/'before/receipt.json').read_text('utf8'));after=json.loads((O/'after/receipt.json').read_text('utf8'));comparisons=[]
 for pt in points:
  b=next(f for f in before['frames'] if f['PTS']==pt);a=next(f for f in after['frames'] if f['PTS']==pt);assert b['source_native_png_sha256']==a['source_native_png_sha256'];assert [r['source_uv'] for r in b['source_rows_kept']]==[r['source_uv'] for r in a['source_rows_kept']]
  ims=[cv2.imread(b['image']),cv2.imread(a['image'])];image_file=O/f'{pt}_before_after.png';assert cv2.imwrite(str(image_file),np.concatenate(ims,axis=1));comparisons.append(dict(PTS=pt,source_time_seconds=pt/12800,source_rows=b['source_rows'],before_native_RMS_px=b['native_full_N_RMS_px'],after_native_RMS_px=a['native_full_N_RMS_px'],before_max_px=b['max_native_error_px'],after_max_px=a['max_native_error_px'],before_valid=b['native_valid_rows'],after_valid=a['native_valid_rows'],image=str(image_file)))
 write(O/'conclusion.json',dict(schema='rinkfit.actual_S03_navigation_visual_evidence.v1',navigation_accepted=True,navigation_receipt=str(restart/'receipt.json'),before_model_sha256=before['model_sha256'],after_model_sha256=after['model_sha256'],all_materials_and_ids=True,source_UV_and_frame_identical=True,comparisons=comparisons,whole_programme_fitted=False,video_generated=False));print(json.dumps(comparisons,ensure_ascii=False,indent=2),flush=True)
