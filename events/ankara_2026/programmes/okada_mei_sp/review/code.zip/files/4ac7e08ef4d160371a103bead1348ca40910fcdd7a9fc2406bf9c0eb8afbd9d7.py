from pathlib import Path
import sys,json,hashlib,av,cv2
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkspace.feedback_runtime import learn_source_review
from rinkfit_joint.io_utils import file_sha256,write_json
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');folder=rec/'s01_worst_station_v1'
doc=Path('D:/CodexData/RinkSpace_Data/events/ankara_2026/feedback/checkpoints/cc93238756b35dff5245a368.json')
task=next(t for t in json.loads(doc.read_text())['tasks']if t['source_row_index']==11476)
source={**task['context']['source'],'native_hw':[1080,1920]}
scope=json.loads(Path('D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/programme_scope.json').read_text())
raw=folder/'native_282368.png'
if not raw.exists():
 with av.open(scope['source']['path'])as cont:
  stream=cont.streams.video[0];cont.seek(282368,backward=True,any_frame=False,stream=stream)
  for frame in cont.decode(stream):
   if int(frame.pts)==282368:
    cv2.imwrite(str(raw),frame.to_ndarray(format='bgr24'));break
   if int(frame.pts)>282368:raise ValueError('Missing native source exposure')
assert raw.exists()
evidence=dict(path=str(raw),sha256=file_sha256(raw),kind='native_pixels',source=source,current_frame=True,independent_of_model=True)
review=folder/'Ad2_U_source_review.json'
write_json(review,dict(authority='assistant_current_original_pixel_review_not_new_user_confirmation',
 source=source,source_row_id=task['source_row_id'],source_uv=[1263.02,586.98],
 source_uv_changed=False,existing_source_qualification_reissued=False,
 semantic_class='static printed ink material on the physical board',
 measurement_operator='existing actual printed U material boundary',
 physical_instance='Ad2 U; existing manually corrected first-shot source identity retained in this exact exposure',
 visibility='the observed lower left U boundary is visible beside the skater, not on the person or reflection',
 position_review='original source mean remains on the visible lower U contour; no new subpixel truth is claimed',
 model_diagnosis='same finite U path contains the correct lower branch, while the old stored station maps to its top; a 175px model residual does not invalidate the source mean',
 pixel_evidence=evidence,
 frozen_same_path_diagnosis=dict(file=str(folder/'source_station_diagnosis.json'),sha256=file_sha256(folder/'source_station_diagnosis.json')),
 actual_full_objective_restart=dict(file=str(rec/'shared_g8/outer_0/ordinary_station_restart/receipt.json'),sha256=file_sha256(rec/'shared_g8/outer_0/ordinary_station_restart/receipt.json'))))
checks={}
for dimension,value in [('semantic_class','static printed board material'),('physical_instance','existing exact-exposure Ad2 U identity, current native context checked'),('measurement_operator','existing printed material boundary, unchanged'),('visibility','original lower U boundary visible outside skater/graphics/reflection'),('position','original UV retained on the lower U contour; assistant current-pixel review, no new subpixel certificate')]:
 checks[dimension]=dict(status='verified',value=value,evidence_refs=[evidence['sha256'],file_sha256(review)])
result=learn_source_review(project=root,event_id='ankara_2026',finding_id=task['finding_id'],source=source,checks=checks,
 evidence_refs=[evidence,dict(path=str(review),sha256=file_sha256(review),kind='current_source_review',source=source,current_frame=True,independent_of_model=True)],
 resolution_type='model_mismatch',lesson=dict(summary='已核实的U轮廓原UV保持；大残差先区分同一有限曲线上的辅助station跳支与真实相机/几何误差，不能让好点迁就模型。',
 current_source_reread_required=True,solver_check='same_finite_path_station_restart_with_complete_current_objective_acceptance',
 source_identity_or_pixels_transferred_to_future_frame=False,UV_or_observation_reinstallation_authorized=False))
write_json(folder/'Ad2_U_feedback_resolution.json',result)
print(json.dumps(dict(finding_id=task['finding_id'],learned_case=result.get('learned_case'),observation_action=result.get('observation_action'),consumers=result.get('consumers'),receipt=result.get('receipt')),ensure_ascii=False),flush=True)
