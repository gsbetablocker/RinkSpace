from pathlib import Path
import json,os,subprocess
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');recipe=json.loads((r/'compare_build_g5_v1/g3_s01_RS_probe_recipe.json').read_text());env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','');x=subprocess.run([str(r/'compare_build_g5_v1/g3_s01_RS_probe.exe'),str(r/'g3_s01_RS_regression_rows.json'),str(r/'g3_s01_RS_native_probe.json')],env=env,capture_output=True,text=True,errors='replace');print(x.stdout+x.stderr);raise SystemExit(x.returncode)
