import os,sys,json,subprocess,hashlib,time
from pathlib import Path
rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');root=Path(r'D:/OneDrive/codex_projs/RinkSpace');exe=rec/'build_v5/joint_fit.exe';model=rec/'recovery_input_model.json';packet=rec/'g5_ice/packet.json';output=rec/'g5_ice/native_qualification.json';recipe=json.loads((exe.parent/'recipe.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert sha(exe)==recipe['executable_sha256']
assert sha(packet)=='a5e83beb94f67e032070768585a4a5c5b5b92b1b84a8314c5f0ed75ed2e11b57'
env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','');env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
command=[str(exe),'--qualification-check',str(model),str(packet),str(output)]
start=time.monotonic()
with (rec/'g5_ice/native_qualification.log').open('w',encoding='utf8')as stream:r=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
result=dict(schema='rinkfit.native_qualification_execution.v1',command=command,returncode=r.returncode,elapsed_seconds=time.monotonic()-start,backend_sha256=sha(exe),model_sha256=sha(model),packet_sha256=sha(packet),fit_started=False,MC_started=False)
(rec/'g5_ice/native_qualification_execution.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8');print(json.dumps(result,ensure_ascii=False));raise SystemExit(r.returncode)
