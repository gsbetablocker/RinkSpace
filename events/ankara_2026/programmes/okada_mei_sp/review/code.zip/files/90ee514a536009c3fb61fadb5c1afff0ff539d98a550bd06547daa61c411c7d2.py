from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,'D:/OneDrive/codex_projs/RinkSpace/calibration/rinkfit/src')
from rinkfit_joint.baseline_auxiliary import packet_header,array_items,checked_array
from rinkfit_joint.io_utils import file_sha256
p=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/g5_ice/packet.json');h=packet_header(p);first=904249;n=h['row_count'];assert n-first==239
arrays={k:checked_array(h['arrays'][k],p.parent) for k in ('uv','native_pts','shot_index','material_index','kind','path','E','station','row','alpha','admission','fit_role')}
ids=[x for i,x in enumerate(array_items(p,'source_row_ids')) if i>=first];datasets=[x for i,x in enumerate(array_items(p,'source_dataset_ids')) if i>=first]
rows=[]
for i in range(first,n):
 j=i-first;rows.append(dict(source_dataset_id=datasets[j],source_row_id=ids[j],shot_id=h['shot_ids'][int(arrays['shot_index'][i])],native_pts=int(arrays['native_pts'][i]),source_uv=arrays['uv'][i].tolist(),material_index=int(arrays['material_index'][i]),path=int(arrays['path'][i]),kind=int(arrays['kind'][i]),E=float(arrays['E'][i]),station=float(arrays['station'][i]),row=float(arrays['row'][i]),alpha=float(arrays['alpha'][i]),active=bool(arrays['admission'][i]==1 and arrays['fit_role'][i]==1),fit_role='test_actual_fresh_qualified_source_copy_no_qualification_granted'))
queries=[]
for q in array_items(p,'queries'):
 if q['row_index']>=first:q['row_index']-=first;queries.append(q)
out=p.parent.parent/'g5_compare_tiny_fixture.json';assert not out.exists();out.write_text(json.dumps(dict(schema='rinkfit.joint_packet.v1',rows=rows,queries=queries,fixture_origin_packet=dict(path=str(p),sha256=file_sha256(p)),original_first_row=first),ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(dict(path=str(out),rows=len(rows),queries=len(queries),sha256=file_sha256(out))))
