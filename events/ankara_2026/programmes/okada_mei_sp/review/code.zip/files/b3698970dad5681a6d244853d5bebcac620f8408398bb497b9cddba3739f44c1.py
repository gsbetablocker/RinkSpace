"""Extract immutable old physical navigation on official PTS; never source observations."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json, sys
ROOT=Path(r'D:/OneDrive/codex_projs/RinkSpace')
DATA=Path(r'D:/CodexData/RinkSpace_Data')
WORK=DATA/'runs/okada_rec_1019'
sys.path[:0]=[str(ROOT/'calibration/program_tracking'),str(ROOT/'calibration/rinkfit/src')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
import cv2, numpy as np
from scipy.spatial.transform import Rotation, Slerp
from z190_physical_camera import PhysicalCameraModel

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def artifact(p):return dict(file=str(Path(p).resolve()),sha256=sha(p))
def write(p,x):
 with Path(p).open('x',encoding='utf8')as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write(chr(10))
def tok(c,v,e,install):
 h=hashlib.sha256()
 for x in (c,v,e):h.update(np.ascontiguousarray(x,dtype='<f8').tobytes())
 h.update(str(install).encode('utf8'));return h.hexdigest()

def main():
 out=WORK/'nav_8a28_v1'
 if out.exists():raise FileExistsError('Immutable output already exists: '+str(out))
 ref=read(DATA/'runs/okada_joint9_1018a/reference_8a28.json')
 archive=Path(ref['scene']['path']).parents[2]/'complete_physical_camera_model_UNACCEPTED_ddff0a574df9f9a6.npz'
 ledger=DATA/'events/ankara_2026/programmes/okada_mei_sp/history/tracking_runs/source_cadence_comparison/O6j8L8TmfKo/full_programme_alignment/native60_to_official50.jsonl'
 if sha(archive)!=ref['camera_archive_sha256']:raise ValueError('Old camera identity mismatch')
 if sha(ledger)!='a9be37308b9a39fb55519a0be69c741c53a8216a81a60a2066fff25bdcf54dcc':raise ValueError('Old native correspondence ledger identity mismatch')
 if sha(ref['scene']['path'])!=ref['scene']['sha256']:raise ValueError('Old scene identity mismatch')
 model, old_pts, aliases, views=PhysicalCameraModel.load_npz(archive)
 with np.load(archive,allow_pickle=False)as a:
  cams=a['camera25'];v4=a['view_state4'];ep=a['effective_pp_offset_px'];inst=a['installation_id'];reps=a['exposure_representative_pts'];meta=json.loads(str(a['metadata_json'].item()))
 oldscene=read(ref['scene']['path']);bounds=np.asarray(oldscene['parameters']['bounds'],float)
 L=float(bounds[2]-bounds[0]);origin=np.r_[(bounds[:2]+bounds[2:])/2,0.]
 scope=read(WORK/'programme_scope.json');first=256256;last=2415104
 if scope['included_frame_count']!=8434 or scope['source']['time_base']!='1/12800':raise ValueError('Official scope changed')
 idx={int(p):i for i,p in enumerate(old_pts)};groups=defaultdict(list)
 for line in ledger.open(encoding='utf8'):
  r=json.loads(line);p=r.get('accepted_official_pts');full=int(r['full_pts'])
  if p is not None and full in idx and first<=int(p)<=last:
   groups[int(p)].append(dict(archive_row=idx[full],legacy_pts=full,match_status=r['match_status'],source_ledger_line=r.get('line_1based')))
 preferred=defaultdict(list);inferred=defaultdict(list);navrefs=[];navstatuses=Counter()
 for n in range(2,10):
  d=DATA/f'events/ankara_2026/programmes/okada_mei_sp/results/shot{n}_review_20261014'
  if n==2:d=d/'r2'
  p=d/'navigation_mapping.json';m=read(p);navrefs.append(artifact(p))
  if m['model_seed']['q_sha256']!=ref['q_sha256'] or m['model_seed']['inherited_camera_archive']['sha256']!=sha(archive):raise ValueError('Navigation identity mismatch')
  for f in m['frames']:
   i=int(f['inherited_camera_archive_row_0based']);point=int(f['official_pts']);navstatuses[f['mapping_status']]+=1
   if hashlib.sha256(np.ascontiguousarray(cams[i],dtype='<f8').tobytes()).hexdigest()!=f['camera25_float64_sha256']:raise ValueError('Preferred old camera row changed')
   record=dict(archive_row=i,legacy_pts=int(old_pts[i]),mapping_status=f['mapping_status'])
   (preferred if f['mapping_status']=='confirmed_pixel_match' else inferred)[point].append(record)
 def unique(records):
  d={}
  for r in records:
   i=r['archive_row'];key=tok(cams[i],v4[i],ep[i],inst[i]);d.setdefault(key,[]).append(r)
  return d
 global_stats=[]
 for s in scope['shots']:
  pp=list(range(s['first_pts'],s['last_pts']+1,256));gg=[unique(groups[p])for p in pp]
  global_stats.append(dict(shot=s['id'],frames=len(pp),direct_mapping_present=sum(bool(x)for x in gg),missing_ledger_mapping=sum(not x for x in gg),multiple_distinct_old_camera_states=sum(len(x)>1 for x in gg)))
 shots=[s for s in scope['shots']if s['id']!='s01'];pts=np.concatenate([np.arange(s['first_pts'],s['last_pts']+1,256,dtype=np.int64)for s in shots]);N=len(pts)
 sid=np.concatenate([np.full(s['native_frame_count'],int(s['id'][1:]),np.uint8)for s in shots]);rig=np.asarray([{'main':0,'secondary':1,'end':2}[next(s['rig_id']for s in shots if int(s['id'][1:])==int(n))]for n in sid],np.uint8)
 selected=np.full(N,-1,np.int64);status=np.zeros(N,np.uint8);navrow=np.full(N,-1,np.int64);candidates=[];candidate_offsets=[0];decisions=[]
 # status: 1 direct unique, 2 confirmed preferred resolves conflict, 3 unresolved conflict, 4 no old accepted mapping.
 for j,p in enumerate(pts):
  p=int(p);u=unique(groups[p]);candidates.extend(groups[p]);candidate_offsets.append(len(candidates))
  if len(u)==1:selected[j]=next(iter(u.values()))[0]['archive_row'];status[j]=1
  elif len(u)>1:
   pr=unique(preferred[p]);eligible=set(pr)&set(u)
   if len(eligible)==1:selected[j]=u[next(iter(eligible))][0]['archive_row'];status[j]=2
   else:status[j]=3
  else:
   status[j]=4;pr=unique(preferred[p])
   if len(pr)==1:selected[j]=next(iter(pr.values()))[0]['archive_row'];status[j]=2
  if selected[j]>=0:navrow[j]=selected[j]
  elif status[j]==4 and len(unique(inferred[p]))==1:navrow[j]=next(iter(unique(inferred[p]).values()))[0]['archive_row']
  if len(u)!=1 or p in inferred:
   decisions.append(dict(native_pts=p,shot_id='s%02d'%sid[j],status=int(status[j]),selected_old_archive_row=int(selected[j]),numeric_navigation_reference_row=int(navrow[j]),raw_distinct_states=len(u),raw_candidates=groups[p],preferred_confirmed=preferred[p],inferred_reference=inferred[p]))
 oldcam=np.full((N,25),np.nan);R=np.full((N,3,3),np.nan);C=np.full((N,3),np.nan);K=np.full((N,3,3),np.nan);D=np.full((N,14),np.nan);logf=np.full(N,np.nan);legacy=np.full(N,-1,np.int64)
 for j in np.flatnonzero(selected>=0):
  i=selected[j];c=cams[i];oldcam[j]=c;R[j]=cv2.Rodrigues(c[3:6])[0];C[j]=(c[:3]-origin)/L;K[j]=[[np.exp(c[6]),c[10],c[8]],[0,np.exp(c[7]),c[9]],[0,0,1]];D[j]=c[11:25];logf[j]=np.mean(c[6:8]);legacy[j]=old_pts[i]
 pivots=[];levers=[];calibrations=[]
 for n in range(3):
  name='okada_sp_installation_%d_conditional_z190'%n;cal=model.calibrations[name];pivots.append((np.asarray(cal.pivot_xyz)-origin)/L);levers.append(np.asarray(cal.lever_xyz)/L);calibrations.append({k:v for k,v in meta['calibrations'][name].items()if k!='field_settings'})
 pivots=np.asarray(pivots);levers=np.asarray(levers)
 navR=R.copy();navlogf=logf.copy();navC=C.copy();navkind=np.where(selected>=0,1,0).astype(np.uint8);provenance=[]
 for j in np.flatnonzero((selected<0)&(navrow>=0)):
  c=cams[navrow[j]];navR[j]=cv2.Rodrigues(c[3:6])[0];navlogf[j]=np.mean(c[6:8]);navC[j]=(c[:3]-origin)/L;navkind[j]=2
 for n in range(2,10):
  ss=np.flatnonzero(sid==n);anchors=ss[np.isfinite(navlogf[ss])];missing=ss[(status[ss]==4)&~np.isfinite(navlogf[ss])]
  if not len(anchors):raise ValueError('No numerical navigation anchors for shot '+str(n))
  for j in missing:
   k=int(np.searchsorted(pts[anchors],pts[j]));left=anchors[max(0,k-1)];right=anchors[min(k,len(anchors)-1)]
   if left==right:navR[j]=navR[left];navlogf[j]=navlogf[left];navkind[j]=4
   else:
    t=(int(pts[j])-int(pts[left]))/(int(pts[right])-int(pts[left]));navR[j]=Slerp([0.,1.],Rotation.from_matrix(np.asarray([navR[left],navR[right]])))([t]).as_matrix()[0];navlogf[j]=(1-t)*navlogf[left]+t*navlogf[right];navkind[j]=3
   navC[j]=pivots[rig[j]]+navR[j].T@levers[rig[j]]
   provenance.append(dict(native_pts=int(pts[j]),shot_id='s%02d'%n,kind=int(navkind[j]),left_anchor_pts=int(pts[left]),right_anchor_pts=int(pts[right]),measured_exposure_correspondence=False,source_observation=False))
 # Preserve genuinely unresolved conflicts as NaN: no candidate identity is averaged or silently chosen.
 if np.any(np.isfinite(navlogf[status==3])):raise ValueError('Unresolved identity conflict was filled')
 exact=np.flatnonzero(selected>=0);centre_err=max((np.max(np.abs(C[j]-(pivots[rig[j]]+R[j].T@levers[rig[j]])))for j in exact),default=0.)
 if centre_err>1e-12:raise ValueError('Normalized shared pivot+lever does not replay old centre')
 out.mkdir()
 np.savez_compressed(out/'navigation.npz',native_pts=pts,shot_number=sid,rig_number=rig,source_clock_time_base=np.asarray([1,12800],np.int64),official_pts_step=np.asarray(256,np.int64),normalization_L=np.asarray(L),normalization_origin=origin,pivot_normalized=pivots,lever_normalized=levers,mapping_status=status,old_archive_row=selected,old_legacy_pts=legacy,old_camera25_scene_units=oldcam,old_R_world_to_camera=R,old_C_normalized=C,old_K_native_pixels=K,old_Brown14=D,old_log_f_native_pixels=logf,navigation_kind=navkind,navigation_R_world_to_camera=navR,navigation_C_normalized=navC,navigation_log_f_native_pixels=navlogf,candidate_offsets=np.asarray(candidate_offsets,np.int64),candidate_old_archive_row=np.asarray([r['archive_row']for r in candidates],np.int64),candidate_old_legacy_pts=np.asarray([r['legacy_pts']for r in candidates],np.int64))
 write(out/'mapping_exceptions.json',dict(decisions=decisions,interpolation_provenance=provenance))
 doc=dict(schema='rinkfit.immutable_8a28_full_native_navigation.v1',q_sha256=ref['q_sha256'],source_archive=artifact(archive),source_scene=ref['scene'],source_correspondence_ledger=artifact(ledger),programme_scope=artifact(WORK/'programme_scope.json'),official_source=scope['source'],preferred_navigation_refs=navrefs,extractor=artifact(__file__),output=artifact(out/'navigation.npz'),mapping_exceptions=artifact(out/'mapping_exceptions.json'),normalization=dict(L=L,origin=origin.tolist(),unit='conditional_L1_not_metres',all_length_values_divided_by_L=True),original_shared_calibrations=calibrations,rig_order=['main','secondary','end'],global_all9_ledger_counts=global_stats,output_scope=dict(shots=['s%02d'%n for n in range(2,10)],native_frames=N,first_native_pts=int(pts[0]),last_native_pts=int(pts[-1])),preferred_201_mapping_status_counts=dict(navstatuses),mapping_status_codes={1:'unique_exact_old_state_from_accepted_ledger_mapping',2:'confirmed_per_shot_navigation_priority_resolution',3:'unresolved_distinct_old_state_conflict_no_identity_selected',4:'no_accepted_ledger_correspondence'},mapping_status_counts=dict(Counter(map(int,status))),navigation_kind_codes={0:'unresolved_conflict_no_navigation_value',1:'exact_selected_old_state',2:'explicit_inferred_historical_navigation_reference_not_confirmed_correspondence',3:'within_shot_SO3_SLERP_and_logf_linear_numerical_navigation_only',4:'one_sided_constant_numerical_navigation_only'},navigation_kind_counts=dict(Counter(map(int,navkind))),normalized_shared_pivot_lever_centre_replay_max_abs=float(centre_err),old_camera_package_exact_replay_verified=True,UV_W_Query_source_qualification_modified=False,old_navigation_values_are_not_source_observations=True,interpolation_is_not_exposure_identity_or_physical_accuracy=True,current_production_camera_family_changed=False,d78_S01_or_shared_scene_changed=False,source_accuracy_accepted=False)
 write(out/'manifest.json',doc)
 print(json.dumps(dict(output=str(out),native_frames=N,status_counts=doc['mapping_status_counts'],navigation_counts=doc['navigation_kind_counts'],normalized_centre_replay_max_abs=centre_err),ensure_ascii=False))

if __name__=='__main__':main()
