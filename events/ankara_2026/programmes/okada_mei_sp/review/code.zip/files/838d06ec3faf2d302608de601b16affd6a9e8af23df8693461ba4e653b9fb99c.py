from pathlib import Path
import sys,json
sys.path.insert(0,'D:/OneDrive/codex_projs/RinkSpace/calibration/rinkfit/src')
from rinkfit_joint.baseline_auxiliary import array_items
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');source=r/'g5_ice/packet.json';p=r/'g5_compare_tiny_fixture.json';fixture=json.loads(p.read_text(encoding='utf8'));first=904249;groups=[]
def absolute_refs(x):
 if isinstance(x,dict):
  if 'file' in x and isinstance(x['file'],str) and not Path(x['file']).is_absolute():x['file']=str((source.parent/x['file']).resolve())
  for v in x.values():absolute_refs(v)
 elif isinstance(x,list):
  for v in x:absolute_refs(v)
for q in array_items(source,'groups'):
 if any(i>=first for i in q['rows']):
  assert all(i>=first for i in q['rows']);q['rows']=[i-first for i in q['rows']];absolute_refs(q);groups.append(q)
fixture['groups']=groups;p.write_text(json.dumps(fixture,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(dict(groups=len(groups),rows=sum(len(q['rows']) for q in groups),ranks=sum(q['rank'] for q in groups))))
