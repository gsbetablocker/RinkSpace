from pathlib import Path
import zipfile,json,hashlib
root=Path(r'D:/OneDrive/codex_projs/RinkSpace')
run=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a')
out=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/scope_archives')
recipe=json.loads((run/'board_source_role_and_operator_recipe_v1.json').read_text())
refs=recipe['code_refs']
z=zipfile.ZipFile(r'D:/CodexData/RinkSpace_Data/pro/Okada_Full9_PRO_Audit_20261019.zip')
relocations=[]
for ref in refs:
 p=Path(ref.get('file',ref.get('path')))
 if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==ref['sha256']:continue
 candidates=[n for n in z.namelist()if n.endswith('/'+p.name)]
 matches=[n for n in candidates if hashlib.sha256(z.read(n)).hexdigest()==ref['sha256']]
 if len(matches)!=1:raise ValueError(('no exact historical executed bytes',str(p),candidates))
 dest=out/(ref['sha256'][:12]+'_'+p.name)
 if dest.exists():assert hashlib.sha256(dest.read_bytes()).hexdigest()==ref['sha256']
 else:dest.write_bytes(z.read(matches[0]))
 relocations.append(dict(original=ref,archive=dict(file=str(dest),sha256=ref['sha256'])))
(out/'relocations.json').write_text(json.dumps(relocations,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(relocations,ensure_ascii=False))
