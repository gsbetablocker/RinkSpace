import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.reference_source_append import append_constraint_source_chunks
from rinkfit_joint.qualified_scope_append import rebind_qualified_board_certificate
from rinkfit_joint.io_utils import file_sha256
run=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a');rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');bundlepath=run/'recovery_tracklet_qualified_v2/manifest.json';bundle=json.loads(bundlepath.read_text());bundleref=dict(file=str(bundlepath),sha256=file_sha256(bundlepath));parent=rec/'scope_ready/packet.json'
def finalize(packet,folder):return rebind_qualified_board_certificate(parent,packet,folder,bundleref)
r=append_constraint_source_chunks(parent,bundle['closed_chunks'],bundle['model']['file'],bundle['material_map']['file'],run/'roles/frame_roles.json',rec/'scope_entities',finalize_packet=finalize,typed_entity_qualification=bundle['typed_entity_qualification'])
print(json.dumps(r,ensure_ascii=False,indent=2))
