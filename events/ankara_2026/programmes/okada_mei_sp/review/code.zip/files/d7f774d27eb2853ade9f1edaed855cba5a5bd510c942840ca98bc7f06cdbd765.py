import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json,time,numpy as np
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.reference_source_append import append_constraint_source_chunks
from rinkfit_joint.qualified_scope_append import rebind_qualified_board_certificate
from rinkfit_joint.io_utils import file_sha256,write_json
rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');parent=rec/'g5_ice/packet.json';bundlepath=rec/'ice_temporal_v1/qualified/manifest.json';bundle=json.loads(bundlepath.read_text());passed=rec/'g5_ice/native_qualification.json'
assert file_sha256(parent)=='a5e83beb94f67e032070768585a4a5c5b5b92b1b84a8314c5f0ed75ed2e11b57'
def ref(p):return dict(file=str(p),sha256=file_sha256(p))
assert file_sha256(bundlepath)=='6e39b8ee243e02ef40077c77597cdc437aa04e8397f5cc439205a13c1ba4129f'
assert json.loads((bundlepath.parent/'cross_bundle_alias_QA.json').read_text())['passed'] if (bundlepath.parent/'cross_bundle_alias_QA.json').exists() else False
parentpass=ref(passed);bundleref=ref(bundlepath);acq=json.loads(Path(bundle['acquisition']['file']).read_text());roles=acq['source_roles']['file'];start=time.monotonic()
def finalize(packet,folder,immutable_parent):
 n=int(immutable_parent['row_count']);assert n==904488 and packet['row_count']==904536
 oldg=immutable_parent['groups'];newg=packet['groups']
 for a,b in zip(oldg,newg[:len(oldg)]):
  assert a['rows']==b['rows'] and a['rank']==b['rank'] and a['statistic_kind']==b['statistic_kind']
  if isinstance(a['W'],dict):
   assert all(a['W'].get(k)==b['W'].get(k) for k in ('sha256','shape','dtype','offset_bytes'))
  else:assert a['W']==b['W']
 for g in newg[len(oldg):]:assert g['rank']==0 and g['W']==[] and g['unknown_noise_source_refs']
 result=rebind_qualified_board_certificate(parent,packet,folder,bundleref,parent_document=immutable_parent,native_parent_qualification_ref=parentpass)
 def array(name):
  d=result['arrays'][name];return np.memmap(d['file'],dtype=d['dtype'],mode='r',offset=int(d.get('offset_bytes',0)),shape=tuple(d['shape']))
 ad,role,kind,shot,mat,uv,pts=(array(k)for k in ('admission','fit_role','kind','shot_index','material_index','uv','native_pts'))
 assert np.all(ad[n:]==1) and np.all(role[n:]==1) and np.all(kind[n:]==0)
 before={};after={};delta={}
 for j,sid in enumerate(packet['shot_ids']):
  was=(ad[:n]==1)&(role[:n]==1)&(shot[:n]==j);now=(ad==1)&(role==1)&(shot==j)
  before[sid]=int(was.sum());after[sid]=int(now.sum());delta[sid]=after[sid]-before[sid]
 expected={s:bundle['by_shot'].get(s,0)for s in packet['shot_ids']};assert delta==expected
 prefix_qa=dict(schema='rinkfit.ice_incremental_append_prefix_QA.v1',passed=True,parent_packet=ref(parent),appended_raw_rows=48,old_raw_rows=n,new_raw_rows=packet['row_count'],new_kind0_ice_rows=48,new_active_rows=48,active_before_by_shot=before,active_after_by_shot=after,active_delta_by_shot=delta,all_old_numeric_prefixes_including_UV_admission_and_four_aux_byte_identical=True,source_ID_and_dataset_prefixes_identical=True,all_old_W_groups_and_descriptors_preserved=True,old_197_advert_corner_sources_retained=True,new_statistical_rank=0,new_precision_invented=False,inherited_native_qualification_ref=parentpass,old_material_qualification_rescanned=False,native_new_generation_check_pending=True)
 write_json(folder/'prefix_QA.json',prefix_qa)
 return result
report=append_constraint_source_chunks(parent,bundle['closed_chunks'],bundle['model']['file'],bundle['material_map']['file'],roles,rec/'g6_ice',finalize_packet_with_parent=finalize)
write_json(rec/'g6_ice/append_execution.json',dict(actual_pid=os.getpid(),returncode=0,elapsed_seconds=time.monotonic()-start,packet=report['packet'],native_parent_qualification_ref=parentpass,no_old_RGB_qualification_replay=True,no_MC=True,no_fit=True))
print(json.dumps(dict(packet=report['packet'],raw=report['raw_rows'],active=report['active_rows'],increment=report['by_shot'],seconds=time.monotonic()-start),ensure_ascii=False),flush=True)
