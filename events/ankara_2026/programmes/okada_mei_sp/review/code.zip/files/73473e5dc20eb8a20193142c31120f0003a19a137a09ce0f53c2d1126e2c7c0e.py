import sys,pathlib,json,traceback
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src'),str(root/'calibration/program_tracking')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
from rinkfit_joint.joint_solver import execute_explicit
raise SystemExit(execute_explicit(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/build_v4/joint_fit.exe',r'D:/CodexData/RinkSpace_Data/runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/source_supported_model.json',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/scope_ready/packet.json',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/motion_g1',config=r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/motion_config.json',engineering_recovery=True))
