import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import sys,json
from pathlib import Path
R=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(R/'calibration/rinkfit/src'))
from rinkfit_joint.grid_baseline_init import initialize_grid
W=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
report=initialize_grid(W/'grid_input_v1/model.json',W/'ice_grid_nav8a28_v1/manifest.json',Path('D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/roles/frame_roles.json'),W/'grid_init_curve_v1')
print(json.dumps(report),flush=True)
