from pathlib import Path
import sys,json,hashlib
import numpy as np,cv2,av
from scipy.optimize import minimize_scalar
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.joint_model import as_event_view,graph_from_joint
from rinkfit_joint.camera_graph import CameraGraph
from rinkfit_start.native_scene import NativeScene
from rinkfit_joint.io_utils import write_json
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');out=rec/'s01_worst_station_v1';out.mkdir(exist_ok=False)
n=904536
def raw(name,dt,shape=None):return np.memmap(rec/'g6_ice'/(name+'.bin'),dtype=dt,mode='r',shape=shape or (n,))
uvs=raw('uv','<f8',(n,2));mis=raw('material_index','<u4');ptss=raw('native_pts','<i8');kinds=raw('kind','u1')
states=[('baseline_plus_g3',rec/'init_g6_v2/initial_state'),('shared_g4',rec/'shared_g4/candidate')]
models={name:json.loads((state/'model.json').read_text())for name,state in states}
graphs={name:CameraGraph(graph_from_joint(m))for name,m in models.items()}
scenes={name:NativeScene(as_event_view(m,'s01'))for name,m in models.items()}
scope=json.loads(Path('D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/programme_scope.json').read_text())
results=[]
for i in [11476,110894,159308]:
 pts=int(ptss[i]);mi=int(mis[i]);q=uvs[i].copy();entry=dict(row=i,native_pts=pts,source_uv=q.tolist(),kind=int(kinds[i]),material_label=models['shared_g4']['materials'][mi]['label'],states={})
 with av.open(scope['source']['path'])as cont:
  st=cont.streams.video[0];cont.seek(pts,stream=st,backward=True,any_frame=False)
  for frame in cont.decode(st):
   if int(frame.pts)==pts:bgr=frame.to_ndarray(format='bgr24');break
   if int(frame.pts)>pts:raise ValueError('native frame missing')
 canvas=bgr.copy();cv2.drawMarker(canvas,tuple(np.rint(q).astype(int)),(0,255,0),cv2.MARKER_CROSS,22,2)
 for si,(name,state)in enumerate(states):
  station=float(np.memmap(state/'explicit_nuisance/station.f64',dtype='<f8',mode='r')[i]);pa=int(np.memmap(state/'explicit_nuisance/path.u32',dtype='<u4',mode='r')[i])
  camera=graphs[name].native_camera('s01');scene=scenes[name];local=float(graphs[name].local_seconds('s01',np.array([pts]))[0])
  def project(ss):
   world=scene.world(mi,pa,np.atleast_1d(ss));v=np.full(len(world),q[1])
   for _ in range(20):
    a=camera.at(world,local+camera.tau*(v/1079-.5));nv=a['uv'][:,1]
    if np.max(np.abs(nv-v),initial=0)<1e-10:v=nv;break
    v=nv
   a=camera.at(world,local+camera.tau*(v/1079-.5))
   valid=a['valid']&(v>=0)&(v<=1079)&(np.abs(v-a['uv'][:,1])<1e-7)
   return a['uv'],valid
  def objective(s):
   pp,good=project(s);return float(np.linalg.norm(pp[0]-q))if good[0]else np.inf
  grid=np.unique(np.r_[np.linspace(0,1,4097),station]);pp,good=project(grid);err=np.linalg.norm(pp-q,axis=1);err[~good]=np.inf;j=int(np.argmin(err));lo=grid[max(j-1,0)];hi=grid[min(j+1,len(grid)-1)]
  best=minimize_scalar(objective,bounds=(lo,hi),method='bounded',options={'xatol':1e-13})
  stbest=float(best.x)if best.fun<err[j]else float(grid[j]);pbest,valid=project(stbest);pcur,gcur=project(station)
  entry['states'][name]=dict(current_station=station,current_predicted_uv=pcur[0].tolist(),current_native_error_px=objective(station),best_same_path_station=stbest,best_same_path_error_px=objective(stbest),best_predicted_uv=pbest[0].tolist(),material_path_unchanged=True,native_UV_unchanged=True,qualification_or_station_update_issued=False)
  color=(255,180,0)if si==0 else (0,0,255)
  for jj in range(len(grid)-1):
   if good[jj] and good[jj+1] and np.max(np.abs(pp[jj:jj+2]))<1e6:cv2.line(canvas,tuple(np.rint(pp[jj]).astype(int)),tuple(np.rint(pp[jj+1]).astype(int)),color,2,cv2.LINE_AA)
  if gcur[0]:cv2.arrowedLine(canvas,tuple(np.rint(q).astype(int)),tuple(np.rint(pcur[0]).astype(int)),color,2,tipLength=.1)
  cv2.putText(canvas,f'{name} current={objective(station):.3f}px best same path={objective(stbest):.3f}px',(25,45+si*35),cv2.FONT_HERSHEY_SIMPLEX,.8,color,2,cv2.LINE_AA)
 cv2.imwrite(str(out/f'row{i}_PTS{pts}.png'),canvas);results.append(entry)
write_json(out/'source_station_diagnosis.json',dict(model_states={k:str(v/'model.json')for k,v in states},rows=results,same_material_path_held=True,source_uv_modified=False,numerical_diagnosis_only=True))
print(json.dumps(results),flush=True)
