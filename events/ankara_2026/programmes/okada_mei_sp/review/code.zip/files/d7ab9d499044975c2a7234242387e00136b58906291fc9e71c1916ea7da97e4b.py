from pathlib import Path
import sys,json,time
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.joint_solver import execute_explicit
from rinkfit_joint.io_utils import write_json,file_sha256
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
while not (rec/'shared_g8_exit.json').exists():time.sleep(1)
assert json.loads((rec/'shared_g8_exit.json').read_text())['code']==0
cfg=json.loads((rec/'shared_g8_config.json').read_text())
cfg.update(parameter_stage='optics',reinitialize_native_auxiliaries=False,
 resume_engineering_checkpoint=str(rec/'shared_g8/candidate/engineering_checkpoint.json'),
 resume_engineering_outer_state=str(rec/'shared_g8/candidate/engineering_outer.json'))
write_json(rec/'optics_g8_config.json',cfg)
write_json(rec/'optics_g8_transition.json',dict(source_packet_sha256=file_sha256(rec/'g8_bound/packet.json'),
 complete_primal_checkpoint=dict(file=str(rec/'shared_g8/candidate/engineering_checkpoint.json'),sha256=file_sha256(rec/'shared_g8/candidate/engineering_checkpoint.json')),
 engineering_outer=dict(file=str(rec/'shared_g8/candidate/engineering_outer.json'),sha256=file_sha256(rec/'shared_g8/candidate/engineering_outer.json')),
 source_members_W_Query_UV_E_and_numerical_precision_unchanged=True,all_nine_shots_and_shared_geometry_remain_open=True,
 newly_opened='three existing rig optics12 blocks',dual_or_penalty_reset=False,source_qualification_granted=False))
print('Continuing all nine shots with existing extra optics, exact complete primal and engineering outer context.',flush=True)
raise SystemExit(execute_explicit(str(rec/'build_v11/joint_fit.exe'),str(rec/'recovery_input_g8_model.json'),str(rec/'g8_bound/packet.json'),str(rec/'optics_g8'),config=str(rec/'optics_g8_config.json'),engineering_recovery=True))
