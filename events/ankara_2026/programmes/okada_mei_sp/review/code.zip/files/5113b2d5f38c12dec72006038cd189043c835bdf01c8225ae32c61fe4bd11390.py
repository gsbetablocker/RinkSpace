import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,sys,time
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.io_utils import file_sha256,write_json
from rinkfit_joint.qualified_scope import compile_active_qualified_scope
run=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a');out=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
p=run/'board_physical_requalification_parallel_v1/partial_manifest.json';parent=json.loads(p.read_text());ref=parent['closed_chunks'][0];chunk=json.loads(Path(ref['file']).read_text())
primary={**parent,'status':'incremental_consumption_of_existing_closed_chunk','completed_exposures':chunk['exposures'],'closed_chunks':[ref],'raw_original_rows':chunk['source_rows'],'status_counts':chunk['status_counts'],'canonical_status_counts':chunk['canonical_status_counts'],'source_parent_partial_ref':dict(file=str(p),sha256=file_sha256(p)),'complete_full6006_scope':False,'all_original_sources_accounted':False}
manifest=out/'primary_first_closed_chunk.json';write_json(manifest,primary)
report=compile_active_qualified_scope(run/'all6006_fixed425_C0material24_closed3875_conditional_bound_v1/packet.json',manifest,run/'board_legacy_mask_provenance_v1/manifest.json',run/'programme_scope.json',out/'scope_fast2',prepared_index_ref=dict(file=str(out/'scope_fast/prepared_index.json'),sha256=file_sha256(out/'scope_fast/prepared_index.json')),dependency_relocations=json.loads((out/'scope_archives/relocations.json').read_text()))
print(json.dumps(report,ensure_ascii=False,indent=2))
