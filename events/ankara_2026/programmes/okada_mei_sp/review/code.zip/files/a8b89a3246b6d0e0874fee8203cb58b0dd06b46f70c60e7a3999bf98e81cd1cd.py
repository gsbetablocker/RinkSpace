"""Prepare and run initialization-only d78/G9 auxiliary reconstruction.

Root must review the complete paired-grid model before invoking this script.
This entry never starts Ceres optimization, mutates a source packet, reuses an
accepted-state binding from another model, changes flags, or resumes old duals.
"""
from __future__ import annotations
import argparse,hashlib,json,mmap,os,sys
from pathlib import Path

ROOT=Path('D:/OneDrive/codex_projs/RinkSpace')
DATA=Path('D:/CodexData/RinkSpace_Data')
WORK=DATA/'runs/okada_rec_1019'
PACKET=WORK/'g9_ice/packet.json'
PACKET_SHA='856fd7a939ce674e10494fbc32cf20023333f02150cae6af2a5937598b842a49'
COMPLETE=DATA/'runs/okada_s1_r11/temporal_1018/local_m4_iter3_scope_full2/complete_state_manifest.json'
COMPLETE_SHA='3e04f3c2e4bb6b1a19989dc4b4f93ffa0f591e3c1a57c8162a67a60c054499d9'
FLAGS_REFERENCE=DATA/'runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/navigation_model.json'
BACKEND=WORK/'build_v14/joint_fit.exe'
EXPECTED_S01_ACTIVE=181840

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def ref(path):
    p=Path(path).resolve()
    return dict(file=str(p),sha256=sha(p))

def structural_flags(model):
    return dict(blocks=[dict(name=b['name'],constant=bool(b.get('constant',False)),fixed_indices=b.get('fixed_indices',[])) for b in model['blocks']],
        linear_control_manifolds=model.get('linear_control_manifolds',[]),
        control_coordinates={sid:s.get('control_coordinates') for sid,s in model['shots'].items()})

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def motion_flag_status(model):
    baseline=json.loads(FLAGS_REFERENCE.read_text('utf-8-sig'))
    old={b['name']:b for b in baseline['blocks']};extra=[]
    for b in model['blocks']:
        if not b['name'].startswith('shot/') or b['name'] not in old:
            continue
        a=old[b['name']]
        became_constant=bool(b.get('constant',False)) and not bool(a.get('constant',False))
        extra_fixed=sorted(set(b.get('fixed_indices',[]))-set(a.get('fixed_indices',[])))
        if became_constant or extra_fixed:
            extra.append(dict(block=b['name'],extra_constant=became_constant,extra_fixed_indices=extra_fixed))
    existing=model.get('source_supported_motion_flags',{})
    return dict(source_supported_flags_packet_sha256=existing.get('packet_sha256'),
        flags_already_bound_to_current_G9=existing.get('packet_sha256')==PACKET_SHA,
        source_supported_motion_flags_applied_by_this_runner=False,
        input_flags_and_manifolds_passed_through_exactly=True,
        original_complete_flags_reference=ref(FLAGS_REFERENCE),additional_freezes_relative_to_complete_reference=extra,
        S01_manifold_equal_to_complete_reference=model.get('linear_control_manifolds',[])==baseline.get('linear_control_manifolds',[]),
        review_before_future_full_fit=existing.get('packet_sha256')!=PACKET_SHA or bool(extra),
        reason='apply_source_supported_motion_flags only adds freezes and can restrict an existing S01 tangent basis; it cannot safely unfreeze a previously restricted generation. No automatic flag or manifold rewrite is performed here.')

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',type=Path,required=True,help='Complete paired-grid model already reviewed by root; read-only input')
    parser.add_argument('--out',type=Path,required=True,help='New immutable initialization generation under the Data root')
    args=parser.parse_args(argv)
    model_file=args.model.resolve();out=args.out.resolve()
    if not model_file.is_file():raise FileNotFoundError(model_file)
    if out.exists():raise FileExistsError('Immutable initialization generation exists: '+str(out))
    if not out.is_relative_to(DATA.resolve()):raise ValueError('Bulk auxiliary/checkpoint output must be under the registered Data root')
    if sha(PACKET)!=PACKET_SHA:raise ValueError('Current qualified unbound G9 packet changed; explicit source-generation review required')
    if sha(COMPLETE)!=COMPLETE_SHA:raise ValueError('d78 complete state manifest changed')
    # Do not parse/clone a large packet or remove its accepted binding. The exact
    # immutable unbound source generation is mandatory, and a bound packet fails.
    with PACKET.open('rb') as stream:
        with mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as document:
            if document.find(b'"accepted_explicit_state_binding"')>=0:
                raise ValueError('Accepted-state-bound packet cannot be used with a new physical model; do not bypass that guard')
    os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    sys.dont_write_bytecode=True
    sys.path[:0]=[str(ROOT/'src'),str(ROOT/'calibration/rinkfit/src')]
    from rinkfit_joint.baseline_auxiliary import build_d78_auxiliary_import
    from rinkfit_joint.joint_solver import execute_explicit
    from rinkfit_joint.io_utils import write_json
    approved_model=ref(model_file);m=json.loads(model_file.read_text('utf-8-sig'))
    if set(m['shots'])!={'s01','s02','s03','s04','s05','s06','s07','s08','s09'} or len(m['rigs'])!=3:
        raise ValueError('Complete nine-shot / three-rig model required')
    flags_before=digest(structural_flags(m));flag_report=motion_flag_status(m)
    out.mkdir(parents=True)
    baseline_dir=out/'baseline_aux'
    imported=build_d78_auxiliary_import(PACKET,model_file,COMPLETE,baseline_dir)
    if imported['preserved_active_rows']!=EXPECTED_S01_ACTIVE:
        raise ValueError('Current exact S01 active denominator changed; no partial restoration allowed')
    if sha(model_file)!=approved_model['sha256'] or sha(PACKET)!=PACKET_SHA:
        raise ValueError('Reviewed immutable model or source changed during preparation')
    cfg=dict(objective_id='engineering_recovery_native_pixel_v1',parameter_stage='optics',
        physical_constraint_penalty=10.,num_threads=8,reinitialize_native_auxiliaries=True,
        baseline_auxiliary_manifest=ref(baseline_dir/'manifest.json'),initialization_only=True,
        engineering_primal_tolerance=1e-8,engineering_equality_tolerance=1e-8)
    config_file=out/'initialization_config.json';write_json(config_file,cfg)
    binding=dict(schema='rinkfit.paired_grid_G9_d78_auxiliary_preparation.v1',
        reviewed_model=approved_model,qualified_unbound_packet=ref(PACKET),complete_d78_state=ref(COMPLETE),
        exact_auxiliary_manifest=cfg['baseline_auxiliary_manifest'],S01_preserved_active_rows=EXPECTED_S01_ACTIVE,
        source_UV_ID_PTS_material_Query_operator_checked_by_existing_import=True,
        input_model_flags_sha256=flags_before,motion_flag_review=flag_report,
        remaining_active_rows_policy='existing production initialize_recovery_auxiliaries; skip exact S01 mask and rebuild every other qualified row',
        configuration=ref(config_file),native_backend=ref(BACKEND),
        initialization_only=True,optimizer_will_not_run=True,old_outer_or_duals_resumed=False,
        accepted_explicit_state_binding_removed_or_bypassed=False,model_source_or_flags_mutated=False)
    write_json(out/'preparation_binding.json',binding)
    # The existing C++ production entry returns at initialization_only, before
    # GPU enabling, graph construction, inner optimization or outer dual updates.
    native=out/'native'
    code=execute_explicit(str(BACKEND),str(model_file),str(PACKET),str(native),config=str(config_file),engineering_recovery=True)
    if code:raise SystemExit(code)
    only=json.loads((native/'initialization_only_receipt.json').read_text())
    restored=json.loads((native/'baseline_auxiliary_restore.json').read_text())
    rebuilt=json.loads((native/'fresh_auxiliary_initialization/receipt.json').read_text())
    if only.get('solver_started') is not False or restored['preserved_native_rows']!=EXPECTED_S01_ACTIVE or rebuilt['preserved_auxiliary_rows_not_RS_recertified']!=EXPECTED_S01_ACTIVE:
        raise ValueError('Native initialization did not retain the complete exact S01 mask without optimization')
    if sha(model_file)!=approved_model['sha256'] or sha(PACKET)!=PACKET_SHA or digest(structural_flags(json.loads(model_file.read_text('utf-8-sig'))))!=flags_before:
        raise ValueError('Read-only approved inputs changed')
    # A later explicitly authorized production run can resume this complete new
    # initial checkpoint against the SAME approved model and UNBOUND G9 packet.
    # No accepted binding or historical optimizer state is carried forward.
    handoff=dict(schema='rinkfit.paired_grid_G9_initialized_state_handoff.v1',
        model=approved_model,packet=ref(PACKET),initial_checkpoint=ref(native/'initial_state/engineering_checkpoint.json'),
        initialization_receipt=ref(native/'initialization_only_receipt.json'),
        full_independent_RS_state=str(native/'initial_independent_RS_state'),
        exact_S01_restore_receipt=ref(native/'baseline_auxiliary_restore.json'),
        remaining_auxiliary_receipt=ref(native/'fresh_auxiliary_initialization/receipt.json'),
        future_config_fragment=dict(resume_engineering_checkpoint=str(native/'initial_state/engineering_checkpoint.json'),reinitialize_native_auxiliaries=False),
        do_not_add_resume_engineering_outer_state=True,full_fit_started=False,
        requires_actual_full_grid_visual_review_before_any_future_full_fit=True,
        same_approved_model_and_packet_SHA_required=True,motion_flag_review=flag_report)
    write_json(out/'ready_state.json',handoff)
    print(json.dumps(dict(initialization_only_completed=True,optimizer_started=False,
        S01_exact_active_rows=EXPECTED_S01_ACTIVE,source_packet_sha256=PACKET_SHA,
        initialized_state=str(out/'ready_state.json'),motion_flags_mutated=False),ensure_ascii=False))
    return 0

if __name__=='__main__':raise SystemExit(main())
