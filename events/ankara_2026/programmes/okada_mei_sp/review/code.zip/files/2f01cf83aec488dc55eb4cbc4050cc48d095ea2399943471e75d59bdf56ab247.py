from pathlib import Path
import hashlib,json,os,subprocess,time,threading,psutil

def main():
 r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');recipe=json.loads((r/'compare_build_g5_v1/recipe.json').read_text());config=r/'v98_compare_g5_v1_config.json';cfg=json.loads(config.read_text());output=Path(cfg['output'])
 if output.exists():raise RuntimeError('immutable comparison output already exists')
 env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','');env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
 command=[str(r/'compare_build_g5_v1/joint_recovery_compare.exe'),'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/fit_full_source_v98/generation_1/model.json',str(r/'g5_ice/packet.json'),'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/all6006_fixed425_C0material24_closed3875_conditional_bound_v1/packet.json','D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/fit_full_source_v98/generation_1/explicit_nuisance/manifest.json',str(config)]
 peak_rss=0;peak_private=0;started=time.time();phase={'value':'starting'}
 with (r/'v98_compare_g5_v1.log').open('x',encoding='utf8') as log,(r/'v98_compare_g5_v1_memory.jsonl').open('x',encoding='utf8') as memory:
  child=subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace');proc=psutil.Process(child.pid)
  def capture():
   for line in child.stdout:
    log.write(line);log.flush()
    if line.startswith('{"comparison_phase":'):
     try:phase['value']=json.loads(line)['comparison_phase']
     except (ValueError,KeyError):pass
  worker=threading.Thread(target=capture);worker.start()
  while child.poll() is None:
   try:
    info=proc.memory_info();peak_rss=max(peak_rss,info.rss,getattr(info,'peak_wset',0));peak_private=max(peak_private,getattr(info,'private',0));memory.write(json.dumps({'elapsed_seconds':time.time()-started,'PID':child.pid,'phase':phase['value'],'rss_bytes':info.rss,'peak_rss_bytes':peak_rss,'private_bytes':getattr(info,'private',0),'peak_private_bytes':peak_private})+'\n');memory.flush()
   except psutil.Error:pass
   time.sleep(.5)
  result=child.wait();worker.join()
 receipt={'returncode':result,'command':command,'PID':child.pid,'peak_RSS_bytes':peak_rss,'peak_private_bytes':peak_private,'elapsed_seconds':time.time()-started,'last_phase':phase['value'],'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(Path(command[0]).read_bytes()).hexdigest(),'fit_started':False}
 with (r/'v98_compare_g5_v1_exit.json').open('x',encoding='utf8') as f:json.dump(receipt,f,indent=2)
 print(json.dumps(receipt));raise SystemExit(result)

if __name__=='__main__':main()
