import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json,time
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.io_utils import file_sha256,write_json
from rinkfit_joint.joint_solver import execute_explicit
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
while not (rec/'shared_g9_exit.json').exists():time.sleep(1)
assert json.loads((rec/'shared_g9_exit.json').read_text())['code']==0
assert json.loads((rec/'build_v14_exit.json').read_text())['code']==0
model=rec/'recovery_input_g9_model.json';packet=rec/'g9_bound/packet.json';candidate=rec/'shared_g9/candidate'
assert file_sha256(model)=='be66dcbfa5823f48884fa014b8d0560d20b5cd32edc42d0c2593e6c6b3ebccb9'
assert file_sha256(packet)=='c33853f94bee5a2589f3a22cbef1a0adb30755fef204058cd83f4fb38fb2a347'
cfg=json.loads((rec/'shared_g9_config.json').read_text())
for key in ('motion_navigation_restart','coupled_motion_navigation_restart','finite_line_navigation_restart'):cfg.pop(key,None)
cfg['reinitialize_native_auxiliaries']=False
cfg['refine_query_navigation_seeds']=False
cfg['resume_engineering_checkpoint']=str(candidate/'engineering_checkpoint.json')
cfg['resume_engineering_outer_state']={'file':str(candidate/'engineering_outer.json'),'sha256':file_sha256(candidate/'engineering_outer.json')}
cfg['source_camera_mode_navigation']=json.loads((rec/'g9_actual_failures/S03_camera_mode_spec_g9.json').read_text())
write_json(rec/'camera_g9_config.json',cfg)
write_json(rec/'camera_g9_resume_identity.json',dict(model=dict(file=str(model),sha256=file_sha256(model)),packet=dict(file=str(packet),sha256=file_sha256(packet)),checkpoint=dict(file=str(candidate/'engineering_checkpoint.json'),sha256=file_sha256(candidate/'engineering_checkpoint.json')),outer=cfg['resume_engineering_outer_state'],no_source_or_dual_reset=True))
print('Resuming same G9 full state with source-supported S03 camera navigation',flush=True)
raise SystemExit(execute_explicit(str(rec/'build_v14/joint_fit.exe'),str(model),str(packet),str(rec/'camera_g9'),config=str(rec/'camera_g9_config.json'),engineering_recovery=True))
