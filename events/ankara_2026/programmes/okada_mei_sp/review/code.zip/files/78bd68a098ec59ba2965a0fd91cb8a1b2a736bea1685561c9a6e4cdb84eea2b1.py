from pathlib import Path
import sys,json,hashlib,time,os
from collections import Counter
ROOT=Path(r'D:/OneDrive/codex_projs/RinkSpace');DATA=Path(r'D:/CodexData/RinkSpace_Data');W=DATA/'runs/okada_rec_1019'
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'calibration/program_tracking'),str(ROOT/'calibration/rinkfit/src')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
import numpy as np,cv2
from rinkspace.vision_programme_ice_review import ice_curve_inventory
from rinkfit_joint.joint_model import as_event_view
from rinkfit_start.native_scene import NativeScene
from projection import project_fast

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def ref(p):return dict(file=str(Path(p).resolve()),sha256=sha(p))
def write(p,x):
 with Path(p).open('x',encoding='utf8')as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write(chr(10))

def main():
 start=time.perf_counter();out=W/'ice_grid_nav8a28_v1'
 if out.exists():raise FileExistsError(out)
 navdir=W/'nav_8a28_v1';navmanifest=read(navdir/'manifest.json');assert sha(navdir/'navigation.npz')==navmanifest['output']['sha256']
 oldpath=Path(navmanifest['source_scene']['path']);assert sha(oldpath)==navmanifest['source_scene']['sha256'];old=read(oldpath)
 currentpath=DATA/'runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/navigation_model.json';current=read(currentpath);current_scene=NativeScene(as_event_view(current,'s01'))
 inventory=ice_curve_inventory(old);oldby={x['curve_id']:x for x in inventory};featureby={f['id']:f for f in old['ice_features']};matched=[];unmatched=[]
 for mi,m in enumerate(current['materials']):
  if not m['label'].startswith('ice.'):continue
  cid=m['label'][4:];o=oldby.get(cid)
  if o is None:unmatched.append(dict(current_material_index=mi,label=m['label'],reason='old_frozen_scene_has_no_identical_curve_id'));continue
  if o['operator']=='unresolved':unmatched.append(dict(current_material_index=mi,label=m['label'],reason='old_material_boundary_semantic_unresolved_no_forced_pair'));continue
  if len(m['paths'])!=1 or m['paths'][0]['kind']not in(0,1):unmatched.append(dict(current_material_index=mi,label=m['label'],reason='no_single_same_primitive_path_for_this_minimal_navigation'));continue
  p=m['paths'][0];provenance=json.loads(p['provenance']);descriptor=provenance.get('descriptor',provenance.get('source_descriptor',{}))
  if descriptor.get('curve_id')!=cid:unmatched.append(dict(current_material_index=mi,label=m['label'],reason='current_provenance_does_not_bind_identical_old_curve_id'));continue
  if (p['kind']==1)!=(featureby[o['feature_id']]['kind']=='circle'):raise ValueError('Line/circle identity mismatch '+cid)
  if p['kind']==1 and (p.get('start_angle',0.)!=0. or abs(p.get('end_angle',2*np.pi)-2*np.pi)>1e-12):raise ValueError('Unmatched circle angle chart '+cid)
  xyz=np.asarray(o['xyz'],float);station=np.linspace(0.,1.,len(xyz));world=current_scene.world(mi,0,station)
  if len(xyz)<2 or not np.isfinite(world).all():raise ValueError('Invalid paired geometry '+cid)
  matched.append(dict(crosswalk_index=len(matched),curve_id=cid,feature_id=o['feature_id'],world_curve_role=o['world_curve_role'],measurement_operator=o['operator'],current_material_index=mi,current_path_index=0,current_path_id=p['id'],current_path_kind=p['kind'],same_entity_basis='existing current path provenance curve_id exactly equals frozen old inventory curve_id; fixed physical feature/layer role; no nearest-shape reassignment',station_correspondence='same ordered finite curve parameter; full circle uses angle 2*pi*station; named straight uses original endpoint order',provenance_descriptor=descriptor,source_qualification_granted=False,old_xyz=xyz,current_world=world,station=station))
 old_unmapped=[dict(curve_id=o['curve_id'],operator=o['operator'],reason='no_confirmed_current_material_pair_in_selected_model')for o in inventory if o['curve_id']not in {x['curve_id']for x in matched}]
 if not matched:raise ValueError('No existing same-entity ice crosswalk')
 oldxyz=np.concatenate([x['old_xyz']for x in matched]);world=np.concatenate([x['current_world']for x in matched]);stations=np.concatenate([x['station']for x in matched]);cross=np.concatenate([np.full(len(x['station']),x['crosswalk_index'],np.int16)for x in matched]);material=np.concatenate([np.full(len(x['station']),x['current_material_index'],np.int32)for x in matched]);paths=np.zeros(len(material),np.int16);ends=np.r_[0,np.cumsum([len(x['station'])for x in matched])]
 crossdoc=[{k:v for k,v in x.items()if k not in('old_xyz','current_world','station')}for x in matched]
 out.mkdir();write(out/'crosswalk.json',dict(schema='rinkfit.old_grid_same_entity_navigation_crosswalk.v1',old_scene=ref(oldpath),current_model=ref(currentpath),role_contract=ref(ROOT/'events/ankara_2026/model_constraints/paint_roles_1018.json'),old_inventory_paths=len(inventory),paired_paths=crossdoc,unpaired_current=unmatched,unpaired_old=old_unmapped,old_model_pixels_are_not_source_observations=True,old_geometry_or_rejected_relations_imported=False))
 with np.load(navdir/'navigation.npz',allow_pickle=False)as n:
  pts=n['native_pts'];shot=n['shot_number'];rig=n['rig_number'];kind=n['navigation_kind'];cams=n['old_camera25_scene_units'];nR=n['navigation_R_world_to_camera'];nC=n['navigation_C_normalized'];nlog=n['navigation_log_f_native_pixels'];L=float(n['normalization_L']);origin=n['normalization_origin']
  templates={r:cams[np.flatnonzero((rig==r)&np.isfinite(cams[:,0]))[0]].copy()for r in range(3)}
  streams={name:(out/(name+'.bin')).open('xb')for name in('target_uv','current_world','station','material_index','path_index','crosswalk_index')};offsets=[0];frame_count=[];frame_curve_count=[];counts=Counter();M=0
  try:
   for fi in range(len(pts)):
    if kind[fi]==0:offsets.append(M);frame_count.append(0);frame_curve_count.append(0);continue
    c=cams[fi].copy()
    if not np.isfinite(c).all():
     c=templates[int(rig[fi])].copy();c[:3]=nC[fi]*L+origin;c[3:6]=cv2.Rodrigues(nR[fi])[0].ravel();c[6:8]=nlog[fi]
    uv,depth=project_fast(c,oldxyz);visible=np.isfinite(uv).all(1)&(depth>.05)&(uv[:,0]>=0)&(uv[:,0]<=1919)&(uv[:,1]>=0)&(uv[:,1]<=1079);indices=[];curves=0
    # This freezes a small numerical navigation set only. It does not sample or remove any actual fitting observation.
    for lo,hi in zip(ends[:-1],ends[1:]):
     candidate=np.flatnonzero(visible[lo:hi])+lo
     if not len(candidate):continue
     chosen=[int(candidate[0])]
     for j in candidate[1:]:
      if np.linalg.norm(uv[j]-uv[chosen[-1]])>=64.:chosen.append(int(j))
     if candidate[-1]!=chosen[-1]and np.linalg.norm(uv[candidate[-1]]-uv[chosen[-1]])>=16.:chosen.append(int(candidate[-1]))
     indices.extend(chosen);curves+=1
    ii=np.asarray(indices,np.int64);arrays=dict(target_uv=uv[ii].astype('<f8'),current_world=world[ii].astype('<f8'),station=stations[ii].astype('<f8'),material_index=material[ii].astype('<i4'),path_index=paths[ii].astype('<i2'),crosswalk_index=cross[ii].astype('<i2'))
    for key,a in arrays.items():a.tofile(streams[key])
    M+=len(ii);offsets.append(M);frame_count.append(len(ii));frame_curve_count.append(curves);counts[str(int(shot[fi]))]+=len(ii)
    if fi%1000==0:print(json.dumps(dict(frame=fi,total_frames=len(pts),paired_navigation_points=M,elapsed_seconds=time.perf_counter()-start)),flush=True)
  finally:
   for f in streams.values():f.close()
  framearrays=dict(frame_native_pts=pts.astype('<i8'),frame_shot_number=shot.astype('u1'),frame_navigation_kind=kind.astype('u1'),frame_offsets=np.asarray(offsets,dtype='<i8'),frame_point_count=np.asarray(frame_count,dtype='<i4'),frame_curve_count=np.asarray(frame_curve_count,dtype='<i2'))
  for key,a in framearrays.items():
   with(out/(key+'.npy')).open('xb')as f:np.save(f,a,allow_pickle=False)
 fields={key:dict(dtype=dtype,shape=shape,storage='raw_binary_C_order',**ref(out/(key+'.bin')))for key,dtype,shape in [('target_uv','<f8',[M,2]),('current_world','<f8',[M,3]),('station','<f8',[M]),('material_index','<i4',[M]),('path_index','<i2',[M]),('crosswalk_index','<i2',[M])]}
 fields.update({key:dict(dtype=str(a.dtype),shape=list(a.shape),storage='npy_memmap',**ref(out/(key+'.npy')))for key,a in framearrays.items()})
 nonzero=np.asarray(frame_count)[np.asarray(frame_count)>0];byshot={}
 for sn in range(2,10):
  ss=shot==sn;byshot['s%02d'%sn]=dict(frames=int(ss.sum()),frames_with_navigation_points=int((np.asarray(frame_count)[ss]>0).sum()),points=int(np.asarray(frame_count)[ss].sum()),unresolved_mapping_frames=int(((kind==0)&ss).sum()))
 totalbytes=sum(Path(x['file']).stat().st_size for x in fields.values())
 doc=dict(schema='rinkfit.old_ice_pixel_layout_navigation.v1',purpose='numerical initializer only: match old rendered ice pixel layout using current d78 same-entity world points; not R/C/K targets or source observations',old_navigation_manifest=ref(navdir/'manifest.json'),old_scene=ref(oldpath),current_model=ref(currentpath),crosswalk=ref(out/'crosswalk.json'),extractor=ref(__file__),fields=fields,old_inventory_paths=len(inventory),paired_paths=len(matched),unpaired_old_paths=len(old_unmapped),frames=len(pts),points=M,point_counts_per_nonempty_frame=dict(minimum=int(nonzero.min()),median=float(np.median(nonzero)),maximum=int(nonzero.max())),by_shot=byshot,array_bytes=totalbytes,elapsed_seconds=time.perf_counter()-start,numeric_dtype='float64',sample_policy='all available native frames; same-entity visible old renderer curve samples spatially thinned at 64 native pixels, end sample when >=16 pixels; only numerical navigation, actual source fitting denominator unchanged',row_time='target UV is old central renderer layout; current initializer must use its signed tau and target_v row time',consumer_must_apply_existing_FrameRoleGuard=True,source_observation=False,source_qualification_or_statistics_created=False,raw_source_UV_W_Query_changed=False,old_scene_geometry_parameters_or_constraints_imported=False,current_S01_shared_scene_or_camera_family_changed=False,legacy_camera_parameters_used_only_inside_old_renderer=True,source_accuracy_accepted=False)
 write(out/'manifest.json',doc);print(json.dumps(dict(output=str(out),paired_paths=len(matched),old_paths=len(inventory),frames=len(pts),points=M,bytes=totalbytes,seconds=doc['elapsed_seconds'],by_shot=byshot)),flush=True)
if __name__=='__main__':main()
