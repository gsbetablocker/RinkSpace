from pathlib import Path
from collections import Counter
import sys,json,hashlib,time
ROOT=Path(r'D:/OneDrive/codex_projs/RinkSpace');DATA=Path(r'D:/CodexData/RinkSpace_Data');W=DATA/'runs/okada_rec_1019';RESULT=DATA/'events/ankara_2026/programmes/okada_mei_sp/results'
sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'calibration/program_tracking'),str(ROOT/'calibration/rinkfit/src')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
import numpy as np,cv2
from rinkspace.vision_programme_ice_review import ice_curve_inventory
from rinkfit_joint.joint_model import as_event_view
from rinkfit_start.native_scene import NativeScene
from projection import project_fast
from calibration.program_tracking.demo_camera_patch import apply_patch,world_plane_homography,project_xy
from calibration.program_tracking.demo_outro import plane_homography

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def ref(p):return dict(file=str(Path(p).resolve()),sha256=sha(p))
def write(p,x):
 with Path(p).open('x',encoding='utf8')as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write(chr(10))
def main():
 begin=time.perf_counter();out=W/'ice_grid_demo50_v1'
 if out.exists():raise FileExistsError(out)
 packet_path=RESULT/'demo_last_shot_20261016/source_packet.npz';receipt_path=packet_path.with_suffix('.json');patch_path=RESULT/'demo_full_20261016/v3/camera_patch.npz';patch_receipt=patch_path.with_suffix('.json');packet_receipt=read(receipt_path);patch_doc=read(patch_receipt)
 if sha(packet_path)!='4e5cb848873df4cb43f0a78f43deda17a445c6e60219111b9aa32d884c02a3ee' or sha(patch_path)!='e28e8b191c8eeb53d4bb1819ca1a1b3eb9f360d2f0540b8b6eea7f1994d22ccf':raise ValueError('Frozen actual Demo data identity changed')
 if sha(packet_path)!=packet_receipt['output']['sha256']or sha(patch_path)!=patch_doc['output']['sha256']or patch_doc['source_packet']['sha256']!=sha(packet_path):raise ValueError('Demo receipt/packet identity mismatch')
 with np.load(packet_path,allow_pickle=False)as a:p={k:a[k].copy()for k in a.files}
 expected=np.arange(256256,2415104+256,256,dtype=np.int64)
 if not(np.array_equal(p['pts'],expected)and np.array_equal(p['native_pts'],expected)and str(p['time_base'])=='1/12800'and str(p['native_fps'])=='50/1'and np.array_equal(p['time_seconds'],expected/12800.)):raise ValueError('Official native PTS changed')
 scope=read(W/'programme_scope.json')
 if packet_receipt['source']['sha256']!=scope['source']['sha256']:raise ValueError('Official source identity mismatch')
 patch=apply_patch(p,patch_path);covered=np.zeros(len(expected),'u1');changed=np.zeros(len(expected),'u1');covered[patch['source_packet_index']]=1;changed[patch['source_packet_index']]=patch['changed']
 if not np.array_equal(p['camera25'][patch['source_packet_index']],patch['camera25']):raise ValueError('Actual in-memory Demo override failed')
 crosswalk_path=W/'ice_grid_nav8a28_v1/crosswalk.json';crossdoc=read(crosswalk_path);originalmanifest=read(W/'ice_grid_nav8a28_v1/manifest.json')
 if sha(crosswalk_path)!=originalmanifest['crosswalk']['sha256']:raise ValueError('Frozen same-entity crosswalk changed')
 oldpath=Path(packet_receipt['inputs']['scene']['path']);currentpath=Path(crossdoc['current_model']['file'])
 if sha(oldpath)!=packet_receipt['inputs']['scene']['sha256']or sha(oldpath)!=crossdoc['old_scene']['sha256']or sha(currentpath)!=crossdoc['current_model']['sha256']:raise ValueError('Old renderer/current d78 scene identity changed')
 old=read(oldpath);current=read(currentpath);ns=NativeScene(as_event_view(current,'s01'));oldby={x['curve_id']:x for x in ice_curve_inventory(old)};pairs=crossdoc['paired_paths'];xyz=[];world=[];stations=[];mat=[];cross=[];before=[];after=[];ends=[0]
 for row in pairs:
  o=oldby[row['curve_id']];x=np.asarray(o['xyz'],float);s=np.linspace(0.,1.,len(x));j=np.arange(len(x));last=len(x)-1
  if row['current_path_kind']==1:
   k=j%last;left=(k-1)%last;right=(k+1)%last
  else:left=np.maximum(0,j-1);right=np.minimum(last,j+1)
  xyz.append(x);before.append(x[left]);after.append(x[right]);world.append(ns.world(row['current_material_index'],row['current_path_index'],s));stations.append(s);mat.append(np.full(len(x),row['current_material_index'],np.int32));cross.append(np.full(len(x),row['crosswalk_index'],np.int16));ends.append(ends[-1]+len(x))
 xyz=np.concatenate(xyz);before=np.concatenate(before);after=np.concatenate(after);world=np.concatenate(world);stations=np.concatenate(stations);mat=np.concatenate(mat);cross=np.concatenate(cross);ends=np.asarray(ends)
 keep=p['shot_index']!=1;frame_indices=np.flatnonzero(keep);pts=p['pts'][keep];shot=p['shot_index'][keep].astype('u1');bridge=p['bridge_mode'][keep];kind=np.where(bridge==0,1,np.where(bridge==1,3,np.where((bridge==2)|(bridge==3),4,2))).astype('u1');kind[changed[keep].astype(bool)]=2
 with np.load(W/'nav_8a28_v1/navigation.npz',allow_pickle=False)as a:prior_conflict=(a['mapping_status']==3).astype('u1');assert np.array_equal(a['native_pts'],pts)
 boundary=np.asarray(old['ice_boundary']['points_xyz'])[:,:2];low=boundary.min(0)-1.5;high=boundary.max(0)+1.5;span=high-low;scale=1535/float(span.max());texture_wh=tuple(max(2,int(round(z*scale))+1)for z in span);bounds=(*low,*high)
 tex=np.array([[span[0]/(texture_wh[0]-1),0,low[0]],[0,-span[1]/(texture_wh[1]-1),high[1]],[0,0,1.]])
 # Read-only exact algebra check against actual Sample.draw texture homography consumer; no textures/images generated.
 contract_error=0.
 for fi in (0,int(patch['source_packet_index'][0]),int(patch['source_packet_index'][-1]),len(expected)-1):
  h=world_plane_homography(p['camera25'][fi]);actual=plane_homography(p['camera25'][fi],bounds,texture_wh);via=h@tex;via/=via[2,2];contract_error=max(contract_error,float(np.max(np.abs(via-actual))))
 if contract_error>1e-8:raise ValueError('No-Brown consumer homography mismatch')
 out.mkdir();spec={'target_uv':('<f8',2),'current_world':('<f8',3),'station':('<f8',1),'material_index':('<i4',1),'path_index':('<i2',1),'crosswalk_index':('<i2',1),'normal':('<f8',2),'normal_valid':('u1',1),'normal_reason':('u1',1),'target_domain_valid':('u1',1)};files={k:(out/(k+'.bin')).open('xb')for k in spec};M=0;offsets=[0];counts=[];curve_counts=[];invalid=0;oldcompare=None
 try:
  for fi,source_index in enumerate(frame_indices):
   c=p['camera25'][source_index];h=world_plane_homography(c);uv=project_xy(h,xyz[:,:2]);R=cv2.Rodrigues(c[3:6])[0];depth=(xyz-c[:3])@R[2];visible=np.isfinite(uv).all(1)&(depth>.05)&(uv[:,0]>=0)&(uv[:,0]<=1919)&(uv[:,1]>=0)&(uv[:,1]<=1079);chosen=[];curves=0
   for lo,hi in zip(ends[:-1],ends[1:]):
    candidates=np.flatnonzero(visible[lo:hi])+lo
    if not len(candidates):continue
    selected=[int(candidates[0])]
    for j in candidates[1:]:
     if np.linalg.norm(uv[j]-uv[selected[-1]])>=64.:selected.append(int(j))
    if candidates[-1]!=selected[-1]and np.linalg.norm(uv[candidates[-1]]-uv[selected[-1]])>=16.:selected.append(int(candidates[-1]))
    chosen.extend(selected);curves+=1
   ii=np.asarray(chosen,np.int64);n=len(ii);previous=project_xy(h,before[ii,:2]);following=project_xy(h,after[ii,:2]);t=following-previous;length=np.linalg.norm(t,axis=1);dp=(before[ii]-c[:3])@R[2];dn=(after[ii]-c[:3])@R[2];finite=np.isfinite(previous).all(1)&np.isfinite(following).all(1)&(dp>.05)&(dn>.05);normalvalid=finite&np.isfinite(length)&(length>1e-12);normal=np.zeros((n,2));normal[normalvalid]=np.c_[-t[normalvalid,1],t[normalvalid,0]]/length[normalvalid,None];reason=np.where(normalvalid,0,np.where(finite,2,1)).astype('u1');invalid+=int((~normalvalid).sum())
   arrays=dict(target_uv=uv[ii],current_world=world[ii],station=stations[ii],material_index=mat[ii],path_index=np.zeros(n,np.int16),crosswalk_index=cross[ii],normal=normal,normal_valid=normalvalid,normal_reason=reason,target_domain_valid=np.ones(n,'u1'))
   for key,a in arrays.items():np.asarray(a,dtype=spec[key][0]).tofile(files[key])
   M+=n;offsets.append(M);counts.append(n);curve_counts.append(curves)
   if int(pts[fi])==1464832:
    brown,_=project_fast(c,xyz[ii]);d=np.linalg.norm(brown-uv[ii],axis=1);oldcompare=dict(native_pts=1464832,source_seconds=114.44,points=n,only_Brown_on_same_Demo_V3_camera_difference_px=dict(RMS=float(np.sqrt(np.mean(d*d))),median=float(np.median(d)),maximum=float(np.max(d))),demo_bridge_mode=int(bridge[fi]),demo_V3_patch_covered=bool(covered[source_index]),demo_V3_patch_changed=bool(changed[source_index]))
    with np.load(W/'nav_8a28_v1/navigation.npz',allow_pickle=False)as a:
     oldc=a['old_camera25_scene_units'][fi].copy()
     if not np.isfinite(oldc).all():
      r=int(a['rig_number'][fi]);jj=np.flatnonzero((a['rig_number']==r)&np.isfinite(a['old_camera25_scene_units'][:,0]))[0];oldc=a['old_camera25_scene_units'][jj].copy();oldc[:3]=a['navigation_C_normalized'][fi]*float(a['normalization_L'])+a['normalization_origin'];oldc[3:6]=cv2.Rodrigues(a['navigation_R_world_to_camera'][fi])[0].ravel();oldc[6:8]=a['navigation_log_f_native_pixels'][fi]
    olduv,_=project_fast(oldc,xyz[ii]);delta=np.linalg.norm(olduv-uv[ii],axis=1);oldcompare['previous_extractor_reference_vs_actual_Demo_V3_layout_px']=dict(RMS=float(np.sqrt(np.mean(delta*delta))),median=float(np.median(delta)),maximum=float(np.max(delta)))
   if fi%2000==0:print(json.dumps(dict(frame=fi,points=M,seconds=time.perf_counter()-begin)),flush=True)
 finally:
  for f in files.values():f.close()
 framearrays=dict(frame_native_pts=pts.astype('<i8'),frame_shot_number=shot,frame_navigation_kind=kind,frame_offsets=np.asarray(offsets,'<i8'),frame_point_count=np.asarray(counts,'<i4'),frame_curve_count=np.asarray(curve_counts,'<i2'),frame_demo_bridge_mode=bridge.astype('u1'),frame_demo_direct_mapping=p['direct_mapping'][keep].astype('u1'),frame_demo_patch_covered=covered[keep],frame_demo_patch_changed=changed[keep],frame_inherited_ledger_state_conflict=prior_conflict)
 for key,a in framearrays.items():
  with(out/(key+'.npy')).open('xb')as f:np.save(f,a,allow_pickle=False)
 fields={k:dict(dtype=dt,shape=[M,ch]if ch>1 else[M],storage='raw_binary_C_order',**ref(out/(k+'.bin')))for k,(dt,ch)in spec.items()};fields.update({k:dict(dtype=str(a.dtype),shape=list(a.shape),storage='npy_memmap',**ref(out/(k+'.npy')))for k,a in framearrays.items()});nonempty=np.asarray(counts)>0;byshot={}
 for sn in range(2,10):
  ss=shot==sn;byshot['s%02d'%sn]=dict(frames=int(ss.sum()),points=int(np.asarray(counts)[ss].sum()),frames_with_targets=int((nonempty&ss).sum()),demo_bridge_modes=dict(Counter(map(int,bridge[ss]))),original_ledger_conflict_frames=int(prior_conflict[ss].sum()))
 doc=dict(schema='rinkfit.old_ice_pixel_layout_normal_navigation.v1',purpose='actual already-converted official50 Demo V3 no-Brown rendered ice layout as numerical initialization only; no old R/C/K parameter targets',source_packet=ref(packet_path),source_packet_receipt=ref(receipt_path),V3_camera_patch=ref(patch_path),V3_camera_patch_receipt=ref(patch_receipt),actual_Demo_projection_code=[ref(ROOT/'calibration/program_tracking/demo_outro.py'),ref(ROOT/'calibration/program_tracking/demo_camera_patch.py')],old_scene=ref(oldpath),current_model=ref(currentpath),crosswalk=ref(crosswalk_path),extractor=ref(__file__),fields=fields,frames=len(pts),points=M,paired_paths=len(pairs),unpaired_old_paths=crossdoc['unpaired_old'],official_clock=dict(time_base='1/12800',fps='50/1',first_native_pts=256256,last_native_pts=2415104,step=256,all_programme_frames=8434,output_S02_S09_frames=7186),source_identity=packet_receipt['source'],projection_consumer='demo_v3_sample.V3Sample -> demo_camera_patch.apply_patch -> Sample.draw -> demo_outro.plane_homography -> warpPerspective; Brown intentionally ignored exactly as actual Demo',texture_bounds_xy=list(bounds),texture_wh=list(texture_wh),world_H_to_actual_texture_H_max_abs=contract_error,normal_definition='unit normal to dense same-curve no-Brown projected tangent; circles closed neighbors, finite lines one-sided endpoints',normal_invalid_count=invalid,normal_invalid_rows_retained=True,target_domain='old Demo finite forward z>0.05 world rays and screen [0,1919]x[0,1079]; no source qualification or occlusion measurement implied',by_shot=byshot,same_frame_1464832=oldcompare,array_bytes=sum(Path(v['file']).stat().st_size for v in fields.values()),elapsed_seconds=time.perf_counter()-begin,legacy_60_to_50_mapping_rebuilt=False,all_Demo_bridge_and_conflict_provenance_retained=True,V3_patch_rows_numeric_only=True,source_observation=False,source_qualification_or_statistics_created=False,raw_source_UV_W_Query_changed=False,old_scene_geometry_parameters_or_constraints_imported=False,current_S01_shared_scene_or_camera_family_changed=False,consumer_must_apply_existing_FrameRoleGuard=True,sample_policy='Same current same-entity world/path/station as prior crosswalk; actual Demo no-Brown visible contour layout every native frame; 64px spatial thinning for navigation only; formal source denominator unchanged')
 write(out/'manifest.json',doc);print(json.dumps(dict(output=str(out),frames=len(pts),points=M,array_bytes=doc['array_bytes'],seconds=doc['elapsed_seconds'],normal_invalid=invalid,projection_contract_error=contract_error,same_frame_1464832=oldcompare,by_shot=byshot)),flush=True)
if __name__=='__main__':main()
