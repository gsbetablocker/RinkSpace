import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json,time
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.joint_replay import render_snapshots
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
while not (rec/'shared_g8_exit.json').exists():time.sleep(1)
assert json.loads((rec/'shared_g8_exit.json').read_text())['code']==0
result=render_snapshots(rec/'shared_g8/candidate/model.json',Path('D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/programme_scope.json'),rec/'visual_shared_g8',
 compiled_dir=Path('D:/CodexData/RinkSpace_Data/runs/okada_s1_r11/gpu_accel/line_bundle/code/compiled_camera'),packet_file=rec/'g8_bound/packet.json',top_view=True)
print(json.dumps(dict(model=result['model'],frames=len(result['frames']),all_material_paths=result['all_material_paths_enabled'],video=False)),flush=True)
