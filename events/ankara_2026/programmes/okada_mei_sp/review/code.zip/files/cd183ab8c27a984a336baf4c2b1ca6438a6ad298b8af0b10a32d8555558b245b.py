from pathlib import Path
import zipfile,json,re,datetime
R=Path('D:/OneDrive/codex_projs/RinkSpace');D=Path('D:/CodexData/RinkSpace_Data');B=D/'pro/okada_audit_1019';out=D/'pro/Okada_Full9_Integrated_Audit_20261019.zip'
# Only final packaging. No SHA computation, tests, solver or validation subprocess.
unpack='''from pathlib import Path
import argparse,tarfile,shutil,importlib.util
p=argparse.ArgumentParser(description='Extract audit files only; never launches fitting.');p.add_argument('--output',required=True,type=Path);p.add_argument('--restore-history',action='store_true');a=p.parse_args();here=Path(__file__).resolve().parent;out=a.output.resolve()
if out.exists():raise SystemExit('Use a new output directory; no overwrite')
out.mkdir(parents=True)
with tarfile.open(here/'payload.tar.xz','r:xz') as t:
 for m in t.getmembers():
  target=(out/m.name).resolve()
  if not target.is_relative_to(out) or m.issym() or m.isdev():raise ValueError('Unsafe archive entry')
  if m.islnk() and not (out/m.linkname).resolve().is_relative_to(out):raise ValueError('Unsafe archive hardlink')
 t.extractall(out)
shutil.copytree(here/'packet_deltas',out/'packet_deltas')
for n in ['00_READ_ME_FIRST.md','PACKAGING_FINAL_REQUESTS.md']:
 if (here/n).exists():shutil.copy2(here/n,out/n)
if (here/'Current_Project_Status').exists():shutil.copytree(here/'Current_Project_Status',out/'Current_Project_Status')
if a.restore_history:
 spec=importlib.util.spec_from_file_location('audit_lossless_decoder',out/'packet_deltas/decode.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.restore(out/'packet_deltas/manifest.json',out,out)
print('Audit files extracted. No fitting process was launched.')
'''
(B/'unpack_audit.py').write_text(unpack,'utf-8')
finalreq='''# 最后打包指令与实际限制

用户先要求不超过200MB，随后明确询问当前大小并放宽体积，最后要求不要再继续校验。已停止额外校验与体积优化，直接交付现有完整材料。

主数据payload.tar.xz为352,843,220字节；补全历史实际运行输入与数组依赖的无损载荷65,318,188字节。最终ZIP约421MB，**原200MB目标未实现，超出幅度较大**；不隐瞒此限制，不把缺失关键输入改写成本机路径。

解压外层ZIP后，从00_READ_ME_FIRST.md开始。python unpack_audit.py --output NEW_DIRECTORY可解开全部主数据。加--restore-history可将包内无损表示还原为此前各真实运行消费的原始packet/数组；此操作只解码数据，不启动拟合。PRO也可直接读取tar、manifest及decoder审查。已有的完整SHA回执是此前产生的记录；用户要求后未额外运行校验。

包内Project/START_HERE.html及旧HTML是压缩开始时的历史快照，可能仍显示当时运行中的文字。Current_Project_Status/保存停机后的入口全文；当前状态以Audit/CURRENT_STATUS.json和本说明为准：最后求解已退出，所有辅助分工已停止，全九拟合未成功，无新接受全九视频，不自动恢复。

4.714GB屏幕网格派生数组用包内完整实际输入与原函数表示；完整原视频、完整诊断视频、环境和对象缓存省去。没有删除原始文件或历史失败。
'''
(B/'PACKAGING_FINAL_REQUESTS.md').write_text(finalreq,'utf-8')
readme=(B/'00_READ_ME_FIRST.md').read_text('utf-8');readme='最终大小与停机说明见PACKAGING_FINAL_REQUESTS.md；原200MB目标未实现，现直接交付现成完整材料。\n\n'+readme
(B/'00_READ_ME_FIRST.md').write_text(readme,'utf-8')
# Change existing status pages only; latest explicit user request ends further checking.
statusdir=B/'Current_Project_Status';statusdir.mkdir(exist_ok=True)
entry=R/'START_HERE.html';s=entry.read_text('utf-8-sig');begin='<!-- OKADA_RECOVERY_20261019_BEGIN -->';end='<!-- OKADA_RECOVERY_20261019_END -->'
card=begin+'\n<p class="callout"><strong>2026-10-19：用户要求离线审核，全部恢复工作已停止。</strong>最后完整候选、来源、源码及失败记录已保存；全九拟合尚未成功，暂无新接受完整网格视频。<a href="file:///D:/CodexData/RinkSpace_Data/pro/Okada_Full9_Integrated_Audit_20261019.zip">下载PRO整合审核包</a>。不自动恢复。</p>\n'+end
if begin in s and end in s:s=re.sub(re.escape(begin)+'.*?'+re.escape(end),lambda m:card,s,flags=re.S);entry.write_text(s,'utf-8')
(statusdir/'START_HERE.html').write_bytes(entry.read_bytes())
page=R/'events/ankara_2026/programmes/okada_mei_sp/fit_joint9/recovery_1019.html';s=page.read_text('utf-8-sig');b='<!-- DIRECT_GRID_ACTUAL_RUN_BEGIN -->';e='<!-- DIRECT_GRID_ACTUAL_RUN_END -->';card=b+'\n<p><strong>用户要求打包审核，当前所有拟合与辅助任务均已停止。</strong>最后model=42bae4e2，完整CP已保存；原始约束未闭合，全九未通过验收。<a href="file:///D:/CodexData/RinkSpace_Data/pro/Okada_Full9_Integrated_Audit_20261019.zip">PRO离线整合包</a>。不自动恢复。</p>\n'+e
if b in s and e in s:s=re.sub(re.escape(b)+'.*?'+re.escape(e),lambda m:card,s,flags=re.S)
else:s=s.replace('<body>','<body><p><strong>最新：用户要求审核，所有拟合已停止，全九未成功。</strong></p>',1)
page.write_text(s,'utf-8');(statusdir/'recovery_1019.html').write_bytes(page.read_bytes())
manifest=json.loads((B/'packet_deltas/manifest.json').read_text('utf-8'));names=sorted({r['payload_path'] for r in manifest['records'] if r.get('payload_path')})
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
 for n in ['00_READ_ME_FIRST.md','PACKAGING_FINAL_REQUESTS.md','unpack_audit.py','CURRENT_STATUS.json','FILE_INDEX.json','NUMERICAL_DEPENDENCIES.json','BUILD_RESULT.json']:
  z.write(B/n,n)
 for f in statusdir.iterdir():
  if f.is_file():z.write(f,'Current_Project_Status/'+f.name)
 for n in names+['manifest.json','decode.py','FULL_SHA_VERIFICATION.json','README.md','PACKAGE_MEMBERS.json']:
  f=B/'packet_deltas'/n
  if f.is_file():z.write(f,'packet_deltas/'+n)
 z.write(B/'payload.tar.xz','payload.tar.xz')
result={'file':str(out),'bytes':out.stat().st_size,'decimal_MB':round(out.stat().st_size/1e6,2),'all_fitting_previously_stopped':True,'all_subtasks_completed_or_stopped':True,'further_SHA_or_tests_executed':False,'zip_closed':True}
(B/'DELIVERED.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
