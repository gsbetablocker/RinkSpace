from pathlib import Path
import sys
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.joint_solver import execute_explicit
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
raise SystemExit(execute_explicit(str(rec/'build_v11/joint_fit.exe'),str(rec/'recovery_input_g8_model.json'),str(rec/'g8_bound/packet.json'),str(rec/'optics_g8_v2'),config=str(rec/'optics_g8_v2_config.json'),engineering_recovery=True))
