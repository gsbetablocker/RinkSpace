import ctypes as c, ctypes.wintypes as w, json,time,pathlib,subprocess,shutil
K=c.WinDLL('kernel32',use_last_error=True);P=c.WinDLL('psapi',use_last_error=True);S=c.c_size_t
class PE(c.Structure):
 _fields_=[('dwSize',w.DWORD),('cntUsage',w.DWORD),('pid',w.DWORD),('heap',S),('module',w.DWORD),('threads',w.DWORD),('ppid',w.DWORD),('priority',w.LONG),('flags',w.DWORD),('exe',w.WCHAR*260)]
class PMC(c.Structure):
 _fields_=[('cb',w.DWORD),('faults',w.DWORD)]+[(n,S) for n in ['peak_ws','ws','quota_peak_paged','quota_paged','quota_peak_nonpaged','quota_nonpaged','pagefile','peak_pagefile','private']]
class PI(c.Structure):
 _fields_=[('cb',w.DWORD)]+[(n,S)for n in ['commit','commit_limit','commit_peak','physical','available','cache','kernel','kernel_paged','kernel_nonpaged','pagesize']]+[(n,w.DWORD)for n in ['handles','processes','threads']]
class IOC(c.Structure):
 _fields_=[(n,c.c_ulonglong)for n in ['read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes']]
K.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD];K.CreateToolhelp32Snapshot.restype=w.HANDLE;K.Process32FirstW.argtypes=[w.HANDLE,c.POINTER(PE)];K.Process32NextW.argtypes=[w.HANDLE,c.POINTER(PE)];K.CloseHandle.argtypes=[w.HANDLE];K.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];K.OpenProcess.restype=w.HANDLE;P.GetProcessMemoryInfo.argtypes=[w.HANDLE,c.POINTER(PMC),w.DWORD];P.GetPerformanceInfo.argtypes=[c.POINTER(PI),w.DWORD];K.GetProcessIoCounters.argtypes=[w.HANDLE,c.POINTER(IOC)];K.GetProcessTimes.argtypes=[w.HANDLE,c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME)]
def ft(x):return ((int(x.dwHighDateTime)<<32)+int(x.dwLowDateTime))/1e7
def sample():
 pi=PI();pi.cb=c.sizeof(pi);assert P.GetPerformanceInfo(c.byref(pi),pi.cb);ps=pi.pagesize
 snap=K.CreateToolhelp32Snapshot(2,0);pe=PE();pe.dwSize=c.sizeof(pe);ok=K.Process32FirstW(snap,c.byref(pe));rows=[]
 while ok:
  h=K.OpenProcess(0x410,False,pe.pid)
  if h:
   pm=PMC();pm.cb=c.sizeof(pm);io=IOC();times=[w.FILETIME()for _ in range(4)]
   if P.GetProcessMemoryInfo(h,c.byref(pm),pm.cb):
    K.GetProcessIoCounters(h,c.byref(io));K.GetProcessTimes(h,*[c.byref(x)for x in times]);rows.append(dict(pid=pe.pid,ppid=pe.ppid,name=pe.exe,private_commit=pm.private,working_set=pm.ws,peak_working_set=pm.peak_ws,peak_commit=pm.peak_pagefile,page_fault_count=pm.faults,cpu_seconds=ft(times[2])+ft(times[3]),read_bytes=io.read_bytes,write_bytes=io.write_bytes,threads=pe.threads))
   K.CloseHandle(h)
  ok=K.Process32NextW(snap,c.byref(pe))
 K.CloseHandle(snap)
 return dict(utc=time.time(),system=dict(physical_total=pi.physical*ps,physical_available=pi.available*ps,commit=pi.commit*ps,commit_limit=pi.commit_limit*ps,commit_peak=pi.commit_peak*ps,cache=pi.cache*ps),processes=sorted(rows,key=lambda r:r['private_commit'],reverse=True))

import argparse
ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--exit-file',required=True);args=ap.parse_args()
Q=c.WinDLL('pdh',use_last_error=True);H=c.c_void_p
Q.PdhOpenQueryW.argtypes=[w.LPCWSTR,S,c.POINTER(H)];Q.PdhAddEnglishCounterW.argtypes=[H,w.LPCWSTR,S,c.POINTER(H)];Q.PdhCollectQueryData.argtypes=[H];Q.PdhGetFormattedCounterValue.argtypes=[H,w.DWORD,c.POINTER(w.DWORD),c.c_void_p];Q.PdhCloseQuery.argtypes=[H]
class CV(c.Structure):_fields_=[('status',w.DWORD),('value',c.c_double)]
query=H();counters={};pdh_status=Q.PdhOpenQueryW(None,0,c.byref(query))
if pdh_status==0:
 for name,field in [('\\Memory\\Page Reads/sec','page_reads_per_second'),('\\Memory\\Pages Input/sec','pages_input_per_second'),('\\Memory\\Pages Output/sec','pages_output_per_second'),('\\PhysicalDisk(_Total)\\Disk Read Bytes/sec','disk_read_bytes_per_second'),('\\PhysicalDisk(_Total)\\Disk Write Bytes/sec','disk_write_bytes_per_second'),('\\PhysicalDisk(_Total)\\Avg. Disk Queue Length','disk_queue_length'),('\\Processor(_Total)\\% Processor Time','CPU_percent')]:
  counter=H();status=Q.PdhAddEnglishCounterW(query,name,0,c.byref(counter))
  if status==0:counters[field]=counter
 Q.PdhCollectQueryData(query)
output=pathlib.Path(args.output);output.parent.mkdir(parents=True,exist_ok=True)
try:
 while True:
  r=sample();r['monitor_scope']='unsandboxed_system_readonly';r['major_processes']=r.pop('processes')[:15]
  if pdh_status==0:
   Q.PdhCollectQueryData(query);r['paging_disk_CPU']={}
   for name,handle in counters.items():
    v=CV();kind=w.DWORD();code=Q.PdhGetFormattedCounterValue(handle,0x200,c.byref(kind),c.byref(v));r['paging_disk_CPU'][name]=dict(value=v.value if code==0 and v.status in (0,1)else None,api_status=code,counter_status=v.status)
  try:
   command=['nvidia-smi','--query-gpu=timestamp,memory.total,memory.used,memory.free,utilization.gpu,utilization.memory','--format=csv,noheader,nounits'];g=subprocess.run(command,capture_output=True,text=True,timeout=5);r['GPU_global_csv']=g.stdout.strip();r['GPU_query_returncode']=g.returncode
  except Exception as error:r['GPU_query_error']=str(error)
  with output.open('a',encoding='utf8')as f:f.write(json.dumps(r)+'\n')
  if pathlib.Path(args.exit_file).exists():break
  time.sleep(2)
finally:
 if pdh_status==0:Q.PdhCloseQuery(query)
