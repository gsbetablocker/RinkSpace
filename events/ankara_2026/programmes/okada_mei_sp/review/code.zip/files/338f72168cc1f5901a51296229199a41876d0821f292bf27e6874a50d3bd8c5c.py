import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,subprocess,copy,hashlib,struct
import numpy as np
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.io_utils import file_sha256,write_json
from rinkfit_joint.joint_solver import rebind_explicit_nuisance,execute_explicit
from rinkfit_joint.baseline_recovery import apply_source_supported_motion_flags
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
exe=rec/'build_v13/joint_fit.exe';packet=rec/'g9_ice/packet.json';recipe=json.loads((exe.parent/'recipe.json').read_text())
assert file_sha256(packet)=='856fd7a939ce674e10494fbc32cf20023333f02150cae6af2a5937598b842a49'
while not (rec/'repair_g8_exit.json').exists():time.sleep(1)
assert json.loads((rec/'repair_g8_exit.json').read_text())['code']==0
while not (rec/'build_v13_exit.json').exists():time.sleep(1)
assert json.loads((rec/'build_v13_exit.json').read_text())['code']==0
env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','')
start=time.monotonic()
with (rec/'g9_ice/native_qualification.log').open('w',encoding='utf8')as f:
 r=subprocess.run([str(exe),'--qualification-check',str(rec/'recovery_input_model.json'),str(packet),str(rec/'g9_ice/native_qualification.json')],env=env,stdout=f,stderr=subprocess.STDOUT)
if r.returncode:raise ValueError('Native source consumer rejected G7')
write_json(rec/'g9_ice/native_qualification_execution.json',dict(returncode=r.returncode,elapsed_seconds=time.monotonic()-start,backend_sha256=file_sha256(exe),source_packet_sha256=file_sha256(packet),fit_started=False))
bound=rec/'g9_bound/packet.json';accepted=rec/'repair_g8/candidate'
result=rebind_explicit_nuisance(packet,accepted,bound)
write_json(bound.parent/'binding_execution.json',dict(result=result,complete_candidate_preserved=True,candidate_visual_acceptance_claimed=False))
old=json.loads((accepted/'model.json').read_text());base=json.loads(Path('D:/CodexData/RinkSpace_Data/runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/navigation_model.json').read_text())
q=copy.deepcopy(old)
for a,b in zip(q['blocks'],base['blocks']):
 assert a['name']==b['name'] and len(a['values'])==len(b['values'])
 if a['name'].startswith('shot/'):
  for flag in ('constant','fixed_indices'):
   if flag in b:a[flag]=copy.deepcopy(b[flag])
   else:a.pop(flag,None)
q['linear_control_manifolds']=copy.deepcopy(base['linear_control_manifolds']);q.pop('source_supported_motion_flags',None)
q=apply_source_supported_motion_flags(bound,q)
def valuehash(d):
 h=hashlib.sha256()
 for i,b in enumerate(d['blocks']):
  h.update(struct.pack('<Q',i));h.update(b['name'].encode());h.update(b'\0');h.update(np.asarray(b['values'],dtype='<f8').tobytes())
 return h.hexdigest()
assert valuehash(q)==valuehash(old)
def projection(d):
 a=copy.deepcopy(d)
 for k in ('source_supported_motion_flags','linear_control_manifolds'):a.pop(k,None)
 for b in a['blocks']:
  for k in ('constant','fixed_indices'):b.pop(k,None)
 return a
assert projection(q)==projection(old)
model=rec/'recovery_input_g9_model.json';write_json(model,q)
write_json(rec/'recovery_input_g9_model_receipt.json',dict(model=dict(file=str(model),sha256=file_sha256(model)),accepted_model=dict(file=str(accepted/'model.json'),sha256=file_sha256(accepted/'model.json')),source_packet=dict(file=str(bound),sha256=file_sha256(bound)),all_1921_physical_blocks_exact=True,physical_values_sha256=valuehash(q),projection_definition_unchanged=True,only_source_supported_motion_flags_and_manifolds_updated=True,source_support=q['source_supported_motion_flags']))
cfg=json.loads((rec/'repair_g8_config.json').read_text());cfg.pop('resume_engineering_checkpoint',None);cfg.pop('resume_engineering_outer_state',None);cfg.pop('motion_navigation_restart',None)
assert json.loads((accepted.parent/'engineering_receipt.json').read_text())['completed_engineering_outer_updates']==0,'Nonzero duals require source-schema migration, not reset'
cfg['reinitialize_native_auxiliaries']=True;cfg['initialization_only']=False;cfg['refine_ordinary_station_seeds']=True;cfg['refine_query_navigation_seeds']=True;cfg['parameter_stage']='optics'
nav=json.loads((rec/'motion_navigation_g8_spec.json').read_text());nav['source_packet_sha256']=file_sha256(bound)
controls=[dict(block='shot/s07/control/8',weight=.5),dict(block='shot/s07/control/10',weight=.5)]
nav['proposals']=[dict(block='shot/s07/control/9',axis=axis,navigation_controls=controls)for axis in (0,1,2)]
nav['source_evidence'].append(dict(file=str(rec/'hist_s07_v1/s07_11444_local_source.json'),sha256=file_sha256(rec/'hist_s07_v1/s07_11444_local_source.json')))
cfg['coupled_motion_navigation_restart']=nav
# A B1 proposal is installed only after its source-bound strict helper contract is available.
line_spec=rec/'B1_finite_line_navigation_spec.json'
if line_spec.exists():
 s=json.loads(line_spec.read_text());s['source_packet_sha256']=file_sha256(bound);cfg['finite_line_navigation_restart']=s
write_json(rec/'shared_g9_config.json',cfg)
print(json.dumps(dict(ready=True,model=str(model),packet=str(bound),source_rows_added=1929,start_actual_full9_solver=True)),flush=True)
raise SystemExit(execute_explicit(str(exe),str(model),str(bound),str(rec/'shared_g9'),config=str(rec/'shared_g9_config.json'),engineering_recovery=True))
