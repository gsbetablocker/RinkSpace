from pathlib import Path
import json,hashlib,sys,tarfile,lzma,zipfile,time,subprocess,datetime
R=Path('D:/OneDrive/codex_projs/RinkSpace');D=Path('D:/CodexData/RinkSpace_Data');W=D/'runs/okada_rec_1019';P=D/'pro';B=P/'okada_audit_1019'
p=json.loads((P/'okada_bundle_plan_v2.json').read_text('utf-8'));files=p['files'];members=p['zip_members'];known={str(Path(x['source_path']).resolve()).lower() for x in files}
def add(f,a=None,role='audit-export'):
 f=Path(f)
 if not f.is_file() or f.stat().st_size==0:return
 k=str(f.resolve()).lower()
 if k in known:return
 known.add(k)
 if a is None:
  try:a='Project/'+f.relative_to(R).as_posix()
  except ValueError:a='Data/'+f.relative_to(D).as_posix()
 files.append({'source_path':str(f),'archive_path':a,'bytes':f.stat().st_size,'role':role})
e=next(x for x in files if Path(x['source_path']).name=='Okada_DirectGrid_Offline_Inventory_20261019.json');files.append({**e,'archive_path':'offline/direct_grid_inventory.json'})
ev=json.loads((P/'okada_selected_pixel_feedback_evidence.json').read_text('utf-8'))
for x in ev['files']:add(x['source_path'],x['archive_path'],'native-pixel-and-real-feedback-evidence')
add(P/'okada_selected_pixel_feedback_evidence.json','offline/selected_pixel_feedback_inventory.json')
for sub in ['scope_archives','baseline_aux_native_build_v1','screen_grid_received_v1']:
 for f in (W/sub).rglob('*'):
  if f.is_file() and f.suffix in ['.json','.py','.cpp','.hpp','.log']:add(f,role='qualification-or-receiver-evidence')
for sub in ['baseline_import_gpu32_v1','baseline_import_v1']:
 for f in (D/'runs/okada_full9_recovery_1019'/sub).rglob('*'):
  if f.is_file() and f.suffix in ['.json','.log'] and f.stat().st_size<6_000_000:add(f,role='first-imported-baseline')
for f in (W/'audit_export').glob('*'):add(f,'Audit/'+f.name)
for n in ['run_full_source_v98.py','same_point_budget_units_v96.log','same_point_budget_units_v96_driver.log','same_point_budget_units_v96_owner_memory.jsonl','joint_gpu_full_shadow_v1.json','joint_gpu_raw_compile_v2/kernel.ptx']:add(D/'runs/okada_joint9_1018a'/n,role='original-run-and-GPU-identity')
for n in ['uv.lock','requirements.txt','requirements-dev.txt']:add(R/n,role='dependency-version')
zpath=P/'Okada_Full9_PRO_Audit_20261019.zip'
with zipfile.ZipFile(zpath) as z:
 for q in z.infolist():
  if q.filename.startswith('project/calibration/rinkfit/') and not q.is_dir():members.append({'zip':str(zpath),'member':q.filename,'archive_path':'Initial_v98/'+q.filename,'bytes':q.file_size,'role':'original-code-snapshot'})
head=subprocess.run(['git','-C',str(R),'rev-parse','HEAD'],capture_output=True,text=True).stdout.strip()
status=subprocess.run(['git','-C',str(R),'status','--short'],capture_output=True,text=True,encoding='utf-8',errors='replace').stdout
(B/'GIT_STATUS.txt').write_text(status,'utf-8');add(B/'GIT_STATUS.txt','Audit/GIT_STATUS.txt')
diff=subprocess.run(['git','-C',str(R),'diff','--binary','--','calibration/rinkfit','src/rink_feedback','src/rinkspace','events/ankara_2026/programmes/okada_mei_sp/fit_joint9','START_HERE.html'],capture_output=True).stdout
(B/'TRACKED_DIFF.patch').write_bytes(diff);add(B/'TRACKED_DIFF.patch','Audit/TRACKED_DIFF.patch')
receipt=json.loads((W/'demo_grid_recovery_v1/engineering_receipt.json').read_text('utf-8'));stages=json.loads((P/'okada_recovery_audit_inventory.json').read_text('utf-8'))['stage_execution_identity']
current={'status':'STOPPED_AT_USER_REQUEST_FOR_PRO_AUDIT','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_HEAD':head,'actual_untracked_sources_bundled':True,'full9_success':False,'new_accepted_full9_video':False,'source_clock':{'youtube_id':'O6j8L8TmfKo','fps':'50/1','time_base':'1/12800','first_pts':256256,'last_pts':2415104,'step_pts':256,'frames':8434,'rigs':3,'shots':9},'latest_full_state':{'model_sha256':receipt['model_sha256'],'checkpoint_sha256':'6806b7a8190719c3d893bd6ebbc695a146f1e6ff4bf4a22c34fbed60749be24e','source_packet_sha256':receipt['source_packet_sha256'],'configuration_sha256':receipt['configuration_sha256'],'iterations':receipt['iterations'],'stopped':receipt['stopped'],'initial_original_contributions':receipt['initial_contributions'],'final_original_contributions':receipt['final_contributions'],'constraint_debt':receipt['final_original_constraint_debt'],'original_W_likelihood_consumed':receipt['original_W_likelihood_consumed'],'formal_acceptance':False,'last_solver_summary_included_numerical_grid_navigation':True,'timing_seconds':receipt['timing_seconds']},'known_failures':['Screen Demo grid is not an initialized physical camera.','Final run still began from physical 9664534b, not matching Demo screen grid.','Iteration cost includes virtual navigation.','Raw constraints and independent RS/Query replay not closed.','S01 exact import does not prove preservation after shared optics solve.','No accepted independent continuous full9 visual result or improved complete video.'],'historical_executions':stages}
(B/'CURRENT_STATUS.json').write_text(json.dumps(current,ensure_ascii=False,indent=2),'utf-8');add(B/'CURRENT_STATUS.json','Audit/CURRENT_STATUS.json');add(B/'00_READ_ME_FIRST.md','00_READ_ME_FIRST.md')
resolver='''from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('.'));p.add_argument('--source');p.add_argument('--sha');a=p.parse_args();r=a.root.resolve();d=json.loads((r/'FILE_INDEX.json').read_text('utf-8'));q=[]
for e in d['files']:
 if (a.sha and e['sha256']==a.sha) or (a.source and e.get('original_path','').replace(chr(92),'/').lower()==a.source.replace(chr(92),'/').lower()):q.append(e)
if not q:raise SystemExit('NOT_IN_BUNDLE; no fallback to original machine path')
for e in q:
 f=(r/e['archive_path']).resolve();assert f.is_relative_to(r) and f.is_file();h=hashlib.sha256()
 with f.open('rb') as s:
  for b in iter(lambda:s.read(1048576),b''):h.update(b)
 assert h.hexdigest()==e['sha256'];print(f)
'''
(B/'resolve.py').write_text(resolver,'utf-8');add(B/'resolve.py','offline/resolve.py')
paths={}
for e in files+members:
 a=e['archive_path'];assert not a.startswith(('/',chr(92))) and '..' not in Path(a).parts
 if a not in paths:paths[a]=e
allfiles=list(paths.values());zcache={};manifest=[]
def stream(e):
 if 'source_path' in e:return open(e['source_path'],'rb')
 if e['zip'] not in zcache:zcache[e['zip']]=zipfile.ZipFile(e['zip'])
 return zcache[e['zip']].open(e['member'])
start=time.time()
for k,e in enumerate(allfiles):
 h=hashlib.sha256()
 with stream(e) as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 e['sha256']=h.hexdigest();orig=e.get('source_path')
 if orig is None:
  m=e['member']
  if m.startswith('run/'):orig=str(D/'runs/okada_joint9_1018a'/m[4:])
  elif m.startswith('evidence/run/'):orig=str(D/'runs/okada_joint9_1018a'/m[len('evidence/run/'):])
  elif m.startswith('project/'):orig=str(R/m[len('project/'):])
  else:orig='original-user-zip:'+m
 manifest.append({'archive_path':e['archive_path'],'original_path':orig,'bytes':e['bytes'],'sha256':e['sha256'],'role':e['role']})
 if k%1000==0:print('IDENTITY',k,len(allfiles),round(time.time()-start,1),flush=True)
source=json.loads((W/'g9_ice/packet.json').read_bytes());bysha={x['sha256']:x for x in manifest};refaudit=[]
def refs(x):
 if isinstance(x,dict):
  if x.get('file') and x.get('dtype'):
   sh=x.get('sha256');found=bysha.get(sh);refaudit.append({'original_file':x['file'],'sha256':sh,'dtype':x['dtype'],'shape':x.get('shape'),'offset_bytes':x.get('offset_bytes',0),'actual_archive_path':found['archive_path'] if found else None})
  for v in x.values():refs(v)
 elif isinstance(x,list):
  for v in x:refs(v)
refs({'arrays':source['arrays'],'groups':source['groups']});missing=[x for x in refaudit if x['actual_archive_path'] is None]
(B/'NUMERICAL_DEPENDENCIES.json').write_text(json.dumps({'current_packet_sha256':receipt['source_packet_sha256'],'all_actual_typed_array_and_W_references_present':not missing,'reference_count':len(refaudit),'missing':missing,'references':refaudit},ensure_ascii=False,indent=2),'utf-8')
if missing:raise RuntimeError('Missing real numerical dependencies: '+str(missing[:3]))
(B/'FILE_INDEX.json').write_text(json.dumps({'schema':'rinkspace.integrated_offline_file_index.v1','original_paths_are_provenance_only':True,'files':manifest},ensure_ascii=False,indent=2),'utf-8')
allfiles.sort(key=lambda e:(Path(e['archive_path']).name.lower(),e['bytes'],e['archive_path']))
raw=B/'payload.tar.xz';seen={};total=0;unique=0
with lzma.open(raw,'wb',format=lzma.FORMAT_XZ,check=lzma.CHECK_CRC64,filters=[{'id':lzma.FILTER_LZMA2,'preset':3,'dict_size':64*1024*1024}]) as xz:
 with tarfile.open(fileobj=xz,mode='w|',format=tarfile.PAX_FORMAT) as t:
  for k,e in enumerate(allfiles):
   ti=tarfile.TarInfo(e['archive_path']);ti.mtime=0;ti.mode=0o644;ti.uid=0;ti.gid=0
   if e['sha256'] in seen:ti.type=tarfile.LNKTYPE;ti.linkname=seen[e['sha256']];ti.size=0;t.addfile(ti)
   else:
    ti.size=e['bytes']
    with stream(e) as f:t.addfile(ti,f)
    seen[e['sha256']]=e['archive_path'];total+=e['bytes'];unique+=1
   if k%150==0:print('COMPRESS',k,len(allfiles),'unique_raw',total,'xz_bytes',raw.stat().st_size,'seconds',round(time.time()-start,1),flush=True)
  for n in ['FILE_INDEX.json','NUMERICAL_DEPENDENCIES.json']:
   f=B/n;ti=tarfile.TarInfo(n);ti.size=f.stat().st_size;ti.mtime=0;ti.mode=0o644
   with f.open('rb') as q:t.addfile(ti,q)
for z in zcache.values():z.close()
result={'payload_bytes':raw.stat().st_size,'logical_files':len(allfiles),'unique_files':unique,'unique_raw_bytes':total,'seconds':time.time()-start,'all_typed_current_dependencies_present':True}
(B/'BUILD_RESULT.json').write_text(json.dumps(result,indent=2),'utf-8');print('PAYLOAD_DONE',json.dumps(result),flush=True)
