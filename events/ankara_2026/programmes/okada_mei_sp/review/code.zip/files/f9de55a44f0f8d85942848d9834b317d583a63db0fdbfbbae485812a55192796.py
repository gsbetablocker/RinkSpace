import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from pathlib import Path
import sys,json,time,subprocess,copy,hashlib,struct
import numpy as np
root=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src')]
from rinkfit_joint.io_utils import file_sha256,write_json
from rinkfit_joint.joint_solver import rebind_explicit_nuisance,execute_explicit
from rinkfit_joint.baseline_recovery import apply_source_supported_motion_flags
rec=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
exe=rec/'build_v11/joint_fit.exe';packet=rec/'g8_ice/packet.json';recipe=json.loads((exe.parent/'recipe.json').read_text())
assert file_sha256(packet)=='49ac2f8d24dd51a5dd7425b015cf774e810d5d073f34cffb6ca408cf93abb90d'
while not (rec/'shared_g7_exit.json').exists():time.sleep(1)
assert json.loads((rec/'shared_g7_exit.json').read_text())['code']==0
while not (rec/'build_v11_exit.json').exists():time.sleep(1)
assert json.loads((rec/'build_v11_exit.json').read_text())['code']==0
env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','')
start=time.monotonic()
with (rec/'g8_ice/native_qualification.log').open('w',encoding='utf8')as f:
 r=subprocess.run([str(exe),'--qualification-check',str(rec/'recovery_input_model.json'),str(packet),str(rec/'g8_ice/native_qualification.json')],env=env,stdout=f,stderr=subprocess.STDOUT)
if r.returncode:raise ValueError('Native source consumer rejected G7')
write_json(rec/'g8_ice/native_qualification_execution.json',dict(returncode=r.returncode,elapsed_seconds=time.monotonic()-start,backend_sha256=file_sha256(exe),source_packet_sha256=file_sha256(packet),fit_started=False))
bound=rec/'g8_bound/packet.json';accepted=rec/'shared_g7/candidate'
result=rebind_explicit_nuisance(packet,accepted,bound)
write_json(bound.parent/'binding_execution.json',dict(result=result,complete_candidate_preserved=True,candidate_visual_acceptance_claimed=False))
old=json.loads((accepted/'model.json').read_text());base=json.loads(Path('D:/CodexData/RinkSpace_Data/runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/navigation_model.json').read_text())
q=copy.deepcopy(old)
for a,b in zip(q['blocks'],base['blocks']):
 assert a['name']==b['name'] and len(a['values'])==len(b['values'])
 if a['name'].startswith('shot/'):
  for flag in ('constant','fixed_indices'):
   if flag in b:a[flag]=copy.deepcopy(b[flag])
   else:a.pop(flag,None)
q['linear_control_manifolds']=copy.deepcopy(base['linear_control_manifolds']);q.pop('source_supported_motion_flags',None)
q=apply_source_supported_motion_flags(bound,q)
def valuehash(d):
 h=hashlib.sha256()
 for i,b in enumerate(d['blocks']):
  h.update(struct.pack('<Q',i));h.update(b['name'].encode());h.update(b'\0');h.update(np.asarray(b['values'],dtype='<f8').tobytes())
 return h.hexdigest()
assert valuehash(q)==valuehash(old)
def projection(d):
 a=copy.deepcopy(d)
 for k in ('source_supported_motion_flags','linear_control_manifolds'):a.pop(k,None)
 for b in a['blocks']:
  for k in ('constant','fixed_indices'):b.pop(k,None)
 return a
assert projection(q)==projection(old)
model=rec/'recovery_input_g8_model.json';write_json(model,q)
write_json(rec/'recovery_input_g8_model_receipt.json',dict(model=dict(file=str(model),sha256=file_sha256(model)),accepted_model=dict(file=str(accepted/'model.json'),sha256=file_sha256(accepted/'model.json')),source_packet=dict(file=str(bound),sha256=file_sha256(bound)),all_1921_physical_blocks_exact=True,physical_values_sha256=valuehash(q),projection_definition_unchanged=True,only_source_supported_motion_flags_and_manifolds_updated=True,source_support=q['source_supported_motion_flags']))
cfg=json.loads((rec/'shared_g4_config.json').read_text());cfg.pop('resume_engineering_checkpoint',None);cfg.pop('resume_engineering_outer_state',None);cfg['reinitialize_native_auxiliaries']=True;cfg['initialization_only']=False;cfg['refine_ordinary_station_seeds']=True
write_json(rec/'shared_g8_config.json',cfg)
print(json.dumps(dict(ready=True,model=str(model),packet=str(bound),source_rows_added=433,start_actual_full9_solver=True)),flush=True)
raise SystemExit(execute_explicit(str(exe),str(model),str(bound),str(rec/'shared_g8'),config=str(rec/'shared_g8_config.json'),engineering_recovery=True))
