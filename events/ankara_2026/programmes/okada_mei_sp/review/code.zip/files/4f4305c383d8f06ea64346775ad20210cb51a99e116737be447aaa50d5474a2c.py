import json
from pathlib import Path
rec=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');state=rec/'motion_g3/candidate';model=json.loads((state/'model.json').read_text())
with (state/'engineering_checkpoint.json').open() as f:
 for _ in range(8):f.readline()
 n=int(f.readline());print('params',n,'blocks',len(model['blocks']))
 for i,b in enumerate(model['blocks']):
  line=f.readline().strip();name,end=json.JSONDecoder().raw_decode(line);flag=line[end:].strip();v=list(map(float,f.readline().split()[1:]))
  if name!=b['name'] or flag!='0' or v!=b['values']:
   print(json.dumps(dict(index=i,name=name,model_name=b['name'],flag=flag,value_count=len(v),model_count=len(b['values']),differences=[dict(index=j,checkpoint=x,model=y,delta=x-y,checkpoint_hex=x.hex(),model_hex=float(y).hex())for j,(x,y)in enumerate(zip(v,b['values']))if x!=y][:8])));break
