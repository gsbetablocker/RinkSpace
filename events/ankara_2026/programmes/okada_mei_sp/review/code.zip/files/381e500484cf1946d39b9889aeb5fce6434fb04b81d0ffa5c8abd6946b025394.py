"""Offline deterministic regeneration of the complete stored Demo screen-grid arrays.
No fitting, source remapping, point selection or S01 replacement. Requires Python 3.11,
NumPy 2.4.6 and SciPy 1.17.1 for the original bytewise numerical environment.
Default verifies packed inputs only. Use --output NEW_DIRECTORY to materialize 4.714 GB.
"""
from pathlib import Path
import argparse,ast,hashlib,json,sys,shutil
import numpy as np
from scipy.spatial.transform import Rotation

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def main():
    a=argparse.ArgumentParser(); a.add_argument('--package-root',type=Path,required=True)
    a.add_argument('--inventory',type=Path); a.add_argument('--output',type=Path)
    args=a.parse_args(); base=args.package_root.resolve()
    ip=args.inventory or base/'offline/direct_grid_inventory.json'
    inventory=json.loads(ip.read_text(encoding='utf8'))
    byid={x['id']:x for x in inventory['files']}
    def file(ident):
        e=byid[ident]; p=(base/e['archive_path']).resolve()
        if not p.is_relative_to(base): raise ValueError('Unsafe packed relative path')
        if p.stat().st_size!=e['bytes'] or sha(p)!=e['sha256']:
            raise ValueError('Packed input identity differs: '+ident)
        return p
    needed=['demo_source_packet','demo_v3_patch','old_scene','original_projection',
            'original_renderer','original_demo_patch','direct_initial_state','direct_topology']
    checked={k:file(k) for k in needed}
    original=json.loads(checked['direct_initial_state'].read_text(encoding='utf8'))
    if args.output is None:
        print(json.dumps({'verified_input_ids':needed,'output_written':False,
                          'complete_original_vertex_rows':original['total_screen_vertices']})); return
    out=args.output.resolve()
    if out.exists(): raise FileExistsError('New output directory required; never overwrite state')
    ns={'np':np,'Rotation':Rotation,'Path':Path,'DEFAULT_OUTPUT':Path('.')}
    def functions(ident,names):
        p=checked[ident]; tree=ast.parse(p.read_text(encoding='utf8-sig'))
        nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
        if {n.name for n in nodes}!=set(names): raise ValueError('Original function inventory changed')
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)
    functions('original_projection',['scene_paths'])
    functions('original_renderer',['fixed_scene_paths'])
    functions('original_demo_patch',['world_plane_homography','project_xy','apply_patch'])
    scene=json.loads(checked['old_scene'].read_text(encoding='utf8'))
    topology=json.loads(checked['direct_topology'].read_text(encoding='utf8'))
    paths=ns['fixed_scene_paths'](scene,draw_grid=True)
    ice=[(i,k,x) for i,(k,x) in enumerate(paths) if k in ('grid','marking')]
    if len(ice)!=2130: raise ValueError('Complete original ice path count changed')
    for (i,k,x),record in zip(ice,topology['paths']):
        if i!=record['original_renderer_path_index'] or k!=record['kind']:
            raise ValueError('Original path identity/order changed')
        if hashlib.sha256(np.ascontiguousarray(x,dtype='<f8').tobytes()).hexdigest()!=record['original_world_vertex_bytes_sha256']:
            raise ValueError('Original complete path coordinates changed')
    xyz=np.concatenate([x for i,k,x in ice])
    with np.load(checked['demo_source_packet'],allow_pickle=False) as z:
        packet={k:z[k].copy() for k in z.files}
    ns['apply_patch'](packet,checked['demo_v3_patch'])
    expected=np.arange(256256,2415104+256,256,dtype=np.int64)
    if not (np.array_equal(packet['pts'],expected) and np.array_equal(packet['native_pts'],expected)
            and str(packet['time_base'])=='1/12800' and str(packet['native_fps'])=='50/1'):
        raise ValueError('Original official 50fps clock changed')
    selected=np.flatnonzero(packet['shot_index']!=1)
    if len(selected)!=7186 or len(xyz)!=26238 or np.any(packet['shot_index'][selected]==1):
        raise ValueError('S01 must remain absent from Demo screen-grid rows')
    specs={'screen_uv':('<f8','screen_uv.f64'),'depth':('<f8','depth.f64'),
           'vertex_mask_bits':('u1','vertex_mask_bits.u8')}
    out.mkdir(parents=True); hashes={k:hashlib.sha256() for k in specs}
    handles={k:(out/v[1]).open('xb') for k,v in specs.items()}
    try:
        for fi,pi in enumerate(selected):
            c=packet['camera25'][pi]; h=ns['world_plane_homography'](c)
            with np.errstate(divide='ignore',invalid='ignore',over='ignore'):
                uv=ns['project_xy'](h,xyz[:,:2])
            r=Rotation.from_rotvec(c[3:6]).as_matrix(); depth=(xyz-c[:3])@r[2]
            finite=np.isfinite(uv).all(1)&np.isfinite(depth); front=finite&(depth>.05)
            inside=finite&(uv[:,0]>=0)&(uv[:,0]<=1919)&(uv[:,1]>=0)&(uv[:,1]<=1079)
            flags=finite.astype('u1')|(front.astype('u1')<<1)|(inside.astype('u1')<<2)
            for key,value in [('screen_uv',uv),('depth',depth),('vertex_mask_bits',flags)]:
                view=memoryview(np.ascontiguousarray(value,dtype=specs[key][0])).cast('B')
                handles[key].write(view); hashes[key].update(view)
    finally:
        for f in handles.values(): f.close()
    results={}
    for key,(_,name) in specs.items():
        want=original['fields'][key]; actual=hashes[key].hexdigest()
        results[key]={'file':name,'bytes':(out/name).stat().st_size,'sha256':actual,
                      'expected_sha256':want['sha256'],'bytewise_identical':actual==want['sha256']}
        if actual!=want['sha256']: raise ValueError('Bytewise reconstruction mismatch: '+key+'; retain original expected SHA, do not accept approximate data')
    receipt={'schema':'rinkfit.offline_direct_grid_reconstruction_receipt.v1',
             'complete_original_vertex_rows':188546268,'frames':7186,'vertices_per_frame':26238,
             'S01_rows_written':0,'new_fitting_or_source_mapping_performed':False,'results':results,
             'original_manifest_sha256':sha(checked['direct_initial_state'])}
    (out/'RECONSTRUCTION_COMPLETE.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
    print(json.dumps(receipt))
if __name__=='__main__': main()
