import sys,pathlib
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'calibration/rinkfit/src'),str(root/'src')]
from rinkfit_joint.joint_solver import execute_explicit
raise SystemExit(execute_explicit(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/build_v9/joint_fit.exe',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/recovery_input_g6_model.json',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/g6_bound/packet.json',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/shared_g4',config=r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/shared_g4_config.json',engineering_recovery=True))
