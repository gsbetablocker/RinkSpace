from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');recipe=json.loads((r/'compare_build_g5_v1/recipe.json').read_text());config=r/'v98_compare_g6_v1_config.json';cfg=json.loads(config.read_text());output=Path(cfg['output'])
if output.exists():raise RuntimeError('immutable comparison output already exists')
env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','');env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
command=[str(r/'compare_build_g5_v1/joint_recovery_compare.exe'),r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/fit_full_source_v98/generation_1/model.json',str(r/'g6_bound/packet.json'),r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/all6006_fixed425_C0material24_closed3875_conditional_bound_v1/packet.json',r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/fit_full_source_v98/generation_1/explicit_nuisance/manifest.json',str(config)]
started=time.perf_counter()
with (r/'v98_compare_g6_v2.log').open('x',encoding='utf8') as log:result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt=dict(returncode=result.returncode,command=command,elapsed_seconds=time.perf_counter()-started,fit_started=False,dependency_note='standard-library runner; no optional process-monitor package')
(r/'v98_compare_g6_v2_exit.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));raise SystemExit(result.returncode)
