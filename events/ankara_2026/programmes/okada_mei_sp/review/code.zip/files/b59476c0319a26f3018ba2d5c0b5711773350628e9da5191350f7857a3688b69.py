import os,sys,json,hashlib
from pathlib import Path
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
ROOT=Path('D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(ROOT))
import numpy as np,cv2
from calibration.program_tracking.demo_camera_patch import apply_patch
from calibration.program_tracking.render_demo_last_shot import decode
from calibration.program_tracking.render_result import SceneRenderer
D=Path('D:/CodexData/RinkSpace_Data/events/ankara_2026/programmes/okada_mei_sp/results');W=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');out=W/'Demo50_actual_reference'
out.mkdir(exist_ok=True)
with np.load(D/'demo_last_shot_20261016/source_packet.npz',allow_pickle=False)as z:packet={k:z[k].copy()for k in z.files}
apply_patch(packet,D/'demo_full_20261016/v3/camera_patch.npz')
scene=json.loads(Path(str(packet['scene_path'])).read_text('utf-8-sig'));renderer=SceneRenderer(scene,draw_grid=True,draw_advertisements=True)
p=1464832;i=int(np.flatnonzero(packet['pts']==p)[0]);native=next(decode(str(packet['source_path']),p,p))[1]
camera=packet['camera25'][i].copy();camera[11:]=0.
im,metrics=renderer.draw(native,camera,title=f'REFERENCE DEMO50 | source={p/12800:.3f}s PTS={p} | existing layout, not current recovered model')
cv2.imwrite(str(out/f'{p}.png'),im)
(out/'receipt.json').write_text(json.dumps(dict(native_pts=p,source_seconds=p/12800,output=str(out/f'{p}.png'),existing_Demo_renderer=True,current_production_model_changed=False,old_camera_used_only_to_render_reference=True,source_accuracy_acceptance=False,metrics=metrics),ensure_ascii=False,indent=2),encoding='utf8')
print(str(out/f'{p}.png'),flush=True)
