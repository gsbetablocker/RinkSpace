import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json,time,traceback
root=Path(r'D:/OneDrive/codex_projs/RinkSpace')
sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.qualified_scope import compile_active_qualified_scope
run=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a')
out=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019')
started=time.monotonic()
r=compile_active_qualified_scope(run/'all6006_fixed425_C0material24_closed3875_conditional_bound_v1/packet.json',run/'board_physical_requalification_parallel_v1/partial_manifest.json',run/'board_legacy_mask_provenance_v1/manifest.json',run/'programme_scope.json',out/'scope_g4',prepared_index_ref=dict(file=str(out/'scope_g1/prepared_index.json'),sha256=__import__('hashlib').sha256((out/'scope_g1/prepared_index.json').read_bytes()).hexdigest()),dependency_relocations=json.loads((out/'scope_archives/relocations.json').read_text()))
print(json.dumps(r,ensure_ascii=False,indent=2));print('SECONDS',time.monotonic()-started)
