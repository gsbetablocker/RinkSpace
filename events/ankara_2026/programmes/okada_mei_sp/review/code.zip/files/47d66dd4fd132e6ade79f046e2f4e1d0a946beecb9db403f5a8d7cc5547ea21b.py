from pathlib import Path
import sys,json,subprocess,os,hashlib
root=Path('D:/OneDrive/codex_projs/RinkSpace');out=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/compare_build_v1');build=out.parent/'build_v3'
setup={};driver=Path('D:/CodexData/RinkSpace_Data/runs/okada_s1_r11/model_checks/build_event_backend.py');save=sys.argv;sys.argv=[str(driver),str(out)];exec(compile(driver.read_text(encoding='utf8').split('sources=')[0],str(driver),'exec'),setup);sys.argv=save
recipe=json.loads((build/'recipe.json').read_text());command=recipe['command'];flags=[x for x in command[1:] if x.startswith('/') and not x.startswith('/Fo') and not x.startswith('/Fe')]
flags=[x for x in flags if not x.startswith('/I')]+['/I'+str(root/'calibration/rinkfit/cpp/include')]+[x for x in flags if x.startswith('/I')]
source=root/'calibration/rinkfit/tools/joint_recovery_compare.cpp';objects=[p for p in build.glob('*.obj') if p.name!='joint_fit.obj'];libs=[x for x in command if x.endswith('.lib')]
cmd=[command[0],*flags,str(source),'/Fo:'+str(out/'joint_recovery_compare.obj'),'/Fe:'+str(out/'joint_recovery_compare.exe'),*map(str,objects),*libs]
r=subprocess.run(cmd,cwd=out,env=setup['env'],capture_output=True,text=True,errors='replace');(out/'build.log').write_text(r.stdout+r.stderr,encoding='utf8');(out/'recipe.json').write_text(json.dumps({'command':cmd,'returncode':r.returncode,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'runtime_bin_paths':recipe['runtime_bin_paths']},indent=2));print(r.stdout+r.stderr);raise SystemExit(r.returncode)
