import sys,json,pathlib
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src'),str(root/'calibration/program_tracking')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
from rinkfit_joint.baseline_recovery import apply_source_supported_motion_flags
from rinkfit_joint.io_utils import file_sha256,write_json
work=pathlib.Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019'); model=json.loads(pathlib.Path(r'D:/CodexData/RinkSpace_Data/runs/okada_full9_recovery_1019/baseline_import_gpu32_v1/navigation_model.json').read_text(encoding='utf8'))
q=apply_source_supported_motion_flags(work/'g5_ice/packet.json',model)
write_json(work/'recovery_input_g5_model.json',q)
print(json.dumps(dict(file=str(work/'recovery_input_g5_model.json'),sha256=file_sha256(work/'recovery_input_g5_model.json'),support=q['source_supported_motion_flags']),ensure_ascii=False))
