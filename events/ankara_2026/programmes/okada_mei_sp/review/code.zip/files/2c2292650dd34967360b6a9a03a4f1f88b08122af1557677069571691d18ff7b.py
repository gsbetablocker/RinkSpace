from pathlib import Path
import json,os,subprocess
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');recipe=json.loads((r/'compare_build_g5_v1/test_recipe.json').read_text());env=os.environ.copy();env['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+env.get('PATH','');env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
cmd=[str(r/'compare_build_g5_v1/test_joint_recovery_compare.exe'),'D:/CodexData/RinkSpace_Data/runs/okada_joint9_1018a/fit_full_source_v98/generation_1/model.json',str(r/'g5_compare_tiny_fixture.json'),str(r/'g5_compare_tiny_test_v1')]
x=subprocess.run(cmd,env=env,capture_output=True,text=True,errors='replace');print(x.stdout+x.stderr);raise SystemExit(x.returncode)
