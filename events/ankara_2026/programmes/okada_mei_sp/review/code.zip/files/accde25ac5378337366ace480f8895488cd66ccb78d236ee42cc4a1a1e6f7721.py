import os,sys,pathlib,json,subprocess,hashlib
w=pathlib.Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');b=w/'build_v6';recipe=json.loads((b/'recipe.json').read_text(encoding='utf8'))
exe=b/'joint_fit.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()==recipe['executable_sha256']
os.environ['PATH']=';'.join(recipe['runtime_bin_paths'])+';'+os.environ.get('PATH','')
code=subprocess.call([str(exe),'--engineering-recovery',str(w/'recovery_input_g5_model.json'),str(w/'g5_ice/packet.json'),str(w/'init_g5'),str(w/'init_g5_config.json')])
raise SystemExit(code)
