from pathlib import Path
import json,zipfile,hashlib,os
P=Path('D:/CodexData/RinkSpace_Data/pro');W=P.parent/'runs/okada_rec_1019'
p=json.loads((P/'okada_bundle_plan.json').read_text('utf-8')); keep=[];exclude=[]
for f in p['files']:
 s=f['source_path'].replace('\\','/');r=f['role'];n=Path(s).name
 reason=None
 if r=='complete-stage-state':
  # CP contains every mutable parameter, including nuisance. Keep each terminal stage CP/model/outer, logs, no duplicate aux exports/initial copies.
  if '/explicit_nuisance/' in s and '/demo_grid_recovery_v1/' not in s:reason='older explicit aux already serialized in bundled complete CP'
  elif '/initial_state/' in s and '/demo_grid_recovery_v1/' not in s:reason='intermediate preflight copy; terminal complete state and original start retained'
  elif '/outer_0/state/' in s:reason='same terminal state alias already inventoried'
  elif '/working_physical/' in s:reason='partial preview superseded by terminal full CP'
 if r=='last-stopped-complete-run':
  # Keep final raw-explicit pixel arrays; independent RS scalar report plus raw fixed-station residual is the relevant visual diagnosis.
  if '/initial_independent_RS_state/' in s:reason='initial independent reprofiling export, not authoritative CP'
  elif '/initial_state/CP_explicit_metrics/' in s and n!='manifest.json':reason='initial derived metric cache; initial CP intact'
  elif '/independent_RS_state/' in s and n not in ['model.json','value_report.json','raw_station_RS_error_native_uv.f64','raw_station_RS_valid.u8']:reason='independent local reprofiling cache; scalar report and raw-station residual retained'
  elif '/candidate/CP_explicit_metrics/' in s and n not in ['manifest.json','explicit_error_native_uv.f64','explicit_predicted_uv.f64','explicit_valid.u8','explicit_RS_equality.f64','explicit_query_equality.f64']:reason='derived classification cache; full classifications in receipt'
 if r=='last-complete-initial-state':
  if '/native/initial_independent_RS_state/' in s:reason='duplicate initial independent replay cache'
  elif '/native/initial_state/CP_explicit_metrics/' in s and n!='manifest.json':reason='duplicate initial derived pixels'
 if r=='continuous-feedback-actual-chain':reason='full feedback cache/test history; selected actual chain will be included instead'
 if r=='qualified-historical-source' and n not in ['source_rows.jsonl.gz']:reason='repeated geometry subset export; full source records and decisions retained'
 if r=='direct-grid/S01' and n=='candidate_predictions.npz':reason='derived prediction cache; full d78 function and aux retained'
 if r=='initialization-or-failure-evidence' and n.endswith('.npz'):reason='derived cache; model and original input retained'
 if reason:exclude.append({**f,'omission_reason':reason})
 else:keep.append(f)
p['files']=keep;p['excluded_redundant_products']=exclude
# V98 snapshot, original source + weight dependencies: original actual bytes, never remove recall markers.
v=json.loads((P/'okada_v98_original_package_inventory.json').read_text('utf-8'))
for f in v['initial_audit_zip']['core_v98_members']+v['initial_audit_zip']['weight_dependency_members']:
 # full serialized CP retains explicit nuisance; direct aux manifest retained as original reference.
 if '/explicit_nuisance/' in f['member'] and not f['member'].endswith('manifest.json'):continue
 p['zip_members'].append({'zip':v['initial_audit_zip']['file'],'member':f['member'],'archive_path':'Initial_v98/'+f['member'],'bytes':f['bytes'],'role':'original-v98-complete-input-state'})
# Add actual original source/run diagnostics, no inferred content.
seen={x['source_path'].replace('\\','/').lower() for x in keep}
def add(f,a=None,role='audit-export'):
 f=Path(f)
 if not f.is_file():return
 s=str(f).replace('\\','/')
 if s.lower() in seen:return
 seen.add(s.lower())
 if a is None:a='Data/'+f.relative_to(P.parent).as_posix()
 keep.append({'source_path':str(f),'archive_path':a,'bytes':f.stat().st_size,'role':role})
add(P/'okada_v98_original_package_inventory.json','offline/v98_inventory.json')
for f in (W/'audit_export').glob('*'):add(f,'Audit/'+f.name)
for f in (P.parent/'runs/okada_joint9_1018a').glob('fit_full_source_v98*'):
 if f.is_file() and f.suffix in ['.log','.jsonl','.json']:add(f,role='original-v98-run-log')
for f in W.rglob('engineering_outer.*.f64'):
 if f.is_file() and any('/'+x+'/' in f.as_posix() for x in {v['stage'] for v in json.loads((P/'okada_stage_state_inventory.json').read_text())['states']}):add(f,role='complete-outer-multiplier')
for n in ['codex-clipboard-private-attachment-00040.png','codex-clipboard-private-attachment-00041.png']:
 add(Path('C:/Users/REDACTED/AppData/Local/Temp')/n,'Evidence/user/'+n,role='user-supplied-failed-grid')
# W actual consumers and typed source arrays; all group matrices with offset/shape must be physically present.
d=json.loads((W/'g9_ice/packet.json').read_bytes())
refs=[]
def scan(x):
 if isinstance(x,dict):
  if 'file' in x and isinstance(x['file'],str) and x.get('dtype'):refs.append(x['file'])
  for v in x.values():scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
scan({'arrays':d['arrays'],'groups':d['groups']})
for q in sorted(set(refs)):add(q,role='actual-W-or-array-dependency')
(P/'okada_bundle_plan_v2.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),'utf-8')
print('CURATED',len(keep),'source refs',len(set(refs)),'zipmembers',len(p['zip_members']),'deflate_estimate',sum(x.get('deflate_bytes',0) for x in keep)+sum(x.get('compressed',0) for x in p['zip_members']))
