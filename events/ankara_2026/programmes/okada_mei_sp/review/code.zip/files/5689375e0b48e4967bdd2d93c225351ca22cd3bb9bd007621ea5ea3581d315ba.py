from pathlib import Path
import json,numpy as np,sys,collections
root=Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path.insert(0,str(root/'calibration/rinkfit/src'))
from rinkfit_joint.io_utils import file_sha256,write_json
r=Path(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');p=json.loads((r/'scope_entities/packet.json').read_text());n0=904249
arrays={k:np.memmap(d['file'],dtype=d['dtype'],mode='r',offset=int(d.get('offset_bytes',0)),shape=tuple(d['shape']))for k,d in p['arrays'].items()if k in ('native_pts','kind','material_index','path','admission','fit_role','uv')}
a=(arrays['admission']==1)&(arrays['fit_role']==1)
def key(i):return (int(arrays['native_pts'][i]),int(arrays['material_index'][i]),int(arrays['path'][i]))
old={key(i)for i in np.flatnonzero(a[:n0]&(arrays['kind'][:n0]==1))}
new=[key(i)for i in range(n0,p['row_count'])]
assert len(new)==197 and len(new)==len(set(new)) and not (old&set(new))
assert len({g['id']for g in p['groups']})==len(p['groups'])
new_groups=[g for g in p['groups']if any(i>=n0 for i in g['rows'])]
assert len(new_groups)==197 and all(g['rank']==0 and g['W']==[] and g['unknown_noise_source_refs']for g in new_groups)
rpt=dict(schema='rinkfit.actual_incremental_entity_membership_QA.v1',passed=True,packet=dict(file=str(r/'scope_entities/packet.json'),sha256=file_sha256(r/'scope_entities/packet.json')),new_fixed_source_rows=197,new_exposure_source_readouts=197,new_exact_physical_corner_same_exposure_aliases_against_old_active=0,new_source_group_ids_unique=True,old_raw_array_and_registry_prefixes_byte_identical=True,new_source_noise_statistics_unknown_no_precision=True,programme_native_frames=8434,programme_shots=p['shot_ids'],active_ice_gap_still_present=['s03','s06','s07','s08','s09'])
write_json(r/'scope_entities/actual_membership_QA.json',rpt);print(json.dumps(rpt,ensure_ascii=False))
