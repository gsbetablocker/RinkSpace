import sys,pathlib,json,traceback
root=pathlib.Path(r'D:/OneDrive/codex_projs/RinkSpace');sys.path[:0]=[str(root/'src'),str(root/'calibration/rinkfit/src'),str(root/'calibration/program_tracking')]
from runtime.bootstrap import add_geometry_dependencies
add_geometry_dependencies()
from rinkfit_joint.joint_solver import execute_explicit
raise SystemExit(execute_explicit(r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/build_v5/joint_fit.exe',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/recovery_input_model.json',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/g4_entities/packet.json',r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/motion_g2',config=r'D:/CodexData/RinkSpace_Data/runs/okada_rec_1019/motion_g2_config.json',engineering_recovery=True))
