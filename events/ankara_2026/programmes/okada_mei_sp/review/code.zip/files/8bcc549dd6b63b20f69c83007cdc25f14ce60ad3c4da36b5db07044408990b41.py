from pathlib import Path
import json,hashlib,time
r=Path('D:/CodexData/RinkSpace_Data/runs/okada_rec_1019');packet=r/'g6_bound/packet.json';spec_file=r/'recovery_metrics_g6_states.json';proof_file=r/'recovery_metrics_g6_refs.json'
if spec_file.exists() or proof_file.exists():raise ValueError('immutable metrics spec generation already exists')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def ref(path):
 p=Path(path)
 if not p.is_file():return dict(file=str(p),exists=False,sha256=None,status='future_shared_output_not_written')
 return dict(file=str(p),exists=True,sha256=sha(p),size_bytes=p.stat().st_size)
def load(path):return json.loads(Path(path).read_text(encoding='utf8'))
packet_ref=ref(packet);assert packet_ref['sha256']=='0d63cd94f0178449862a478bd4769c3fb2bfb373a504d4b50dbb8704906441cf'
states=[dict(label='failed_v98_reference_g6',state=str(r/'v98_same_g6_v1/independent_RS_state'),explicit=str(r/'v98_same_g6_v1/CP_explicit_metrics'),model=str(r/'v98_same_g6_v1/independent_RS_state/model.json'),model_view_semantics='Actual compatibility replay export: reference physical function with legacy master-expanded mirror view; not an assertion that every unused mirror equals complete CP. Stored CP auxiliaries and287 fresh numeric seeds remain explicitly distinguished.',expected_exact_checkpoint_model_blocks=False),dict(label='restored_S01_plus_g3_other8_g6',state=str(r/'init_g6_v2/initial_independent_RS_state'),explicit=str(r/'init_g6_v2/initial_state/CP_explicit_metrics'),model=str(r/'init_g6_v2/initial_independent_RS_state/model.json'),model_view_semantics='Exact runtime/CP block export after complete d78 S01 component restoration, keeping accepted g3 state of the other8 shots and initializing48 appended g6 rows.',expected_exact_checkpoint_model_blocks=True),dict(label='shared_g4_candidate_g6',state=str(r/'shared_g4/independent_RS_state'),explicit=str(r/'shared_g4/candidate/CP_explicit_metrics'),model=str(r/'shared_g4/independent_RS_state/model.json'),model_view_semantics='Future exact candidate physical model and independent replay from the same shared_g4 generation; SHA remains unbound until artifacts are complete.',expected_exact_checkpoint_model_blocks=True)]
limits=['Existing RMS/P95 summarize only each mode valid finite subset: report active_rows, valid_rows and invalid_rows together. Equal active population does not alone make conditional RMS denominators identical.','Existing worst_native_source_rows includes valid finite rows only. Failed roots and finite but physically invalid CP predictions require their separate failure-source evidence; they are not erased or treated as zero.','Non-Query rows keep stored finite station during independent native replay. Only frozen Query rows may locally close station,row,alpha on their fixed material path.']
checks=[]
for state in states:
 root=Path(state['state']);explicit=Path(state['explicit']);value_path=root/'value_report.json';meta_path=explicit/'manifest.json';model_path=Path(state['model']);entry=dict(label=state['label'],model=ref(model_path),value_report=ref(value_path),CP_manifest=ref(meta_path),state_directory_exists=root.is_dir(),CP_directory_exists=explicit.is_dir(),model_view_semantics=state['model_view_semantics'])
 if value_path.is_file() and meta_path.is_file() and model_path.is_file():
  value=load(value_path);meta=load(meta_path);assert entry['model']['sha256']==value['model_sha256'];assert value['files']['model.json']['sha256']==entry['model']['sha256'];assert meta['packet_sha256']==packet_ref['sha256'] and meta['raw_rows']==904536 and value['active_rows']==246650
  actual_exact=value.get('exact_checkpoint_model_blocks',False);assert actual_exact==state['expected_exact_checkpoint_model_blocks'];entry.update(status='existing_metadata_SHA_and_shape_verified',model_SHA_matches_replay_and_ledger=True,exact_checkpoint_model_blocks=actual_exact,CP_state_token=meta['state_token'],raw_rows=meta['raw_rows'],active_rows=value['active_rows'],array_payload_SHA_rescan_performed=False,arrays=[])
  for directory,ledger in [(root,value['files']),(explicit,meta['files'])]:
   for name,d in ledger.items():
    f=directory/name;assert f.is_file() and f.stat().st_size==d['size_bytes'];entry['arrays'].append(dict(file=str(f),exists=True,size_bytes=f.stat().st_size,expected_sha256=d['sha256'],payload_sha_status='model_payload_verified_above'if f==model_path else 'deferred_to_existing_metrics_checked_array_loader'))
  if state['label']=='failed_v98_reference_g6':
   receipt_path=r/'v98_same_g6_v1/comparison_receipt.json';receipt=load(receipt_path);assert receipt['current_packet_sha256']==packet_ref['sha256'] and receipt['comparison_denominator_rows']==246650 and receipt['same_original_CP_auxiliary_rows']==246363 and receipt['fresh_auxiliary_rows']==287 and receipt['explicit']['state_token']==meta['state_token'];entry['execution_receipt']=ref(receipt_path);entry['historical_CP_rows']=246363;entry['fresh_numerical_seed_rows']=287
  else:
   receipt_path=r/'init_g6_v2/initialization_only_receipt.json';receipt=load(receipt_path);assert receipt['source_packet_sha256']==packet_ref['sha256'] and receipt['explicit_metrics']['state_token']==meta['state_token'];entry['execution_receipt']=ref(receipt_path);cp_model=ref(r/'init_g6_v2/initial_state/model.json');assert cp_model['sha256']==entry['model']['sha256'];entry['CP_model_exact_same_SHA']=cp_model
 else:entry['status']='planned_not_ready_no_candidate_SHA_claimed'
 checks.append(entry)
spec=dict(schema='rinkfit.full9_g6_three_state_metrics_spec.v1',packet=packet_ref,raw_rows=904536,common_active_population_rows=246650,native_exposures=8434,states=states,mode_limits=limits,status='prepared_waiting_shared_g4_candidate',metrics_scan_started=False)
spec_file.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n',encoding='utf8');proof=dict(schema='rinkfit.recovery_metrics_spec_metadata_reference_check.v1',spec=ref(spec_file),packet=packet_ref,checks=checks,mode_limits=limits,large_pixel_or_temporal_scan_started=False,large_numeric_array_payloads_rehashed=False,production_metrics_source_changed=False,planned_command=['D:/OneDrive/codex_projs/RinkSpace/.venv/Scripts/python.exe','-X','utf8','-B','-m','rinkfit_joint.recovery_metrics','--packet',str(packet),'--states',str(spec_file),'--out',str(r/'full9_same_g6_v1')]);proof_file.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(spec=ref(spec_file),proof=ref(proof_file),states=[dict(label=x['label'],status=x['status'],model_sha=x['model']['sha256'])for x in checks],metrics_scan_started=False)))
